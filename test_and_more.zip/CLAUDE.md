# CLIP — Cloud Licensing Workspace Context

> **Application**: Connected Licensing Integrated Platform (CLIP)
> **Owner**: Dell Technologies — DLF Cloud Licensing Solution
> **Workspace root**: `cloud-licensing/` (multi-project, multi-Git-repo)

---

## Secondary Memory — LEARNINGS.md

**After every prompt**, update `ai/resources/LEARNINGS.md` with any new learnings, discoveries, patterns, gotchas, or corrections from the current interaction. This file serves as:
1. **User review surface** — the user reviews it to catch incorrect AI understandings
2. **Memory reconstruction** — can be used to rebuild AI memory in a new session (only if asked)
3. **Cross-session persistence** — not session-specific, no size limit, no compaction needed

Append new entries to the appropriate section or create new sections as needed. Do not overwrite or compact existing content.

### Feature Branch Requirement for the `ai` Repo

The `ai/` directory is a **separate Git repository** (remote: `gitlab.dell.com/.../ai.git`). Multiple users and AI agents modify it concurrently across different JIRA issues. **Before modifying any file in `ai/`** (including `LEARNINGS.md`, feature specs, project history, etc.), ensure the `ai` repo is checked out to the correct feature branch:

- **During SDLC work** (any `/skill` workflow): Use `develop-{ISSUE_ID}` — created automatically by the `prepare` skill.
- **During ad-hoc work with a JIRA context**: Create or switch to `develop-{ISSUE_ID}` before editing.
- **During non-JIRA sessions**: Create a descriptive branch (e.g., `develop-adhoc-{YYYYMMDD}`) or skip LEARNINGS.md updates if the session is trivial.

**Never commit directly to `develop`** in the `ai` repo during SDLC or JIRA-associated work — always use a feature branch. After modifying files in `ai/`, stage and commit the changes with the standard `JIRA#{ISSUE_ID}; {description}` message format.

### Workspace-Level Config Files — Dual-Copy Rule

The following workspace-level configuration files live at the workspace root (`cloud-licensing/`) but are **outside all Git repositories**:

- `cloud-licensing/CLAUDE.md` — this file
- `cloud-licensing/.devin/skills/` — Devin skill definitions
- `cloud-licensing/.windsurf/workflows/` — Windsurf workflow definitions

To ensure these files are version-controlled and branch-managed, the `ai` repo maintains **mirror copies** under `ai/do-not-use/`:

| Workspace root path | Mirror in `ai` repo |
|---|---|
| `CLAUDE.md` | `ai/do-not-use/CLAUDE.md` |
| `.devin/skills/` | `ai/do-not-use/.devin/skills/` |
| `.windsurf/workflows/` | `ai/do-not-use/.windsurf/workflows/` |

**Whenever you modify any of these workspace-level files**, you **must also copy the change** to the corresponding path under `ai/do-not-use/` and commit it to the `ai` repo on the current feature branch. The copy command pattern:

```bash
cp {WORKSPACE_ROOT}/{file} {WORKSPACE_ROOT}/ai/do-not-use/{file}
cd {WORKSPACE_ROOT}/ai && git add -A && git commit -m "JIRA#{ISSUE_ID}; sync workspace config: {file}"
```

This applies to all JIRA-associated and SDLC work. The workspace root copy is the **active** copy loaded by tools; the `ai/do-not-use/` copy is the **versioned** copy for Git history and merge conflict resolution.

---

## Workspace Layout

The `cloud-licensing/` root is **not itself a Git repository**. It contains multiple independent Git projects.

```
cloud-licensing/
├── clip-app/                  ← Core CLIP application (main write-side API services)
├── clip-integrations/         ← Dell-specific wrapper over clip-app; all external calls come via this
├── clip-control-plane/        ← Background processing, scheduled jobs, event listeners
├── clip-app-query/            ← Read-side query service (CQRS read model)
├── clip-client-java/          ← Java SDK for product/client integration
├── clip-client-c/             ← C/C++ native SDK for product/firmware
├── clip-delegated-server/     ← On-prem delegated license server (empty — setup pending)
├── clip-config-server/        ← Environment configurations
├── clip-demo-app/             ← Sample demo application (old, Java 17 / Spring Boot 3.2.4)
├── clip-ai-manager/           ← AI management console (NestJS + React)
├── clip-mcp-server/           ← MCP server for AI assistants (incomplete)
└── ai/                        ← AI specs, project specs, flows, scripts (separate Git repo)
```

---

## Project Summaries

### `clip-app` — Core CLIP API (Java 21 / Spring Boot 3.5.6)

Modular monolith — the primary write-side service. All domain modules assembled into a single deployable JAR. Uses Spring WebFlux (reactive, non-blocking) with functional endpoints (`RouterFunction<ServerResponse>`).

**Modules**: `clip-model`, `clip-commons`, `clip-offer`, `clip-entitlement`, `clip-product-instance`, `clip-product-client`, `clip-product-model`, `clip-consumption`, `clip-audit`, `clip-reservations`, `clip-clients`, `clip-app-service`, `clip-e2e-test`

**Key service module**: `clip-app-service` — Spring Boot main class, `application.yml`, final assembly.

**Conditional activation** via Spring properties: `spring.clip.core`, `spring.clip.productInstance`, `spring.clip.consumption`, `spring.clip.audit`.

### `clip-integrations` — External Integration Service (Java 21 / Spring Boot 3.5.6)

Dell-specific wrapper over clip-app. All external product registration requests flow through this service. Handles DLF integrations, B2B commerce, TLA pre-processing, auto-trial, delegated ops.

**Modules**: `clip-int-model`, `clip-int-commons`, `clip-int-clients`, `clip-int-gateway`, `clip-int-entitlement`, `clip-int-product`, `clip-int-consumption`, `clip-int-customer`, `clip-int-reservation`, `clip-int-delegated-ops`, `clip-audit-event-listener`, `clip-int-service`, `clip-int-e2e-test`

**Key service module**: `clip-int-service` — Main Spring Boot assembly.

**API base path**: `/api/v1/clip/integration/` (Portal: `/api/v1/clip/integration/portal/`)

### `clip-control-plane` — Background Operations (Java 21 / Spring Boot 3.5.6)

Scheduled jobs, Kafka event listeners, reprocessing, data migration, Customer Compliance Engine (CCE).

**Modules**: `clip-commons`, `clip-control-plane-cce`, `clip-control-plane-clients`, `clip-control-plane-reprocess`, `clip-control-plane-service`, `clip-scheduler`, `clip-sdr-event-listener`, `clip-transaction-audit`, `clip-product-instance`, `clip-data-migration-service`

**Key service module**: `clip-control-plane-service` — Main Spring Boot assembly.

### `clip-app-query` — Read-Side Query Service (Java 17 / Spring Boot 3.2.5)

CQRS read model — optimised query endpoints over CLIP data.

**Modules**: `clip-commons-query`, `clip-offer-query`, `clip-entitlement-query`, `clip-product-instance-query`, `clip-product-client-query`, `clip-product-model-query`, `clip-consumption-query`, `clip-reservations-query`, `clip-audit-query`, `clip-customer-query`, `clip-transaction-audit-query`, `clip-app-query-service`

**Key service module**: `clip-app-query-service` — Main Spring Boot assembly.

### `clip-client-java` — Java SDK (Java 17, has `mvnw`)

Thin Java client library for product teams to integrate with CLIP. Single JAR (`1.0.0-SNAPSHOT`).

### `clip-client-c` — C/C++ Native SDK

Native shared library (`libclipc`) for products/firmware. Targets Windows (MSVC) and Linux/Unix.

### `clip-ai-manager` — AI Management Tooling (Node.js/TypeScript)

`backend/` — NestJS REST API | `frontend/` — Vite + React UI.

---

## Technology Stack

| Layer | Technology |
|---|---|
| **Language** | Java 21 (clip-app, clip-integrations, clip-control-plane), Java 17 (clip-app-query, clip-client-java, clip-demo-app) |
| **Framework** | Spring Boot WebFlux (reactive) — 3.5.6 (main services), 3.2.5 (clip-app-query) |
| **Build** | Apache Maven multi-module (system `mvn`; `clip-client-java` has bundled `mvnw`) |
| **API style** | Functional endpoints (`RouterFunction<ServerResponse>`) — no annotation controllers |
| **Reactive** | Project Reactor — `Mono<T>` / `Flux<T>` throughout |
| **Database** | MongoDB (Reactive driver) |
| **Cache** | Redis (embedded for local profile) |
| **Messaging** | Apache Kafka — outbox pattern for reliability |
| **Security** | OAuth2 via Layer7 / DI Portal; JKS truststore (`dellcas2018.jks`) |
| **Code gen** | Lombok, MapStruct |
| **Observability** | Micrometer Tracing, Dynatrace OneAgent, Actuator |
| **CI/CD** | GitLab CI; environments: DIT → GE1/GE2/GE4 → Perf → Prod |

---

## Build & Test

### Building with Unit Tests (default — always do this for code changes)

All projects must build cleanly with full unit tests before changes are considered complete. Run `mvn clean install` from the project root for each impacted project.

**Projects**: `clip-app`, `clip-integrations`, `clip-control-plane`, `clip-app-query`
**Exception**: `clip-client-java` — use `./mvnw clean install` (bundled Maven wrapper)

### E2E Testing (skip unit tests, package, run JAR, then run E2E tests)

When testing for E2E scenarios, skip unit tests during build, run the service JAR, then run E2E tests separately to ensure no regression (no impact to existing behaviors or flows).

**All feature-level E2E tests live in `clip-integrations/clip-int-e2e-test`** — because all external requests flow through `clip-integrations`. Tests are **black-box**: submit HTTP requests via existing clients and assert on the response body only (no direct MongoDB queries).

| Item | Convention |
|---|---|
| **Location** | `clip-integrations/clip-int-e2e-test/src/test/java/.../e2e/suites/` |
| **Base class** | Extend `AbstractE2EUseCaseApp` (full client injection) or `AbstractE2EUseCaseIntegration` (integration clients only) |
| **Annotation** | `@Disabled @Slf4j @SpringBootTest(webEnvironment = RANDOM_PORT)` |
| **Setup** | `@BeforeEach init()` → `injectWebClientOnRandomPortToClipClients(port)` + `ObjectMapper` config |
| **Flow** | `@Test flow()` → setup data (model → offer → entitlement → register) → exercise feature endpoint → assert response |
| **Assertions** | `StepVerifier.create(mono).consumeNextWith(r -> { ... }).verifyComplete()` |
| **JSON fixtures** | `src/test/resources/jsonfiles/{feature}/` with `_PLACEHOLDER_` tokens, resolved via `E2ETestUtility.replacePlaceholder()` |
| **`@Disabled`** | Required — E2E tests need a running environment; they are not run in CI by default |

```bash
# 1. Build without tests
cd clip-app
./mvnw clean
./mvnw package -DskipTests=true

# 2. Run the service JAR
java -jar ./clip-app-service/target/clip-app-service-0.0.1-SNAPSHOT.jar \
  --info -Dreactor.netty.http.server.accessLogEnabled=true

# 3. Run E2E tests (in a separate terminal)
# clip-app E2E tests (against running instance)
cd clip-app && mvn test -pl clip-e2e-test -Dspring.profiles.active=test

# clip-integrations E2E tests (black-box feature tests)
cd clip-integrations && mvn test -pl clip-int-e2e-test -Dspring.profiles.active=test

# Python-based registration E2E tests (against running instance)
uv run ai/scripts/test_registrations.py --help
```

### Service JAR Locations

| Project | Service JAR |
|---|---|
| clip-app | `clip-app-service/target/clip-app-service-0.0.1-SNAPSHOT.jar` |
| clip-integrations | `clip-int-service/target/clip-int-service-0.0.1-SNAPSHOT.jar` |
| clip-control-plane | `clip-control-plane-service/target/clip-control-plane-service-0.0.1-SNAPSHOT.jar` |
| clip-app-query | `clip-app-query-service/target/clip-app-query-service-0.0.1-SNAPSHOT.jar` |

### Running Locally

```bash
# Run clip-app with local profile
cd clip-app && mvn spring-boot:run -pl clip-app-service -Dspring-boot.run.profiles=local
```

**Runtime**: Port `9092`, context path `/clip-app`, JVM heap `-Xmx4g -Xms2g`, profiles: `local`, `dev`, `cloud`, `cloud-prod`.

### Test Commands Reference

This section is the **single source of truth** for the `test` skill/workflow. Each project entry defines the commands to run for unit tests, E2E tests, and lint/static analysis. The `test` skill reads this table — update it here whenever a project's test setup changes.

| # | Project | Type | Command | Working Directory | Notes |
|---|---------|------|---------|-------------------|-------|
| 1 | `clip-app` | unit | `mvn clean install` | `clip-app` | Full build with all unit tests |
| 2 | `clip-app` | e2e | `mvn test -pl clip-e2e-test -Dspring.profiles.active=test` | `clip-app` | Requires running service JAR |
| 3 | `clip-integrations` | unit | `mvn clean install` | `clip-integrations` | Full build with all unit tests |
| 4 | `clip-integrations` | e2e | `mvn test -pl clip-int-e2e-test -Dspring.profiles.active=test` | `clip-integrations` | Black-box feature tests; requires running service JAR |
| 5 | `clip-control-plane` | unit | `mvn clean install` | `clip-control-plane` | Full build with all unit tests |
| 6 | `clip-app-query` | unit | `mvn clean install` | `clip-app-query` | Full build with all unit tests |
| 7 | `clip-client-java` | unit | `./mvnw clean install` | `clip-client-java` | Uses bundled Maven wrapper |
| 8 | `clip-ai-manager` | unit | `npm run test` | `clip-ai-manager/backend` | Jest (NestJS backend only) |
| 9 | `clip-ai-manager` | e2e | `npm run test:e2e` | `clip-ai-manager/backend` | Requires running NestJS service |
| 10 | `clip-ai-manager` | lint | `npm run lint` | `clip-ai-manager/frontend` | Vite + React frontend lint |

**Column definitions:**
- **Type**: `unit` = unit/integration tests (run always), `e2e` = end-to-end tests (run only when requested or when implementation plan specifies), `lint` = static analysis/linting.
- **Working Directory**: Relative to the workspace root (`cloud-licensing/`).
- **Notes**: Pre-conditions or special instructions.

**E2E pre-requisites:** E2E tests require a running service instance. Before running E2E commands, build and start the service JAR (see "Service JAR Locations" above). E2E tests that are `@Disabled` need the annotation removed or a specific test class targeted.

---

## Key Architecture Patterns

| Pattern | Description |
|---|---|
| **Modular monolith** | `clip-app` — all domain modules assembled into one JAR |
| **CQRS** | `clip-app` (writes) + `clip-app-query` (reads) |
| **Handler → Service → Repository** | Layered architecture within every domain module |
| **Kafka Outbox** | Reliable event publishing via `clip_kafka_outbox` MongoDB collection |
| **Pre-Authorization Filter** | Cross-cutting header validation (`X-Primary-Customer-Id`, `correlationId`, etc.) |
| **Conditional Beans** | `@ConditionalOnProperty` to enable/disable modules per deployment |
| **Correlation ID propagation** | Reactor context (`contextWrite`) for distributed tracing |
| **Response signing** | `JsonSecurityService` — cryptographic signing of registration responses |
| **TTL Index** | Auto-expiry of test/trial `ProductInstance` records (30-day TTL) |
| **RFC 7807 errors** | `ClipException` + `ClipProblemDetail` for all error responses |

---

## Local Configuration

Personal access tokens for external services are stored in `local.config` at the workspace root. Read this file to authenticate with Confluence, Jira, or GitLab APIs.

| Variable | Service |
|---|---|
| `JIRA_PAT` | Jira (Dell internal) |
| `GIT_PAT` | GitLab (`gitlab.dell.com`) |
| `CONFLUENCE_PAT` | Confluence (Dell internal) |

**Usage**: Read `local.config` and parse the `KEY=VALUE` pairs. Never log, commit, or expose these tokens.

---

## Feature Development Lifecycle

Every new feature, enhancement, defect fix, or config change follows the same end-to-end process. Workflows are defined in both `.windsurf/workflows/` (for Windsurf) and `.devin/skills/` (for Devin). The steps below must be followed in order.

### Master Orchestrator — `sdlc` Skill

**Skill:** `.devin/skills/sdlc/SKILL.md`

The `sdlc` skill runs the **entire SDLC autonomously** from a single JIRA ID. It chains all individual skills below and only pauses at **3 user checkpoints**:

| # | Checkpoint | User Action |
|---|-----------|-------------|
| **1** | After feature spec generated | Review requirements, answer open questions, iterate until clear |
| **2** | After implementation plan generated | Review plan, iterate until perfect |
| **3** | After MRs created | Add review comments to code diffs in GitLab for final optimization |

Between checkpoints, the agent operates fully autonomously — JIRA updates, Git operations, builds, tests, commits, pushes, MR creation, and cleanup all happen without user intervention.

**Quick start:** `Run the SDLC workflow for SCLP-3394`

### Directory Structure

```
ai/
├── project-specs/                          ← Workspace-level specs (initialised once)
│   ├── functional-spec.md
│   ├── technical-spec.md
│   ├── data-model-spec.md
│   ├── api-spec.md
│   ├── flows/                              ← Mermaid flow diagrams for existing features
│   └── data/                               ← Sample JSON requests/responses, model & offer configs
│
└── feature-specs/
    └── {JIRA_ID}/                          ← One folder per JIRA issue (e.g. SCLP-3394)
        ├── feature-spec.md                 ← Functional requirements, ACs, impacted areas, open questions
        ├── implementation_plan.md          ← Detailed code change plan, test strategy, file references
        ├── change-summary.md              ← Summary of all changes, tests, commits (generated by /execute)
        └── merge-requests.md              ← MR links per project (generated by /git_push)
```

### Step-by-Step Process

| # | Phase | Workflow | Skill | Description |
|---|-------|---------|-------|-------------|
| **0** | **Initialise project specs** | `/create_project_specs` | `.devin/skills/create_project_specs/SKILL.md` | Run **once** (or when the codebase changes significantly) to generate `ai/project-specs/` with functional, technical, data model, and API specs. This is a **prerequisite** for all feature work. |
| **1** | **Create feature spec** | `/create_feature_specs {JIRA_ID}` | `.devin/skills/create_feature_specs/SKILL.md` | Fetches the JIRA issue (summary, description, ACs) via REST API, cross-references project specs and codebase, and generates `ai/feature-specs/{JIRA_ID}/feature-spec.md`. Transitions JIRA to **Defining Details**. |
| **2** | **Review feature spec** | *(manual — Checkpoint 1)* | — | User reviews the feature spec, answers open questions (§4.9), and iterates until the requirements are clear and complete. |
| **3** | **Create implementation plan** | `/create_implementation_plan {JIRA_ID}` | `.devin/skills/create_implementation_plan/SKILL.md` | Reads the feature spec, traces the codebase, and generates `ai/feature-specs/{JIRA_ID}/implementation_plan.md` with files to modify, test strategy, merge rules, and code references. Transitions JIRA to **Waiting for Dev**. |
| **4** | **Review & finalise plan** | *(manual — Checkpoint 2)* | — | User reviews and iterates on the implementation plan until it is ready for development. |
| **5** | **Prepare** | `/prepare {JIRA_ID}` | `.devin/skills/prepare/SKILL.md` | Attaches the feature spec and implementation plan to the JIRA issue, posts a structured summary comment, creates feature branches `develop-{JIRA_ID}` across impacted projects, and transitions the issue to **In Development**. |
| **6** | **Execute implementation** | `/execute {JIRA_ID}` | `.devin/skills/execute/SKILL.md` | Follows the implementation plan step by step (TDD): writes tests, implements code, runs verification, commits with message format `JIRA#{JIRA_ID}; {description}`. |
| **7** | **Test** | `/test {JIRA_ID}` | `.devin/skills/test/SKILL.md` | Pre-push quality gate: runs full unit tests across all impacted projects, optionally runs E2E tests. All tests must pass before pushing. |
| **8** | **Push & create MR** | `/git_push {JIRA_ID}` | `.devin/skills/git_push/SKILL.md` | Pushes feature branches to origin and creates Merge Requests targeting `develop` (never `main`). |
| **9** | **Review MR diffs** | *(manual — Checkpoint 3)* | — | Human reviewer adds comments to the MR code diffs in GitLab for final optimization. |
| **10** | **Fix MR comments** | `/git_fix_comments {JIRA_ID}` | `.devin/skills/git_fix_comments/SKILL.md` | Reads unresolved MR review comments from GitLab, analyses each, implements accepted fixes, replies with reasoning for rejected ones, builds with unit tests, commits, and pushes to the same feature branch. |
| **11** | **Wrap up** | `/wrap_up {JIRA_ID}` | `.devin/skills/wrap_up/SKILL.md` | Verifies all MRs are merged, deletes local and remote feature branches, updates per-project functional history (`ai/project-history/`), posts a coding summary comment to JIRA, and transitions the issue to **Complete**. |

### Commit Message Convention

All commits **must** follow the GitLab pre-receive hook pattern:

```
JIRA#{JIRA_ID}; {short description}
```

Example: `JIRA#SCLP-3394; Add additionalInfo-only update path for PUT /api/v1/clip/product`

The pattern enforced by the hook is: `(JIRA#[A-Za-z0-9]{2,}-\d+;)` — note the `JIRA#` prefix and trailing semicolon.

**No AI attribution in commits**: Do **NOT** add `Co-Authored-By: Devin`, `Generated with [Devin]`, or any similar AI-generated/co-authored labels to commit messages. Commit messages must contain only the JIRA-prefixed description — nothing else.

### Branch Naming

Feature branches are named `develop-{JIRA_ID}` (e.g. `develop-SCLP-3394`). MRs always target `develop`, never `main`.

### JIRA Status Transitions (automated by sdlc skill)

| Phase | JIRA Status | Triggered by |
|-------|-------------|-------------|
| Feature spec created | Defining Details | `create_feature_specs` (Step 1) |
| Implementation plan created | Waiting for Dev | `create_implementation_plan` (Step 3) |
| Specs attached & branches created | In Development | `prepare` (Step 5) |
| MRs merged & wrapped up | Complete | `wrap_up` (Step 11) |

### Skills Inventory

All skills are in `.devin/skills/` and have a corresponding workflow in `.windsurf/workflows/`:

| Skill | Path | Lines | Purpose |
|-------|------|-------|---------|
| `sdlc` | `.devin/skills/sdlc/SKILL.md` | ~280 | **Master orchestrator** — chains all skills, 3 user checkpoints |
| `create_project_specs` | `.devin/skills/create_project_specs/SKILL.md` | ~500 | Generate 8 project-level spec documents |
| `create_feature_specs` | `.devin/skills/create_feature_specs/SKILL.md` | ~360 | Generate feature requirements spec from JIRA, transition to Defining Details |
| `create_implementation_plan` | `.devin/skills/create_implementation_plan/SKILL.md` | ~570 | Generate detailed implementation plan with code refs, transition to Waiting for Dev |
| `prepare` | `.devin/skills/prepare/SKILL.md` | ~350 | Attach specs to JIRA, create feature branches, transition to In Development |
| `execute` | `.devin/skills/execute/SKILL.md` | ~530 | TDD implementation, build, commit |
| `test` | `.devin/skills/test/SKILL.md` | ~350 | Pre-push quality gate — run unit tests, E2E tests, lint across impacted projects |
| `git_push` | `.devin/skills/git_push/SKILL.md` | ~310 | Push branches, create MRs targeting develop |
| `git_fix_comments` | `.devin/skills/git_fix_comments/SKILL.md` | ~250 | Fix MR review comments, reply on GitLab |
| `wrap_up` | `.devin/skills/wrap_up/SKILL.md` | ~580 | Delete branches, update project history, JIRA summary, transition to Complete |

---

## Cross-Project Notes

- Changes to `clip-model` or `clip-commons` in `clip-app` often require matching changes in `clip-control-plane` and `clip-app-query`, which maintain their own copies of commons.
- All main Java projects share `groupId: com.dell.delp.clip` and version `0.0.1-SNAPSHOT`. Exception: `clip-client-java` uses `com.dell.delp.clip.client` / `1.0.0-SNAPSHOT`.
- GitLab remote: `https://gitlab.dell.com/infrastructure/ase/dlf/cloud-licensing-solution/<project-name>`
- Branch strategy: feature branches → `develop` (rebase) → MR to `main` → deploy to GE for manual verification.
- CheckStyle config: `clip_checks.xml` in `clip-app` and `clip-app-query`.

---

## Detailed Specifications

For in-depth details, refer to the project specs at `ai/project-specs/`:

| Spec | Path | Contents |
|---|---|---|
| **Technical Spec** | `ai/project-specs/technical-spec.md` | Full architecture, module dependencies, Kafka topics/config, server config, MongoDB config, security, deployment, observability |
| **Functional Spec** | `ai/project-specs/functional-spec.md` | All features & use cases, business rules, functional flows (Mermaid diagrams), actors & roles |
| **API Spec** | `ai/project-specs/api-spec.md` | Every REST endpoint for clip-app — method, path, headers, params, request/response DTOs |
| **Data Model Spec** | `ai/project-specs/data-model-spec.md` | All 19+ MongoDB collections, field definitions, indexes (unique/compound/TTL), embedded types, enumerations |
| **Registration Flows** | `ai/project-specs/flows/` | 11 detailed Mermaid flow diagrams (HW/SW registration, expansion, reduction, TLA, upgrade, deregistration) |
| **Sample Data** | `ai/project-specs/data/` | Example JSON requests/responses, sample product model & offer configs |

### Quick Reference — When to Consult Which Spec

- **Adding/changing an API endpoint?** → `api-spec.md` + `technical-spec.md` (routing pattern)
- **Modifying a MongoDB entity or index?** → `data-model-spec.md`
- **Changing registration logic?** → `functional-spec.md` + `flows/*.md`
- **Working on clip-integrations registration?** → `flows/*.md` (all 11 registration flows)
- **Understanding compliance/audit?** → `functional-spec.md` (sections 3.7, 4.6)
- **Kafka topics or messaging?** → `technical-spec.md` (section 6)
- **Server/deployment config?** → `technical-spec.md` (sections 7, 10)

---

## Domain Quick Reference

### Core Concepts

- **Product Model** → licensable software product definition + license policy
- **Offer** → feature set (feature codes, types, UoM) under a product model
- **Entitlement** → customer's right to use features (types: `PERPETUAL`, `EVALUATION`, `SUBSCRIPTION`, `TLA`, `PAY_PER_USE`, `LIMITED`)
- **Product Instance** → registered installation with unique **cSWID** (format: `CL` + 3-char product line code + 2-digit hex nanoseconds, ~7 chars)
- **Product Client** → connectivity agent on a product instance
- **Reservation Pool** → groups cSWIDs + entitlements; determines **License Type** (priority: `TLA > PAID > TRIAL > LIMITED > UNLICENSED`)
- **Consumption** → feature usage telemetry per client
- **Compliance** → audit check (feature qty / term / uncounted) with severity: `100 OK → 200 INFO → 300 WARN → 400 ALERT → 500 CRITICAL`

### Registration Flows (via clip-integrations)

| Flow | Method | Path |
|---|---|---|
| New HW registration | `POST` | `/api/v1/clip/integration/product/hardware` |
| New SW registration | `POST` | `/api/v1/clip/integration/product/software` |
| Update / Expansion | `PUT` | `/api/v1/clip/integration/product` |
| Reduction | `PUT` | `/api/v1/clip/integration/product/reduction` |
| Deregistration | `POST` | `/api/v1/clip/integration/product/deregister/external` |
| File-to-connected upgrade | `POST` | `/api/v1/clip/integration/product/upgrade/external` |

### Key MongoDB Collections

`clip_product_models`, `clip_offers`, `clip_entitlements`, `clip_entitled_features`, `clip_product_instances`, `clip_product_clients`, `clip_reservation`, `clip_consumption`, `clip_consumption_state`, `clip_audit`, `clip_compliance`, `clip_tla_consumption_state`, `clip_transactions_audit`, `clip_kafka_outbox`, `clip_exception_audit`

Full schema details → `ai/project-specs/data-model-spec.md`
