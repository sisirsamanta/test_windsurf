# Skill: prepare

> Prepare for feature implementation: attach specs to JIRA, create feature branches across workspace repos, and transition the JIRA issue to "In Development".

---

## Purpose

This workflow combines three preparation tasks that happen after the feature spec and implementation plan are reviewed and approved:

1. **Attach artifacts to JIRA** — uploads `feature-spec.md` and `implementation_plan.md` as attachments and posts a structured summary comment.
2. **Create feature branches** — checks out `develop`, pulls latest, and creates `develop-{ISSUE_ID}` in every impacted project.
3. **Transition JIRA status** — moves the issue to **In Development** to signal that coding is about to begin.

---

## Prerequisites

- `local.config` at workspace root contains `JIRA_PAT` for JIRA API access.
- JIRA base URL is `https://jira.dell.com`.
- The feature spec directory `ai/feature-specs/{ISSUE_ID}/` exists and contains both `feature-spec.md` and `implementation_plan.md`.
- All Git projects are cloned under the `cloud-licensing/` workspace root with an `origin` remote.
- Network access to the Git remote and JIRA instance.

---

## Workflow Steps

### Step 1 --- Obtain JIRA Issue ID

Determine the JIRA issue ID (e.g., `SCLP-1234`) from one of the following sources, in priority order:

1. **Explicitly provided by the user** --- use as-is.
2. **Current git branch name** --- extract from branch naming convention:
   ```bash
   BRANCH=$(git branch --show-current)
   ISSUE_ID=$(echo "$BRANCH" | grep -oP 'SCLP-\d+')
   ```
3. **Prompt the user** --- if neither source yields an issue ID, ask the user to provide it.

The feature branch naming convention is `develop-{ISSUE_ID}` (e.g. `develop-SCLP-1234`).

---

### Step 2 --- Verify Local Artifacts

Check that both required files exist:

```bash
SPEC_DIR="ai/feature-specs/${ISSUE_ID}"
FEATURE_SPEC="${SPEC_DIR}/feature-spec.md"
IMPL_PLAN="${SPEC_DIR}/implementation_plan.md"
```

If either file is missing, stop and tell the user to run `create_feature_specs` or `create_implementation_plan` first.

**Read both files** to extract content for the JIRA summary comment in Step 6:

1. **From `feature-spec.md`** --- extract Overview, Functional Requirements (FR-XXX items), and Acceptance Criteria.
2. **From `implementation_plan.md`** --- extract Files to Modify, Test Plan, Critical Constraints, and Open Questions.

---

### Step 3 --- Determine Which Projects to Prep

The workspace contains the following Git repositories (each is a separate Git repo under `cloud-licensing/`):

|| # | Project Directory |
||---|---|
|| 1 | `clip-app` |
|| 2 | `clip-integrations` |
|| 3 | `clip-control-plane` |
|| 4 | `clip-app-query` |
|| 5 | `clip-client-java` |
|| 6 | `clip-client-c` |
|| 7 | `clip-config-server` |
|| 8 | `clip-delegated-server` |
|| 9 | `clip-demo-app` |
|| 10 | `clip-mcp-server` |
|| 11 | `ai` |

Use the following priority order to decide which projects to prep:

#### Priority 1: Auto-detect from feature spec (preferred)

Read the feature spec and implementation plan files. Extract all mentioned module names and map them to their parent Git project using the **Module-to-Project Mapping Table** below:

|| Module Name | Git Project |
||---|---|
|| `clip-model`, `clip-commons`, `clip-offer`, `clip-entitlement`, `clip-product-instance`, `clip-license`, `clip-registration`, `clip-api`, `clip-service`, `clip-persistence`, `clip-app-config`, `clip-app-service`, `clip-e2e-test` | `clip-app` |
|| `clip-int-*` (any module starting with `clip-int-`), `clip-audit-event-listener` | `clip-integrations` |
|| `clip-control-plane-*`, `clip-scheduler`, `clip-sdr-event-listener`, `clip-transaction-audit`, `clip-data-migration-service` | `clip-control-plane` |
|| `clip-*-query`, `clip-app-query-service` | `clip-app-query` |
|| `clip-client-java` | `clip-client-java` |
|| `clip-client-c` | `clip-client-c` |
|| `clip-config-server` | `clip-config-server` |
|| `ai` (any file path under `ai/`) | `ai` |

**After auto-detection, present the detected project list to the user for confirmation before proceeding.** The user may add or remove projects from the list.

> **Note:** The `ai` project should **always be included** regardless of detection method. Every SDLC workflow writes files to `ai/`.

#### Priority 2: User-specified projects

If the user provides an explicit list, use that directly.

#### Priority 3: Ask the user

If neither a feature spec nor an explicit list is available, present the full project list and ask the user to select.

---

### Step 4 --- Pre-Flight Checks & Context Switching

Before modifying any repo, check the **current branch** and **working tree status** on every selected project:

```bash
cd <project-dir>
CURRENT_BRANCH=$(git branch --show-current)
STATUS=$(git status --porcelain)
```

Evaluate each project against the cases below.

#### Case A --- On a different feature branch (context switch)

The current branch matches `develop-{OTHER_ID}` where `OTHER_ID` is a **different** issue from `{ISSUE_ID}`. This means the user was previously working on another feature and is now switching to a new one.

1. **If the working tree is dirty** (uncommitted changes exist):
   - Extract the previous issue ID: `OTHER_ID` = the part after `develop-` in the branch name.
   - **Auto-commit** all changes with the proper JIRA commit message format:
     ```bash
     git add -A
     git commit -m "JIRA#${OTHER_ID}; WIP: save in-progress work before switching to ${ISSUE_ID}"
     ```
   - Log: `"Auto-committed in-progress work on develop-{OTHER_ID} in {project}."`

2. **If the working tree is clean**, no action needed.

In both sub-cases, the project proceeds to Step 5 normally (checkout `develop`, pull, create new branch).

#### Case B --- On `develop`, `main`, or any non-feature branch with a dirty working tree

Present the status to the user and ask them to choose:

|| Option | Action |
||---|---|
|| **Stash** | Run `git stash push -m "prepare auto-stash before develop-{ISSUE_ID}"` and continue. |
|| **Skip** | Skip this project. Mark it as "skipped (dirty)" in the final report. |
|| **Abort** | Stop the entire workflow immediately. |

#### Case C --- Already on `develop-{ISSUE_ID}` (same feature branch as the new issue)

The branch for this issue already exists and is checked out. Ask the user:

|| Option | Action |
||---|---|
|| **Keep** | Stay on the existing branch. Skip Git prep (Step 5) for this project --- it is already set up. |
|| **Recreate** | Delete the local branch, re-checkout `develop`, pull latest, and recreate `develop-{ISSUE_ID}`. **Warn** that any local-only commits on the old branch will be lost. |

#### Case D --- Clean working tree (any branch, no uncommitted changes, and not Case C)

No action needed --- proceed directly to Step 5.

---

Only proceed to Step 5 once all selected projects have been processed (auto-committed, stashed, skipped, or already clean).

---

### Step 5 --- Execute Git Prep

For each selected project that passed pre-flight checks, execute **sequentially**:

```bash
cd <project-dir>

# 1. Switch to develop branch
git checkout develop

# 2. Pull latest develop
git pull origin develop

# 3. Create the feature branch from develop
git checkout -b develop-{ISSUE_ID}

# 4. Pull to set up tracking (non-blocking if remote branch doesn't exist yet)
git pull origin develop
```

#### Error Handling

|| Step | Error Scenario | Handling |
||---|---|---|
|| `git checkout develop` | Local `develop` doesn't exist | Run `git fetch origin develop` then `git checkout -b develop --track origin/develop`. |
|| `git pull origin develop` | Network/auth error or merge conflicts | Mark project as failed. Report the specific error. |
|| `git checkout -b develop-{ISSUE_ID}` | Branch already exists locally | Ask user: **Switch** to existing branch or **Recreate** (delete and re-create from develop). |
|| `git checkout -b develop-{ISSUE_ID}` | Branch already exists on remote | Inform user and ask: **Switch and track** or **Recreate locally**. |
|| Second `git pull` | Any failure | **Non-blocking.** Log a warning but do NOT mark the project as failed. |

If a project fails at any step, log the failure and **continue to the next project**. Do not abort the entire workflow.

---

### Step 6 --- Attach Specs to JIRA

Upload both spec files as attachments to the JIRA issue.

#### 6a. Obtain JIRA Credentials

```bash
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
JIRA_BASE="https://jira.dell.com"
```

#### 6b. Upload Attachments

```bash
# Attach feature-spec.md
curl -s -w "\n%{http_code}" \
  -X POST \
  -H "Authorization: Bearer $JIRA_PAT" \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@${FEATURE_SPEC}" \
  "${JIRA_BASE}/rest/api/2/issue/${ISSUE_ID}/attachments"

# Attach implementation_plan.md
curl -s -w "\n%{http_code}" \
  -X POST \
  -H "Authorization: Bearer $JIRA_PAT" \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@${IMPL_PLAN}" \
  "${JIRA_BASE}/rest/api/2/issue/${ISSUE_ID}/attachments"
```

**Verify** each upload returns HTTP 200. If an attachment with the same name already exists, JIRA will create a new version --- this is acceptable.

If either upload fails, report the error but continue to the next step. JIRA failures are non-blocking.

---

### Step 7 --- Post Summary Comment to JIRA

Construct a structured comment in **JIRA wiki markup** and post it. Use the content extracted in Step 2 to populate sections.

#### Comment Template (JIRA Wiki Markup)

```
{panel:title=AI Feature Artifacts|borderStyle=solid|borderColor=#0052CC|titleBGColor=#0052CC|titleColor=#FFFFFF|bgColor=#F4F5F7}
*Attachments uploaded:*
* [^feature-spec.md] --- Feature specification document
* [^implementation_plan.md] --- Implementation plan with file changes and test strategy

_Generated by AI assistant_
{panel}

h2. Feature Spec Summary

h3. Overview
<OVERVIEW_TEXT>

h3. Functional Requirements
|||ID||Title||
||<FR_ID_1>|<FR_TITLE_1>|
...

h3. Acceptance Criteria
* <AC_1>
* <AC_2>
...

----

h2. Implementation Plan Summary

h3. Files to Modify
|||File Path||Change Description||
||{{<FILE_PATH_1>}}|<CHANGE_DESC_1>|
...

h3. Test Plan
* <TEST_ITEM_1>
...

h3. Critical Constraints
{warning}
* <CONSTRAINT_1>
...
{warning}

----

h2. Open Questions
{color:#de350b}*The following items require human review before implementation begins:*{color}
# <OPEN_QUESTION_1>
...

{note}If there are no open questions, this section will read: "No open questions --- ready for implementation."{note}
```

#### Posting the Comment

Build the JSON payload with the wiki markup body. **JSON-escape** the body string:

```bash
JSON_PAYLOAD=$(jq -n --arg body "$COMMENT_BODY" '{"body": $body}')

curl -s -w "\n%{http_code}" \
  -X POST \
  -H "Authorization: Bearer $JIRA_PAT" \
  -H "Content-Type: application/json" \
  -d "$JSON_PAYLOAD" \
  "${JIRA_BASE}/rest/api/2/issue/${ISSUE_ID}/comment"
```

**Verify** HTTP 201. If it fails, report the error but continue.

---

### Step 8 --- Transition JIRA to "In Development"

#### 8a. Fetch current issue status

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name`. If already "In Development", skip the transition.

#### 8b. Get available transitions

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Find the transition whose `name` matches **"In Development"** (case-insensitive). Record its `id`.

#### 8c. Execute the transition

```bash
curl -s -X POST \
  -H "Authorization: Bearer $JIRA_PAT" \
  -H "Content-Type: application/json" \
  -d '{"transition": {"id": "<TRANSITION_ID>"}}' \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}/transitions"
```

#### 8d. Error handling

|| Error Scenario | Handling |
||---|---|
|| `JIRA_PAT` not found | Log warning: "JIRA PAT not configured. Skipping JIRA updates." Continue workflow. |
|| HTTP 401 | Log warning: "JIRA authentication failed. PAT may be expired. Skipping." |
|| HTTP 403 | Log warning: "JIRA permission denied. Skipping." |
|| No matching transition | Log warning: "No 'In Development' transition available from current status '{status}'. Issue may already be in the target state. Skipping." |
|| Network error | Log warning: "Could not reach JIRA. Skipping." |

**JIRA failure is NOT a workflow failure.** The Git prep is the primary objective. JIRA updates are best-effort. Always continue to the report regardless of JIRA outcome.

---

### Step 9 --- Report Results

Produce a summary report after all steps are complete.

#### Git Prep Summary

```
=======================================
  prepare Summary --- develop-{ISSUE_ID}
=======================================

|| # | Project              | Status  | Branch                | Details                    |
||---|----------------------|---------|-----------------------|----------------------------|
|| 1 | clip-app             | PREPPED | develop-SCLP-1234     | HEAD: a1b2c3d              |
|| 2 | clip-integrations    | PREPPED | develop-SCLP-1234     | HEAD: e4f5g6h (auto-committed WIP on develop-SCLP-999) |
|| 3 | clip-control-plane   | SKIPPED | develop (dirty)       | User chose to skip         |
|| 4 | clip-app-query       | FAILED  | develop               | Branch already exists      |
|| 5 | ai                   | PREPPED | develop-SCLP-1234     | HEAD: i7j8k9l (auto-committed WIP on develop-SCLP-999) |

Totals: 3 prepped / 1 skipped / 1 failed
Context switches: 2 projects had in-progress work auto-committed on develop-SCLP-999
```

#### JIRA Summary

```
JIRA Attachments: 2 uploaded (feature-spec.md, implementation_plan.md)   [OK]
JIRA Comment:     Posted (ID: XXXXX)                                      [OK]
JIRA Status:      Transitioned to "In Development"                        [OK]
```

#### Reminders

```
NOTE: All feature branches are LOCAL only. They have not been pushed to origin.
      Push branches after committing your changes: git push origin develop-{ISSUE_ID}
```

---

## Important Rules

1. **Never discard uncommitted work.** If on a different feature branch, auto-commit with `JIRA#{OTHER_ID}; WIP:` message. If on `develop` or a non-feature branch, ask the user before stashing or switching.
2. **Auto-commit uses the JIRA commit format.** The commit message must match the GitLab pre-receive hook pattern `(JIRA#[A-Za-z0-9]{2,}-\d+;)` --- even for WIP auto-commits.
3. **Never force-push or force-delete branches.** Always ask the user when a branch conflict is encountered.
4. **Process projects sequentially**, not in parallel, to avoid interleaved error output.
5. **JIRA failure must never block Git prep.** The branch setup is the primary deliverable.
6. **Always report results**, even on total failure. Include context-switch details when applicable.
7. **Use the exact branch naming convention**: `develop-{ISSUE_ID}`. Do not deviate.
8. **Confirm auto-detected projects with the user** before executing any Git commands.
9. **Always verify file existence** before attempting JIRA uploads.
10. **JSON-escape the comment body** meticulously --- unescaped newlines or quotes cause HTTP 400 errors.
11. **Use `X-Atlassian-Token: no-check`** on attachment uploads --- required by JIRA to bypass XSRF protection.

---

## JIRA REST API Reference

|| Action | Method | Endpoint | Expected Status |
||---|---|---|---|
|| Attach file | `POST` | `/rest/api/2/issue/{issueIdOrKey}/attachments` | 200 |
|| Add comment | `POST` | `/rest/api/2/issue/{issueIdOrKey}/comment` | 201 |
|| Get issue status | `GET` | `/rest/api/2/issue/{issueIdOrKey}?fields=status` | 200 |
|| Get transitions | `GET` | `/rest/api/2/issue/{issueIdOrKey}/transitions` | 200 |
|| Execute transition | `POST` | `/rest/api/2/issue/{issueIdOrKey}/transitions` | 204 |

**Base URL**: `https://jira.dell.com`
**Auth header**: `Authorization: Bearer <JIRA_PAT from local.config>`
**Attachment header**: `X-Atlassian-Token: no-check` (required for file uploads)

---

## Troubleshooting

|| Symptom | Likely Cause | Fix |
||---|---|---|
|| HTTP 401 on JIRA API | JIRA PAT invalid/expired | Verify `JIRA_PAT` in `local.config`. Regenerate from JIRA profile if needed. |
|| HTTP 403 on attachment upload | Lacks "Attach Files" permission | Check JIRA project permissions. |
|| HTTP 413 on attachment upload | File exceeds size limit | JIRA default is 10 MB. Markdown files should be well under this. |
|| XSRF error | Missing `X-Atlassian-Token: no-check` header | Ensure header is present on all attachment uploads. |
|| HTTP 400 on comment POST | Malformed JSON body | Use `jq` to safely JSON-encode the comment body. |
|| Comment renders incorrectly | Invalid JIRA wiki markup | Verify all macros are properly opened and closed. |
|| Git checkout fails | Unmerged files or dirty state | Run pre-flight checks first. Stash or skip dirty repos. |
|| Branch already exists | Prior prep run for same issue | Ask user: switch to existing or recreate. |
|| Auto-commit on context switch fails | Merge conflict or hook rejection | Report the error to the user and offer to stash instead. |
