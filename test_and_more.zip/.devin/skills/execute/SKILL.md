# Skill: execute

> Read an implementation plan and execute it end-to-end: implement code (TDD), verify builds, commit, update JIRA.

---

## Purpose

This workflow takes a JIRA issue ID, loads the corresponding implementation plan and feature spec from `ai/feature-specs/{ISSUE_ID}/`, and executes the entire plan from start to finish. It follows Test-Driven Development — writing unit tests first, then implementing the feature, verifying the build, committing with the correct message format, generating a change summary, and updating the JIRA ticket with structured results.

---

## Prerequisites

- `local.config` at workspace root contains `JIRA_PAT` for JIRA API access.
- Implementation plan exists at `ai/feature-specs/{ISSUE_ID}/implementation_plan.md`.
- Feature spec exists at `ai/feature-specs/{ISSUE_ID}/feature-spec.md`.
- Feature branches follow the naming convention `develop-{ISSUE_ID}` (e.g. `develop-SCLP-3394`).
- Each impacted git project has been checked out to the correct feature branch before starting.
- Maven is available for building (`mvn` for most projects, `./mvnw` for clip-client-java).

---

## Module-to-Project Mapping

| Maven Module Path | Git Project Directory | Build Command |
|---|---|---|
| `clip-product-instance/`, `clip-product-model/`, `clip-entitlement/`, `clip-app-service/`, `clip-offer/`, `clip-reservation/`, `clip-consumption/`, `clip-compliance/`, `clip-audit/`, `clip-common/` | `clip-app` | `mvn clean install` |
| `clip-integrations-*` modules | `clip-integrations` | `mvn clean install` |
| `clip-control-plane-*` modules | `clip-control-plane` | `mvn clean install` |
| `clip-app-query-*` modules | `clip-app-query` | `mvn clean install` |
| `clip-client-java` | `clip-client-java` | `./mvnw clean install` |
| `clip-delegated-server-*` modules | `clip-delegated-server` | `mvn clean install` |

---

## Workflow Steps

### Step 1 — Obtain JIRA Issue ID

Ask the user for the JIRA issue ID if not already provided (e.g. `SCLP-3394`). This ID drives every subsequent step — file paths, branch names, commit messages, and JIRA updates.

```
ISSUE_ID=SCLP-XXXX
```

### Step 2 — Load Implementation Plan

Read both plan files in full:

```
ai/feature-specs/{ISSUE_ID}/implementation_plan.md
ai/feature-specs/{ISSUE_ID}/feature-spec.md
```

**Extract and internalise ALL of the following before writing any code:**

| Item | What to extract |
|---|---|
| **Design Decisions** | Architecture choices, merge strategies, data flow, response-only vs persisted fields |
| **Files to Modify** | Every file listed with its full path, what to add/change, and where (line numbers if given) |
| **Files NOT to Modify** | Explicit exclusions — do NOT touch these files under any circumstance |
| **Implementation Order** | The exact sequence the plan prescribes (e.g. tests first, then validator, then service) |
| **Critical Constraints** | Reactive patterns (`Mono<T>`, no `.block()`), null-handling rules, merge semantics, response-only fields, signing order, event publishing |
| **Test Plan** | Unit test scenarios, E2E test scenarios, test helper methods to create |
| **Key Code References** | Files referenced for context (existing patterns, helper methods, related services) |

**Do NOT proceed until you have fully understood the plan.** If anything is ambiguous, ask the user before implementing.

### Step 3 — Verify Branch Readiness

For each git project that the plan impacts (use the module-to-project mapping above):

1. Navigate to the project directory.
2. Verify the current branch is `develop-{ISSUE_ID}`:

```bash
cd <project-dir>
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "develop-$ISSUE_ID" ]; then
    echo "ERROR: Expected branch develop-$ISSUE_ID but found $CURRENT_BRANCH"
    # STOP and ask the user — do NOT checkout automatically
fi
```

3. Verify clean working tree:

```bash
git status --porcelain
# If output is non-empty, STOP and ask the user whether to stash or proceed
```

4. Pull latest from remote:

```bash
git pull origin develop-$ISSUE_ID
```

If any project fails branch readiness, **STOP and report** — do not attempt to fix branch issues automatically.

### Step 4 — Read Existing Code

**This step is MANDATORY — do NOT skip it under any circumstance.**

Read ALL files systematically before writing a single line of code:

**4.1 — Files to Modify (from the plan)**
- Read each file end-to-end.
- Note actual line numbers for insertion points mentioned in the plan.
- Note imports, package declarations, class structure.
- Note coding patterns: indentation, naming conventions, Javadoc style, annotation usage.

**4.2 — Key Code References (from the plan)**
- Read every file referenced as context (e.g. existing service methods, mapper helpers, DTOs).
- Understand how similar features are implemented in the codebase.
- Note reactive chain patterns (`Mono.flatMap`, `Mono.zip`, error handling).

**4.3 — Existing Tests**
- Read the test class(es) that will be modified.
- Note test framework annotations (`@Test`, `@DisplayName`, `@ExtendWith`, `@MockBean`, etc.).
- Note test helper classes and factory methods.
- Note assertion style (AssertJ, JUnit, Reactor `StepVerifier`).
- Read E2E test classes if the plan includes E2E tests.

**4.4 — Related Project Specs (if referenced)**
- `ai/project-specs/flows/*.md` — registration logic flows
- `ai/project-specs/api-spec.md` — API contracts
- `ai/project-specs/data-model-spec.md` — entity schemas
- `ai/project-specs/technical-spec.md` — architecture patterns

### Step 5 — Execute Implementation Order

Follow the exact implementation order prescribed in the plan. For each item in the order:

#### Step 5.1 — Write Unit Tests First (TDD)

Write tests BEFORE writing the implementation code. This is non-negotiable.

1. **Create test helpers first** — factory methods for building test request/response DTOs, mock entities, etc. Add these to the existing test helper class (e.g. `ProductInstanceTestHelper.java`).

2. **Write test methods** matching the exact test scenarios from the plan:
   - Use the same framework annotations as existing tests (`@Test`, `@DisplayName`, etc.).
   - Use the same naming convention as existing tests (e.g. `methodName_scenario_expectedResult`).
   - Use the same assertion library (AssertJ `assertThat()`, Reactor `StepVerifier`, etc.).
   - Mock dependencies using the same patterns as existing tests (`when(...).thenReturn(...)`).
   - Each test should be focused on ONE scenario from the plan.

3. **Compile-check after each test file**:

```bash
cd <project-dir>
mvn compile -pl <module> -am
mvn test-compile -pl <module> -am
```

Tests are expected to FAIL at this point (no implementation yet) — but they must COMPILE.

#### Step 5.2 — Implement Feature

Make code changes exactly as prescribed in the implementation plan:

1. Follow the plan's file-by-file instructions.
2. **After modifying each file**, compile-check immediately:

```bash
mvn compile -pl <module> -am
```

3. **Match code style exactly:**
   - Same indentation (spaces vs tabs, indent width).
   - Same import ordering and grouping.
   - Same Javadoc and inline comment style.
   - Same logging patterns (`log.info()`, `log.debug()`, `log.error()`).
   - Same reactive chain style (line breaks, `.flatMap` vs `.map`, error handling).

4. **Follow critical constraints from the plan:**
   - All service methods return reactive types (`Mono<T>`, `Flux<T>`).
   - **Never use `.block()`** — this is a reactive application (Spring WebFlux).
   - Honour null-handling rules (three-way merge: null=remove, absent=preserve, non-null=overwrite).
   - Honour response-only fields (e.g. License Policy Thresholds injected AFTER DB save, NOT persisted).
   - Honour signing order (sign response AFTER all fields are populated).
   - Honour event publishing (Kafka outbox pattern for transaction events).

5. **Do NOT modify files listed in "Files NOT to Modify"** — even if it seems like a good idea. If a change seems necessary in an excluded file, STOP and ask the user.

#### Step 5.3 — Run Unit Tests

After implementation is complete, run unit tests for the impacted module:

```bash
cd <project-dir>
mvn test -pl <module> -am
```

**If tests fail:**

1. Read the full test output carefully.
2. **Distinguish between new test failures and regressions:**
   - New test failures (tests you just wrote) → fix the IMPLEMENTATION, not the tests.
   - Regression failures (pre-existing tests now failing) → you likely broke something — review your changes.
3. Fix the issue.
4. Re-run tests.
5. **Retry up to 3 times.** If still failing after 3 attempts, STOP and report the failure to the user with:
   - The exact test(s) failing
   - The error message / stack trace
   - What you've tried so far
   - Your hypothesis about the root cause

#### Step 5.4 — Write E2E Tests (if plan includes them)

If the implementation plan specifies E2E tests:

1. Read existing E2E test classes for patterns.
2. Write E2E tests using the same framework and conventions.
3. E2E tests typically hit the running application via HTTP — note the test infrastructure (e.g. `@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)`, `WebTestClient`).

If the plan does NOT include E2E tests, skip this step and note it in the change summary.

#### Step 5.5 — Run E2E Tests (if applicable)

```bash
cd <project-dir>
mvn verify -pl <module> -am
```

Apply the same failure handling as Step 5.3 (3 retries, then report).

#### Step 5.6 — Full Verification

Run full verification across each impacted project:

**Checkstyle:**
```bash
mvn checkstyle:check -pl <module> -am
```

**Full build (compile + test + package):**

```bash
# For clip-app, clip-integrations, clip-control-plane, clip-app-query:
cd <project-dir>
mvn clean install

# For clip-client-java:
cd clip-client-java
./mvnw clean install
```

**Full test suite** (to catch regressions across the entire project):
```bash
mvn test
```

All three checks must pass. If any fail, diagnose and fix before proceeding.

### Step 6 — Self-Review

Run `git diff` in each impacted project and review ALL changes:

```bash
cd <project-dir>
git diff
git diff --stat
```

**Check for:**

| Check | Action if Failed |
|---|---|
| **Unintended changes** — files modified that are NOT in the plan | Revert with `git checkout -- <file>` |
| **Missing changes** — files in the plan that were NOT modified | Implement the missing changes |
| **Style consistency** — formatting, imports, naming | Fix to match existing code style |
| **Constraint compliance** — no `.block()`, response-only fields not persisted, correct merge semantics | Fix violations |
| **Test coverage** — every scenario from the plan has a corresponding test | Add missing tests |
| **No secrets or credentials** — no PATs, passwords, or API keys in the diff | Remove immediately |
| **No debug code** — no `System.out.println`, no commented-out code, no TODO markers that weren't there before | Remove |

### Step 7 — Commit

After self-review passes, commit changes in each impacted project:

```bash
cd <project-dir>
git add -A
git commit -m "JIRA#${ISSUE_ID}; <concise description of changes>"
```

**Commit message format:**
- Must start with `JIRA#{ISSUE_ID};` — this is required by the GitLab pre-receive hook.
- Follow the semicolon with a space and a concise description.
- Example: `JIRA#SCLP-3394; Add additionalInfo-only update path for PUT /api/v1/clip/product`

**Do NOT push unless the user explicitly asks.** The commit stays local until the user confirms.

### Step 8 — Generate change-summary.md

Create the file `ai/feature-specs/{ISSUE_ID}/change-summary.md` with the following structure:

```markdown
# Change Summary — {ISSUE_ID}

- **JIRA Issue:** [ISSUE_ID](https://jira.dell.com/browse/{ISSUE_ID})
- **Branch:** `develop-{ISSUE_ID}`
- **Generated:** {YYYY-MM-DD}

---

## Overview

{One-paragraph description of what was implemented, the approach taken, and key design decisions.}

---

## Projects Impacted

| # | Project | Files Changed | Insertions | Deletions | Commits |
|---|---------|--------------|------------|-----------|---------|
| 1 | `clip-app` | N | +X | -Y | 1 |

---

## Files Modified

### `{project-name}`

| # | File | Change |
|---|------|--------|
| 1 | `FileName.java` | Description of what was added/modified |

---

## Tests

### Unit Tests

| # | Test Name | Scenario | Result |
|---|-----------|----------|--------|
| 1 | `testMethodName` | What the test verifies | Pass/Fail |

**Total:** X/Y passed

### E2E Tests

{Table of E2E tests or "No E2E tests added in this iteration."}

---

## Commits

| # | Project | Hash | Message |
|---|---------|------|---------|
| 1 | `clip-app` | `{short-hash}` | JIRA#{ISSUE_ID}; {description} |

---

## Verification

- **Compilation:** Clean / Failed
- **Unit tests:** X/Y passed
- **E2E tests:** X/Y passed / N/A
- **CheckStyle:** Clean / N/A
```

Get the commit hash with:

```bash
git log -1 --format="%h"
```

Get insertions/deletions with:

```bash
git diff --stat HEAD~1
```

### Step 9 — Commit `ai/` Repo Changes

The `ai/` directory is a separate Git repository. After generating the change-summary (and any other files written to `ai/` during this workflow — feature specs, LEARNINGS.md, etc.), commit those changes on the feature branch.

**9.1 — Sync workspace-level config files:**

If any workspace-level configuration files were modified during this session (CLAUDE.md, `.devin/skills/*`, `.windsurf/workflows/*`), copy them to the `ai` repo's mirror:

```bash
# Only needed if workspace-level files were actually modified
cp {WORKSPACE_ROOT}/CLAUDE.md {WORKSPACE_ROOT}/ai/do-not-use/CLAUDE.md
cp -r {WORKSPACE_ROOT}/.devin/skills/ {WORKSPACE_ROOT}/ai/do-not-use/.devin/skills/
cp -r {WORKSPACE_ROOT}/.windsurf/workflows/ {WORKSPACE_ROOT}/ai/do-not-use/.windsurf/workflows/
```

Skip this sub-step if no workspace-level config files were modified.

**9.2 — Stage and commit:**

```bash
cd {WORKSPACE_ROOT}/ai
git add -A
git status
```

If there are staged changes, commit them:

```bash
git commit -m "JIRA#${ISSUE_ID}; Update feature specs and change summary"
```

If there are no changes to commit, skip this step silently.

**Do NOT push** — the `ai` repo is pushed alongside other projects by the `git_push` workflow.

### Step 10 — Update JIRA

**10.1 — Read JIRA PAT:**

```bash
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
```

**10.2 — Post a structured comment to the JIRA issue:**

```bash
curl -s --request POST \
  --header "Authorization: Bearer $JIRA_PAT" \
  --header "Content-Type: application/json" \
  --data '{
    "body": "{panel:title=Implementation Complete|borderStyle=solid|borderColor=#14892c|titleBGColor=#d4f5d4|bgColor=#f5fff5}\n*Commit:* {{COMMIT_HASH}} on branch {{develop-ISSUE_ID}}\n\n*Files Modified:*\n||Project||File||Change||\n|clip-app|FileName.java|Description|\n\n*Unit Tests:*\n||Test||Scenario||Result||\n|testMethodName|What it verifies|(/) Pass|\n\n*Verification:*\n(/) Compilation clean\n(/) Unit tests: X/X passed\n(/) Full build: PASSED\n{panel}"
  }' \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/comment"
```

The comment uses JIRA wiki markup:
- `{panel}` — coloured panel with title
- `{{monospace}}` — for commit hashes, branch names
- `||header||` — table headers
- `|cell|` — table cells
- `(/)` — green check icon
- `(x)` — red X icon

**10.3 — Transition the issue to "In Development":**

First, get available transitions:

```bash
curl -s --header "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/transitions"
```

Find the transition ID for "In Development" (or the appropriate status), then:

```bash
curl -s --request POST \
  --header "Authorization: Bearer $JIRA_PAT" \
  --header "Content-Type: application/json" \
  --data '{"transition": {"id": "TRANSITION_ID"}}' \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/transitions"
```

**If the JIRA update fails, treat it as non-blocking** — report the failure but do not roll back code changes.

### Step 11 — Report Results

Present a final summary to the user:

```
=== execute Skill — Results for {ISSUE_ID} ===

Implementation Status: COMPLETE / PARTIAL / FAILED

Projects Impacted:
  - clip-app: 5 files modified, 6 tests written, build PASSED

Changes Made:
  1. RegistrationValidator.java — added isAdditionalInfoOnlyUpdate() detection method
  2. ProductInstanceService.java — added early-return branch for additional-info-only updates
  3. ProductInstanceMapperHelper.java — added mergeAdditionalInfo() and mergeMetaData()
  ...

Tests Written:
  Unit Tests: 6/6 passed
    1. updateProductInstance_additionalInfoOnly_success
    2. updateProductInstance_additionalInfoOnly_explicitNullRemovesKey
    ...
  E2E Tests: N/A

Verification:
  - Compilation: CLEAN
  - Unit Tests: ALL PASSED
  - Full Build: PASSED
  - CheckStyle: CLEAN

Commit:
  - clip-app: abc1234 — JIRA#SCLP-3394; Add additionalInfo-only update path

Next Steps:
  - Review the diff: `cd clip-app && git diff HEAD~1`
  - Push when ready: `cd clip-app && git push origin develop-SCLP-3394`
  - Change summary: ai/feature-specs/SCLP-3394/change-summary.md

JIRA Update: SUCCESS — comment posted, status → In Development
```

---

## Error Recovery

| Error | Recovery Strategy |
|---|---|
| **Compilation error loop** | Fix and retry up to 3 attempts. If still failing after 3 attempts, STOP and present the error to the user with full context. Do NOT keep looping. |
| **Test failure loop** | Add targeted logging (`log.debug`) to narrow the issue. Distinguish new failures from regressions. Fix implementation, not tests. Retry up to 3 attempts, then STOP and report. |
| **Scope creep** | If the implementation requires changes to files NOT in the plan, or the plan seems incomplete, STOP immediately and ask the user. Do NOT make unplanned changes. |
| **Missing dependency** | If a class, method, or module referenced in the plan doesn't exist, search the codebase first (`grep`, `find`). If genuinely missing, STOP and ask the user. |
| **Merge conflict** | If `git pull` produces merge conflicts, STOP and report the conflicting files. Do NOT attempt automatic resolution. |
| **JIRA API failure** | Treat as non-blocking. Report the failure (HTTP status, response body) but do NOT roll back code changes. The user can update JIRA manually. |
| **Build timeout** | If `mvn clean install` runs for more than 10 minutes without progress, check for hung tests or infinite loops. Report to the user. |

---

## Build Commands Reference

| Project | Directory | Build Command | Notes |
|---|---|---|---|
| `clip-app` | `clip-app/` | `mvn clean install` | Multi-module Maven project |
| `clip-integrations` | `clip-integrations/` | `mvn clean install` | Multi-module Maven project |
| `clip-control-plane` | `clip-control-plane/` | `mvn clean install` | Multi-module Maven project |
| `clip-app-query` | `clip-app-query/` | `mvn clean install` | Multi-module Maven project |
| `clip-client-java` | `clip-client-java/` | `./mvnw clean install` | Uses Maven wrapper (bundled `mvnw`) |
| `clip-delegated-server` | `clip-delegated-server/` | `mvn clean install` | Multi-module Maven project |

**Single-module test (faster feedback):**
```bash
mvn test -pl <module-name> -am
```

**Compile-only check (fastest feedback):**
```bash
mvn compile -pl <module-name> -am
mvn test-compile -pl <module-name> -am
```

---

## Important Rules

1. **TDD is mandatory.** Write tests BEFORE implementation. Tests must compile (but are expected to fail) before you write the feature code.
2. **Never use `.block()`.** This is a fully reactive Spring WebFlux application. All service methods must return `Mono<T>` or `Flux<T>`.
3. **Read before writing.** Step 4 (Read Existing Code) is not optional. You must read every file before modifying it.
4. **Follow the plan exactly.** Do not add features, refactor unrelated code, or "improve" things not in scope.
5. **Do not modify excluded files.** If the plan says "Files NOT to Modify", those files are off-limits.
6. **Commit message format is enforced.** The GitLab pre-receive hook requires `JIRA#{ISSUE_ID};` at the start.
7. **Do not push unless asked.** The commit stays local until the user explicitly requests a push.
8. **Fix implementation, not tests.** If TDD tests fail after implementation, the implementation is wrong — not the tests.
9. **Preserve existing code style.** Match indentation, imports, naming, Javadoc, and reactive chain patterns exactly.
10. **JIRA failures are non-blocking.** Never roll back code changes because of a JIRA API error.

---

## JIRA API Reference

| Action | Method | Endpoint |
|---|---|---|
| Get issue details | `GET` | `/rest/api/2/issue/{ISSUE_ID}` |
| Post comment | `POST` | `/rest/api/2/issue/{ISSUE_ID}/comment` |
| Get transitions | `GET` | `/rest/api/2/issue/{ISSUE_ID}/transitions` |
| Transition issue | `POST` | `/rest/api/2/issue/{ISSUE_ID}/transitions` |

**Base URL:** `https://jira.dell.com`
**Auth header:** `Authorization: Bearer <JIRA_PAT from local.config>`
