# Skill: sdlc

> End-to-end SDLC orchestrator — takes a JIRA ID and autonomously drives a feature from analysis through implementation, code review, and closure.

---

## Purpose

This is the **master orchestrator** skill for the CLIP platform. Given a single JIRA issue ID, it executes the complete Software Development Lifecycle autonomously:

1. Analyses the project and feature requirements
2. Creates detailed specs and implementation plans
3. Implements the code changes following TDD
4. Pushes code and creates Merge Requests
5. Addresses MR review comments
6. Closes the feature and updates JIRA

The entire flow runs as a single continuous agent session with only **3 user checkpoints** where human input is required. Between checkpoints, the agent operates fully autonomously.

---

## User Checkpoints

| # | When | What the user does | What happens next |
|---|------|-------------------|-------------------|
| **1** | After feature spec is generated | Review `feature-spec.md`, answer open questions (section 4.9), iterate until requirements are clear | Agent proceeds to create implementation plan |
| **2** | After implementation plan is generated | Review `implementation_plan.md`, iterate until the plan is perfect — discuss design decisions, file choices, test strategy | Agent proceeds to prep branches, implement, push, and create MRs |
| **3** | After MRs are created and human reviewer adds comments to the MR diffs | Add review comments on the actual code diffs in GitLab MR UI for final optimization | Agent fixes accepted comments, replies to rejected ones, pushes updates |

Between these checkpoints, everything runs autonomously — JIRA updates, Git operations, builds, tests, commits, pushes, MR creation, and cleanup.

---

## Prerequisites

- `local.config` at workspace root with `JIRA_PAT` and `GIT_PAT`
- JIRA issue exists with summary, description, and acceptance criteria
- Project specs exist at `ai/project-specs/` (if not, the orchestrator runs `create_project_specs` first)
- Maven and Git are available on the system PATH
- Network access to `jira.dell.com` and `gitlab.dell.com`

---

## Orchestration Flow

```
Input: JIRA Issue ID (e.g. SCLP-3394)

Phase 1: ANALYSIS (autonomous)
  |
  +--> Step 1: Verify project specs exist
  +--> Step 2: Fetch JIRA issue
  +--> Step 3: Generate feature spec
  |
  === CHECKPOINT 1: User reviews feature spec ===
  |
Phase 2: PLANNING (autonomous)
  |
  +--> Step 4: Generate implementation plan
  |
  === CHECKPOINT 2: User reviews implementation plan ===
  |
Phase 3: EXECUTION (autonomous)
  |
  +--> Step 5: Prepare (attach specs to JIRA, prep Git branches, transition to In Development)
  +--> Step 6: Execute implementation (TDD)
  +--> Step 7: Test (pre-push quality gate — full test suite across all impacted projects)
  +--> Step 8: Push & create MRs
  |
  === CHECKPOINT 3: Human reviewer adds MR comments ===
  |
Phase 4: REVIEW & CLOSE (autonomous)
  |
  +--> Step 9: Fix MR review comments
  +--> Step 10: Wait for MR merge approval
  +--> Step 11: Close & clean up
  |
  Done.
```

---

## Workflow Steps

### Step 1 — Verify Project Specs

Check if `ai/project-specs/` exists and contains the core spec files:
- `functional-spec.md`
- `technical-spec.md`
- `data-model-spec.md`
- `api-spec.md`

If any are missing, run the `create_project_specs` skill first (see `.devin/skills/create_project_specs/SKILL.md`). This is a one-time setup step.

If specs exist, load them into context for use throughout the flow.

---

### Step 2 — Fetch JIRA Issue & Validate

Load credentials from `local.config` at the workspace root:
```bash
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
GIT_PAT=$(grep GIT_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
```

Fetch the JIRA issue to validate it exists and has sufficient content:

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=summary,description,issuetype,priority,status,labels,components,customfield_10208,issuelinks"
```

Validate:
- Issue exists (not 404)
- Has a description (not empty)
- Has acceptance criteria (`customfield_10208`) or description contains testable requirements

If the issue lacks sufficient detail, report what's missing and ask the user to update the JIRA issue before continuing.

Log the current JIRA status for tracking throughout the flow.

---

### Step 3 — Generate Feature Spec

Execute the `create_feature_specs` skill (see `.devin/skills/create_feature_specs/SKILL.md`):

1. Use the JIRA data fetched in Step 2 (no need to re-fetch)
2. Load project specs from `ai/project-specs/`
3. Analyse the codebase for context
4. Generate `ai/feature-specs/{ISSUE_ID}/feature-spec.md`

After generation, present the feature spec to the user with a clear summary:

```
=== CHECKPOINT 1: Feature Spec Review ===

Feature spec generated: ai/feature-specs/{ISSUE_ID}/feature-spec.md

Summary:
- {N} Functional Requirements (FR-01 through FR-{N})
- {N} Acceptance Criteria
- Impacted areas: {list of modules/files}

Open Questions (need your input):
- Q1: {question text}
- Q2: {question text}

Please review the feature spec and:
1. Answer the open questions above
2. Confirm the requirements are correct and complete
3. Flag anything that needs changes

Reply when ready to proceed to implementation planning.
```

**WAIT for user response.** Iterate on the feature spec based on feedback:
- If the user answers open questions, update section 4.9
- If the user requests changes, regenerate affected sections
- If the user adds requirements, add new FR entries
- Continue until the user confirms the spec is ready

---

### Step 4 — Generate Implementation Plan

Execute the `create_implementation_plan` skill (see `.devin/skills/create_implementation_plan/SKILL.md`):

1. Read the approved feature spec
2. Load project context (CLAUDE.md, project specs)
3. Deep-dive codebase analysis (trace entry points, analyse logic, DTOs, cross-cutting concerns, test infrastructure)
4. Generate `ai/feature-specs/{ISSUE_ID}/implementation_plan.md`

Present the plan to the user:

```
=== CHECKPOINT 2: Implementation Plan Review ===

Implementation plan generated: ai/feature-specs/{ISSUE_ID}/implementation_plan.md

Summary:
- Files to modify: {N}
- Files NOT to modify: {list}
- Unit tests to write: {N}
- E2E tests to write: {N}

Open Questions (resolve before coding):
- {list any discrepancies found}

Key Design Decisions:
- {summarize major decisions}

Please review the implementation plan and:
1. Resolve any open questions
2. Confirm the file changes are correct
3. Confirm the test strategy
4. Flag any design decisions you want to change

Reply when ready to proceed to implementation.
```

**WAIT for user response.** Iterate on the plan:
- If the user questions a design decision, discuss alternatives and update
- If the user wants different files modified, adjust the plan
- If the user wants more/fewer tests, adjust
- Continue until the user says the plan is perfect

---

### Step 5 — Prepare (autonomous)

Execute the `prepare` skill (see `.devin/skills/prepare/SKILL.md`):

1. Verify `feature-spec.md` and `implementation_plan.md` exist locally
2. Attach both specs to the JIRA issue as attachments
3. Post a structured summary comment in JIRA wiki markup
4. Auto-detect impacted projects from the implementation plan
5. For each project: checkout develop, pull latest, create `develop-{ISSUE_ID}`
6. Transition JIRA to "In Development"

The agent auto-detects projects from the plan's "Files to Modify" section — no user input needed. If all projects are clean, proceed silently. Only stop if there are uncommitted changes (stash them automatically).

Report the prep results table and continue.

---

### Step 6 — Execute Implementation (autonomous)

Execute the `execute` skill (see `.devin/skills/execute/SKILL.md`):

1. Read all files in the plan before writing any code
2. Follow TDD: write unit tests first, then implement, then verify
3. Run full unit tests — must pass
4. Write E2E tests if specified in the plan
5. Run E2E tests if applicable
6. Self-review all changes
7. Commit with `JIRA#{ISSUE_ID}; {description}` format
8. Generate `change-summary.md`
9. Post implementation summary comment to JIRA
10. Transition JIRA to "In Development"

This is the largest step. Follow the implementation plan exactly. If stuck:
- Compilation errors: retry up to 3 times, then ask user
- Test failures: add logging, diagnose, fix implementation (not tests)
- Scope creep: stop if a change requires modifying "Files NOT to Modify"

Report results and continue.

---

### Step 7 — Test (autonomous)

Execute the `test` skill (see `.devin/skills/test/SKILL.md`):

1. Identify all projects on the `develop-{ISSUE_ID}` branch
2. Load test commands from the **Test Commands Reference** table in `CLAUDE.md`
3. Run full unit tests for each impacted project
4. Run lint/static analysis if configured
5. Run E2E tests if the implementation plan specifies them

**All unit tests must pass before proceeding to push.** If any test fails:
- Read the failure output and identify the root cause
- If the failure is in newly written code, fix the implementation (not the tests)
- Retry up to 3 times
- If still failing after 3 attempts, stop and report to the user with the failing test names, errors, and a root cause hypothesis

Report the test results table and continue only if all unit tests pass.

---

### Step 8 — Push & Create MRs (autonomous)

Execute the `git_push` skill (see `.devin/skills/git_push/SKILL.md`):

1. Push all impacted projects to origin
2. Create MRs targeting `develop` (NEVER `main`)
3. Generate `merge-requests.md`

Report MR URLs and inform the user:

```
=== MRs Created — Ready for Review ===

| # | Project | MR | URL |
|---|---------|-----|-----|
| 1 | clip-app | !{iid} | {url} |

Please review the code diffs in GitLab and add your review comments.

=== CHECKPOINT 3: Waiting for MR Review Comments ===

When you've finished adding review comments to the MR(s), reply here and I'll
address them — implementing accepted suggestions and replying to any I disagree with.
```

**WAIT for user response.** The user should:
1. Open the MR URL(s) in GitLab
2. Review the actual code diffs
3. Add inline comments on specific lines or general comments
4. Come back and tell the agent to proceed

---

### Step 9 — Fix MR Review Comments (autonomous)

Execute the `git_fix_comments` skill (see `.devin/skills/git_fix_comments/SKILL.md`):

1. Fetch all unresolved MR discussions from GitLab
2. Filter to actionable comments (ignore bots, system notes, resolved threads)
3. Analyse each comment against the code, specs, and feature requirements
4. For each comment, decide: Accept / Reject / Escalate
5. Present the analysis summary (this is informational — no user gate since Checkpoint 3 already happened)
6. Make code changes for accepted comments
7. Build with full unit tests — must pass
8. Commit and push with `JIRA#{ISSUE_ID}; Fix MR review comments`
9. Reply to each discussion on GitLab (fix confirmation for accepted, reasoning for rejected)
10. Resolve accepted discussions

If there are escalated comments (large architectural changes), flag them for the user but continue with the rest.

Report results. If the reviewer adds more comments after this round, the user can trigger this step again.

---

### Step 10 — Wait for MR Merge (user-driven)

After MR comments are addressed, the MR needs to be approved and merged by a human reviewer in GitLab. This is outside the agent's control.

Inform the user:

```
=== Waiting for MR Merge ===

All review comments have been addressed. Next steps:
1. Reviewer approves the MR(s) in GitLab
2. Reviewer (or you) merges the MR(s) to develop
3. Once merged, reply here and I'll clean up

MR URLs:
{list MR URLs from merge-requests.md}
```

**WAIT for user to confirm MRs are merged.**

---

### Step 11 — Wrap Up (autonomous)

Execute the `wrap_up` skill (see `.devin/skills/wrap_up/SKILL.md`):

1. Verify all MRs are merged (abort if any are still open)
2. Delete local and remote feature branches
3. Switch all projects back to `develop` and pull latest
4. Post a coding summary comment to JIRA (feature complete panel with MRs, files, tests, commits)
5. Transition JIRA to "Complete"
6. Update per-project functional modification history (`ai/project-history/{project}.md`)

Report final results:

```
=== SDLC Complete for {ISSUE_ID} ===

Feature: {summary}
Status: Complete

Branch cleanup: All feature branches deleted
JIRA: Transitioned to Complete
MRs: All merged to develop
Project history: Updated for N project(s)

Artifacts retained:
- ai/feature-specs/{ISSUE_ID}/feature-spec.md
- ai/feature-specs/{ISSUE_ID}/implementation_plan.md
- ai/feature-specs/{ISSUE_ID}/change-summary.md
- ai/feature-specs/{ISSUE_ID}/merge-requests.md
- ai/project-history/{project}.md (per impacted project)
```

---

## Important Rules

1. **Only 3 user checkpoints.** Between checkpoints, operate fully autonomously. Do not ask for confirmation on individual steps.
2. **Always update JIRA.** Post comments at key milestones (specs attached, implementation complete, feature complete). Transition status appropriately.
3. **Always update Git.** Commit with `JIRA#{ISSUE_ID}; {description}` format. Never force-push. Always target `develop` for MRs.
4. **Build must pass before push.** Never push code that doesn't compile or pass unit tests.
5. **Follow the implementation plan exactly.** Do not modify files listed in "Files NOT to Modify".
6. **TDD is mandatory.** Write tests before implementation.
7. **Preserve code style.** Read surrounding code before editing. Do not add/remove comments unless specified.
8. **Handle errors gracefully.** JIRA/GitLab API failures are non-blocking — report and continue. Build/test failures must be fixed before proceeding.
9. **Generate artifacts.** Ensure `feature-spec.md`, `implementation_plan.md`, `change-summary.md`, and `merge-requests.md` are all created in `ai/feature-specs/{ISSUE_ID}/`.
10. **If project specs don't exist**, run `create_project_specs` as step 0 before starting the feature flow.

---

## JIRA Status Transitions

| Phase | JIRA Status |
|-------|-------------|
| Start | Proposed |
| After feature spec (Step 3) | Defining Details |
| After implementation plan (Step 4) | Waiting for Dev |
| After prepare (Step 5) | In Development |
| After MRs merged & closed (Step 11) | Complete |

---

## Skill References

| Skill | Path | Used in Step |
|-------|------|-------------|
| `create_project_specs` | `.devin/skills/create_project_specs/SKILL.md` | Step 1 (if needed) |
| `create_feature_specs` | `.devin/skills/create_feature_specs/SKILL.md` | Step 3 |
| `create_implementation_plan` | `.devin/skills/create_implementation_plan/SKILL.md` | Step 4 |
| `prepare` | `.devin/skills/prepare/SKILL.md` | Step 5 |
| `execute` | `.devin/skills/execute/SKILL.md` | Step 6 |
| `test` | `.devin/skills/test/SKILL.md` | Step 7 |
| `git_push` | `.devin/skills/git_push/SKILL.md` | Step 8 |
| `git_fix_comments` | `.devin/skills/git_fix_comments/SKILL.md` | Step 9 |
| `wrap_up` | `.devin/skills/wrap_up/SKILL.md` | Step 11 |

---

## Quick Start

```
User: Run the SDLC workflow for SCLP-3394

Agent: Starting SDLC orchestration for SCLP-3394...
       [Step 1] Project specs found at ai/project-specs/
       [Step 2] JIRA issue fetched: "Add additionalInfo-only update path"
       [Step 3] Feature spec generated...

       === CHECKPOINT 1: Please review the feature spec ===
       ...
```
