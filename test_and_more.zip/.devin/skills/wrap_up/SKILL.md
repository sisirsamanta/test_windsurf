# Skill: wrap_up

> Clean up feature branches after all MRs are merged, update per-project functional history, publish a Confluence summary page, post a coding summary to JIRA, and transition the issue to Complete.

---

## Purpose

This workflow performs post-merge wrap-up for a JIRA feature issue. It verifies that all Merge Requests across impacted CLIP projects have been merged, deletes the corresponding feature branches (local and remote), appends per-project entries to the functional modification history (`ai/project-history/`), publishes a detailed Confluence summary page under a configurable parent, posts a comprehensive coding summary comment to the JIRA issue in wiki markup, and transitions the issue to "Complete" or "Done".

**This skill does NOT merge anything.** All MRs must already be in the `merged` state before running this workflow. If any MR is still open, the workflow stops immediately.

---

## Prerequisites

- `local.config` at workspace root contains `JIRA_PAT` and `GIT_PAT`:
  ```
  JIRA_PAT=<Base64-encoded JIRA personal access token>
  GIT_PAT=<GitLab personal access token (glpat-...)>
  ```
- **Optional**: `local.config` may also contain Confluence credentials for publishing a summary page:
  ```
  CONFLUENCE_PAT=<Base64-encoded Confluence personal access token>
  CONFLUENCE_PARENT=<Full URL of the parent Confluence page>
  ```
  If either `CONFLUENCE_PAT` or `CONFLUENCE_PARENT` is missing, empty, or invalid, the Confluence step is silently skipped.
- Each git project has an `origin` remote pointing to `gitlab.dell.com`.
- Feature branches follow the naming convention `develop-SCLP-XXXX` (where `SCLP-XXXX` is the JIRA issue ID).
- All Merge Requests for the feature must already be merged into `develop`.
- The JIRA issue exists and is accessible with the configured `JIRA_PAT`.

---

## Workflow Steps

### Step 1 — Obtain JIRA Issue ID

Determine the JIRA issue ID (`SCLP-XXXX`) for this feature. Sources (in priority order):

1. The user provides it directly (e.g., "wrap up SCLP-1234").
2. Detect from the current branch name: `git branch --show-current` → `develop-SCLP-1234` → extract `SCLP-1234`.
3. Prompt the user if it cannot be determined.

Store as `ISSUE_ID` (e.g., `SCLP-1234`). The feature branch name pattern is `develop-{ISSUE_ID}` (e.g., `develop-SCLP-1234`).

---

### Step 2 — Load Authentication

Read credentials from the workspace-root `local.config` file:

```bash
WORKSPACE_ROOT="C:/Users/Karan_K/Workspaces/cloud-licensing"
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
GIT_PAT=$(grep GIT_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
CONFLUENCE_PAT=$(grep CONFLUENCE_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
CONFLUENCE_PARENT=$(grep CONFLUENCE_PARENT "$WORKSPACE_ROOT/local.config" | cut -d= -f2-)
```

**JIRA API auth** uses the PAT as a Bearer token:
```
Authorization: Bearer $JIRA_PAT
```

**GitLab API auth** uses the PAT as a private token header:
```
PRIVATE-TOKEN: $GIT_PAT
```

**Confluence API auth** uses the PAT as a Bearer token:
```
Authorization: Bearer $CONFLUENCE_PAT
```

**Base URLs:**
- JIRA: `https://jira.dell.com`
- GitLab: `https://gitlab.dell.com/api/v4`
- Confluence: `https://confluence.dell.com` (REST API at `/rest/api/content`)

---

### Step 3 — Verify All MRs Are Merged

Before deleting any branches, verify that every project's MR for this feature is safely merged. **Do NOT proceed if any MR is still open.**

**Git projects to check** (each is a separate git repo under the workspace):

|| Project | GitLab Path (URL-encoded for API) |
||---|---|
|| `clip-app` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app` |
|| `clip-integrations` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-integrations` |
|| `clip-control-plane` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-control-plane` |
|| `clip-app-query` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app-query` |
|| `clip-client-java` | `globalops%2FBPM%2FDF%2Fclp%2Fclp-active%2Fclip-client-java` |
|| `clip-delegated-server` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-delegated-server` |
|| `ai` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fai` |

**For each project directory:**

#### 3.1 — Check if the remote feature branch exists

```bash
cd <project-dir>
git fetch origin
git branch -r --list "origin/develop-${ISSUE_ID}"
```

If the command returns output, the remote branch exists. If empty, the remote branch does not exist.

#### 3.2 — Check if a local feature branch exists

```bash
git branch --list "develop-${ISSUE_ID}"
```

#### 3.3 — Check MR status via GitLab API

Query for **merged** MRs:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<ENCODED_PATH>/merge_requests?source_branch=develop-${ISSUE_ID}&target_branch=develop&state=merged"
```

Query for **opened** MRs:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<ENCODED_PATH>/merge_requests?source_branch=develop-${ISSUE_ID}&target_branch=develop&state=opened"
```

#### 3.4 — Classify each project

|| Remote branch? | MR state | Local branch? | Classification | Action |
||---|---|---|---|---|
|| Yes/No | `merged` | Yes/No | **Safe** | Proceed with branch deletion |
|| Yes/No | `opened` | Yes/No | **STOP** | Halt entire workflow — MR must be merged first |
|| Yes | No MR found | Yes/No | **Warn** | Remote branch exists but no MR — ask user to confirm deletion |
|| No | No MR found | Yes | **Safe** | Only local branch remains — safe to delete |
|| No | No MR found | No | **Skip** | No involvement with this feature — nothing to do |

#### 3.5 — Present summary for confirmation

Display a table summarizing all projects:

```
=== MR Verification Summary for {ISSUE_ID} ===

|| Project              | Remote Branch | Local Branch | MR Status | Classification |
||----------------------|---------------|--------------|-----------|----------------|
|| clip-app             | YES           | YES          | merged    | Safe           |
|| clip-integrations    | YES           | YES          | merged    | Safe           |
|| clip-control-plane   | NO            | NO           | —         | Skip           |
|| clip-app-query       | NO            | YES          | —         | Safe           |
|| clip-client-java     | NO            | NO           | —         | Skip           |
|| clip-delegated-server| NO            | NO           | —         | Skip           |
```

**If any project has classification = STOP**, halt the entire workflow and report which MRs are still open. Do NOT delete any branches.

**If any project has classification = Warn**, present the warning and ask the user to confirm before proceeding.

---

### Step 4 — Delete Feature Branches

For each project classified as **Safe** or **Warn (confirmed)**, perform branch cleanup:

#### 4.1 — Switch to develop

```bash
cd <project-dir>
git checkout develop && git pull origin develop
```

**Error handling:** If `git checkout develop` fails (e.g., uncommitted changes):
```bash
git fetch origin develop
git checkout -f develop
git reset --hard origin/develop
```

#### 4.2 — Delete local feature branch

```bash
git branch -D develop-${ISSUE_ID}
```

**Error handling:**
- If the branch does not exist locally, that's fine — skip.
- If `-D` fails because it's "not fully merged" — this should NOT happen since we verified the MR is merged. **STOP and report** this anomaly. Do not force-delete without investigation.

#### 4.3 — Delete remote feature branch (if it exists)

```bash
git push origin --delete develop-${ISSUE_ID}
```

**Error handling:**
- If the remote branch was already deleted (error: `remote ref does not exist`) — that's fine, continue.
- If there's a permission error (403) — report the failure but continue with other projects. The user may need to delete it manually via GitLab UI.

#### 4.4 — Prune stale remote-tracking references

```bash
git fetch --prune
```

This removes any remaining `origin/develop-{ISSUE_ID}` remote-tracking references.

---

### Step 5 — Gather Coding Summary

Collect information for the JIRA summary comment from multiple sources:

#### 5.1 — Feature specification

If a feature spec exists at `ai/feature-specs/{ISSUE_ID}/feature-spec.md`, read it to extract:
- Feature title / description
- Key requirements implemented

#### 5.2 — Implementation plan

If an implementation plan exists at `ai/feature-specs/{ISSUE_ID}/implementation-plan.md`, read it to extract:
- Approach taken
- Components modified

#### 5.3 — Git log for commits

For each project that had a merged MR, collect commits referencing this issue:

```bash
cd <project-dir>
git fetch origin develop
git log origin/develop --oneline --grep="JIRA#${ISSUE_ID}"
```

Also try alternative patterns:
```bash
git log origin/develop --oneline --grep="${ISSUE_ID}"
```

Record: commit hash, one-line message, author, date.

#### 5.4 — GitLab MR details

For each merged MR, fetch full details:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<ENCODED_PATH>/merge_requests?source_branch=develop-${ISSUE_ID}&target_branch=develop&state=merged"
```

Extract per MR:
- MR IID and title
- MR web URL
- Author
- Merge date (`merged_at`)
- Number of changes (files modified)

Fetch MR changes to get the list of files modified:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<ENCODED_PATH>/merge_requests/<MR_IID>/changes"
```

Extract from `changes[]`:
- File paths (`new_path`)
- Change type (added, modified, deleted — infer from `new_file`, `deleted_file`, `renamed_file` flags)

#### 5.5 — Test information

Note any test classes added or modified from the MR changes list (files matching `*Test.java`, `*Tests.java`, `*Spec.java`, `*IT.java`).

---

### Step 6 — Post Summary Comment to JIRA

Compose a JIRA comment in **wiki markup** and post it to the issue.

#### 6.1 — Wiki markup template

```
{panel:title=Feature Complete — {ISSUE_ID}|borderStyle=solid|borderColor=#00875a|titleBGColor=#00875a|titleColor=#ffffff|bgColor=#f0fff0}

h3. Summary

{summary_text}

h3. Merge Requests

|||Project||MR||Title||Author||Merged||Files Changed||
||{project_1}|[!{mr_iid_1}|{mr_url_1}]|{mr_title_1}|{mr_author_1}|{merged_date_1}|{file_count_1}|
||{project_2}|[!{mr_iid_2}|{mr_url_2}]|{mr_title_2}|{mr_author_2}|{merged_date_2}|{file_count_2}|

h3. Files Modified

|||Project||File||Change Type||
||{project}|{{file_path_1}}|Modified|
||{project}|{{file_path_2}}|Added|
||{project}|{{file_path_3}}|Deleted|

h3. Tests

|||Project||Test Class||Type||
||{project}|{{TestClassName1}}|Unit|
||{project}|{{TestClassName2}}|Integration|

h3. Commits

|||Project||Hash||Message||
||{project_1}|{{abc1234}}|{commit_message_1}|
||{project_1}|{{def5678}}|{commit_message_2}|
||{project_2}|{{ghi9012}}|{commit_message_3}|

h3. Artifacts Retained

* Feature spec: {{ai/feature-specs/{ISSUE_ID}/feature-spec.md}}
* Implementation plan: {{ai/feature-specs/{ISSUE_ID}/implementation-plan.md}}
* Session logs retained in {{.devin/}} workspace directory

{panel}
```

**Substitution rules:**
- `{summary_text}` — 2–4 sentence summary of what was implemented, derived from the feature spec and MR titles.
- `{mr_url_N}` — Full GitLab web URL for the MR (e.g., `https://gitlab.dell.com/infrastructure/ase/dlf/cloud-licensing-solution/clip-app/-/merge_requests/1264`).
- `{merged_date_N}` — Format as `YYYY-MM-DD`.
- `{file_count_N}` — Number of files in the MR's `changes[]` array.
- Test type: infer `Integration` if file name contains `IT`, otherwise `Unit`.

#### 6.2 — Post the comment

```bash
curl -s --request POST \
  --header "Authorization: Bearer $JIRA_PAT" \
  --header "Content-Type: application/json" \
  --data '{
    "body": "<wiki_markup_content_escaped_for_json>"
  }' \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/comment"
```

**Error handling:**
- `200`/`201` — Success.
- `401`/`403` — Authentication failure. Report but do NOT fail the workflow. Branch cleanup is already done.
- `404` — Issue not found. Report.
- Network error — Report but do NOT fail the workflow.

#### 6.3 — Add `AI-Delivered` label

Add a static label `AI-Delivered` to the JIRA issue so AI-delivered work can be tracked for reporting purposes.

```bash
curl -s --request PUT \
  --header "Authorization: Bearer $JIRA_PAT" \
  --header "Content-Type: application/json" \
  --data '{
    "update": {
      "labels": [{"add": "AI-Delivered"}]
    }
  }' \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}"
```

This uses the JIRA `update` field operation to **add** the label without removing any existing labels on the issue.

**Error handling:**
- `204` — Success (no content).
- `200` — Success.
- `401`/`403` — Authentication failure. Report but do NOT fail the workflow.
- `404` — Issue not found. Report.
- Network error — Report but do NOT fail the workflow.

**JIRA failure is NOT a workflow failure.** The primary goal (branch cleanup) has already been achieved by this point.

---

### Step 7 — Transition JIRA to Complete

Move the JIRA issue to the "Complete" (or "Done") status.

#### 7.1 — Fetch current issue status

```bash
curl -s --header "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}?fields=status"
```

Check `fields.status.name`. If already "Complete" or "Done", skip the transition.

#### 7.2 — Get available transitions

```bash
curl -s --header "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/transitions"
```

Parse the `transitions[]` array. Find a transition where `name` matches (case-insensitive):
- `"Complete"`
- `"Done"`
- `"Close"`
- `"Resolve"`

Record the `transition.id`.

#### 7.3 — Execute the transition

```bash
curl -s --request POST \
  --header "Authorization: Bearer $JIRA_PAT" \
  --header "Content-Type: application/json" \
  --data '{
    "transition": {
      "id": "<TRANSITION_ID>"
    }
  }' \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}/transitions"
```

**Error handling:**
- `204` — Success (no content).
- `401`/`403` — Permission denied. Report: "Could not transition {ISSUE_ID} — insufficient permissions. Please transition manually."
- No matching transition found — Report: "No 'Complete' or 'Done' transition available from current status '{current_status}'. Please transition manually."
- Network error — Report but do NOT fail the workflow.

**JIRA failure is NOT a workflow failure.** Branch cleanup has already been completed successfully.

---

### Step 8 — Update Per-Project Functional Modification History

Append a reverse-chronological entry to the functional modification history file for each project that had a merged MR in this feature. This provides a durable, human- and AI-readable changelog per project.

#### 8.1 — Directory and file structure

History files live at:

```
ai/project-history/
├── clip-app.md
├── clip-integrations.md
├── clip-control-plane.md
├── clip-app-query.md
├── clip-client-java.md
└── clip-client-c.md
```

Each file corresponds to one Git project. If the directory or file does not exist, create it.

#### 8.2 — Determine issue type

Fetch the JIRA issue type if not already known:

```bash
curl -s --header "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/${ISSUE_ID}?fields=issuetype,summary"
```

Map `fields.issuetype.name` to the entry type:
- `Story`, `Feature`, `Enhancement` → **Feature**
- `Bug`, `Defect` → **Defect**
- `Task`, `Sub-task`, `Config Change` → **Task**
- Anything else → use the raw issue type name

#### 8.3 — Gather entry data (from Step 5 outputs)

For each project with a merged MR, collect:
- **Date**: Use the MR `merged_at` date, formatted as `YYYY-MM-DD`.
- **ISSUE_ID**: The JIRA issue ID (e.g., `SCLP-3394`).
- **Title**: The JIRA issue summary (e.g., "Additional Info Only Update Registration").
- **Type**: From Step 8.2 above.
- **Modules affected**: Infer from the MR file paths — extract the Maven module name from the path (e.g., `clip-product-instance/src/...` → `clip-product-instance`). List unique modules.
- **Files modified**: List the key source files changed (from Step 5.4 MR changes), excluding test files. Use just the file name (e.g., `RegistrationValidator.java`), not the full path. Limit to 10 files; if more, append `(+N more)`.
- **Summary**: 1–3 sentence functional description of what changed and why. Derive from the feature spec summary or MR title. Focus on **business/functional intent**, not code-level detail.
- **MR**: The MR reference in the format `!{iid}` (e.g., `!1264`).

#### 8.4 — Entry format

Each entry follows this exact markdown format:

```markdown
## {YYYY-MM-DD} | {ISSUE_ID} | {JIRA Summary Title}

**Type**: {Feature|Defect|Task}
**Modules affected**: {module-1}, {module-2}
**Files modified**: {File1.java}, {File2.java}, {File3.java}
**Summary**: {1-3 sentence functional description of what changed and why}
**MR**: !{iid}
```

Example:

```markdown
## 2026-03-19 | SCLP-3394 | Additional Info Only Update Registration

**Type**: Feature
**Modules affected**: clip-product-instance
**Files modified**: RegistrationValidator.java, ProductInstanceMapperHelper.java, ProductInstanceService.java
**Summary**: Added a lightweight update path to `PUT /api/v1/clip/product` that allows updating only `additionalInfo` and `metaData` fields without commerce identifiers or hardware serials. Uses three-way merge with null-removal semantics.
**MR**: !1264
```

#### 8.5 — Append to history file

For each project with a merged MR:

1. **If the file does not exist**, create it with a title header:
   ```markdown
   # {project-name} — Functional Modification History

   ```
   Then append the entry below the header.

2. **If the file already exists**, insert the new entry **immediately after the title header line** (line 1 — the `# {project-name} — ...` heading) and any blank line following it. This keeps the file in **reverse chronological order** (newest first).

3. **Ensure a blank line** separates the new entry from any existing entries below it.

**Example result after two features:**

```markdown
# clip-app — Functional Modification History

## 2026-03-19 | SCLP-3394 | Additional Info Only Update Registration

**Type**: Feature
**Modules affected**: clip-product-instance
**Files modified**: RegistrationValidator.java, ProductInstanceMapperHelper.java, ProductInstanceService.java
**Summary**: Added a lightweight update path to `PUT /api/v1/clip/product` that allows updating only `additionalInfo` and `metaData` fields without commerce identifiers or hardware serials. Uses three-way merge with null-removal semantics.
**MR**: !1264

## 2026-03-15 | SCLP-3380 | Fix entitlement count mismatch

**Type**: Defect
**Modules affected**: clip-entitlement
**Files modified**: EntitlementService.java, EntitlementRepository.java
**Summary**: Fixed incorrect entitlement count when multiple pool names exist for the same model. Root cause was missing distinct clause in aggregation pipeline.
**MR**: !1258
```

#### 8.6 — Cross-project entries

If the feature spans multiple projects (e.g., `clip-app` and `clip-integrations` both had MRs), append an entry to **each** project's history file. Each entry should reference only the modules and files relevant to **that specific project**, not the entire feature's footprint.

#### 8.7 — Error handling

- If the `ai/project-history/` directory does not exist, create it.
- If writing a history file fails (e.g., filesystem permissions), report the failure but do NOT fail the workflow. This step is best-effort.
- Never overwrite or compact existing history entries. This file is append-only (prepend to body, append to file conceptually).

#### 8.8 — Commit `ai/` repo changes

The `ai/` directory is a separate Git repository. After updating project-history files, sync any modified workspace-level config files and commit.

**Sync workspace-level config files** (only if modified during this session):

```bash
cp {WORKSPACE_ROOT}/CLAUDE.md {WORKSPACE_ROOT}/ai/do-not-use/CLAUDE.md
cp -r {WORKSPACE_ROOT}/.devin/skills/ {WORKSPACE_ROOT}/ai/do-not-use/.devin/skills/
cp -r {WORKSPACE_ROOT}/.windsurf/workflows/ {WORKSPACE_ROOT}/ai/do-not-use/.windsurf/workflows/
```

**Stage and commit:**

```bash
cd {WORKSPACE_ROOT}/ai
git add -A
git status
```

If there are staged changes, commit them:

```bash
git commit -m "JIRA#${ISSUE_ID}; Update project history after wrap-up"
```

If there are no changes to commit, skip silently. If the `ai` repo is on `develop` (not a feature branch), push the commit directly — project-history updates are low-risk, append-only changes.

---

### Step 9 — Publish Confluence Summary Page

Create a detailed summary page on Confluence under the configured parent page. **This entire step is optional** — skip it silently if any of the following are true:

- `CONFLUENCE_PAT` is missing, empty, or not set in `local.config`
- `CONFLUENCE_PARENT` is missing, empty, or not set in `local.config`
- The parent page ID cannot be extracted from `CONFLUENCE_PARENT`
- The Confluence API is unreachable

#### 9.1 — Parse parent page URL

Extract the **space key** and **parent page ID** from the `CONFLUENCE_PARENT` URL.

The URL follows the pattern: `https://confluence.dell.com/spaces/{SPACE_KEY}/pages/{PAGE_ID}/{Page+Title}`

```bash
# Example: https://confluence.dell.com/spaces/DF/pages/1286841426/FY27+-+DL+Features+Delivery
SPACE_KEY=$(echo "$CONFLUENCE_PARENT" | grep -oP '/spaces/\K[^/]+')
PARENT_PAGE_ID=$(echo "$CONFLUENCE_PARENT" | grep -oP '/pages/\K[0-9]+')
```

If either `SPACE_KEY` or `PARENT_PAGE_ID` is empty after parsing, log a warning and skip this step.

#### 9.2 — Verify parent page exists

```bash
curl -s --header "Authorization: Bearer $CONFLUENCE_PAT" \
  "https://confluence.dell.com/rest/api/content/${PARENT_PAGE_ID}?expand=space"
```

If the response is not `200`, log a warning ("Confluence parent page not accessible — skipping Confluence publish") and skip this step. Do NOT fail the workflow.

#### 9.3 — Generate page title

Construct the page title in the format:

```
{ISSUE_ID} - {Short Heading}
```

Where `{Short Heading}` is a **maximum 5-word** summary derived from the JIRA issue summary. Condense the JIRA summary into at most 5 words that capture the essence of the change.

Examples:
- JIRA summary "Additional Info Only Update Registration" → `SCLP-3394 - AdditionalInfo Only Update Registration`
- JIRA summary "Fix entitlement count mismatch when multiple pools exist for same model" → `SCLP-3380 - Fix Entitlement Count Mismatch`
- JIRA summary "Add hardware serial validation to registration endpoint" → `SCLP-3401 - HW Serial Registration Validation`

#### 9.4 — Build page content

Compose the page body in **Confluence Storage Format** (XHTML). The page must contain the following sections in order:

```html
<h2>Overview</h2>
<table>
  <tbody>
    <tr><th>JIRA Issue</th><td><a href="https://jira.dell.com/browse/{ISSUE_ID}">{ISSUE_ID}</a></td></tr>
    <tr><th>Type</th><td>{Issue Type — Feature/Defect/Task}</td></tr>
    <tr><th>Priority</th><td>{Priority from JIRA}</td></tr>
    <tr><th>Status</th><td>Complete</td></tr>
    <tr><th>Completion Date</th><td>{YYYY-MM-DD — date of the last MR merge}</td></tr>
    <tr><th>Delivered By</th><td>AI-Assisted (Devin/Windsurf)</td></tr>
  </tbody>
</table>

<h2>Functional Summary</h2>
<p>{2-4 sentence description of what was implemented, the business problem it solves, and who is impacted. Derive from feature-spec.md overview section.}</p>

<h2>Technical Summary</h2>
<p>{2-4 sentence description of the technical approach taken — architecture patterns used, key design decisions, technology choices. Derive from the implementation plan approach section.}</p>

<h2>Changes by Project</h2>
{For each project that had a merged MR, include a sub-section:}

<h3>{project-name} (MR !{iid})</h3>
<p><strong>MR Link:</strong> <a href="{mr_web_url}">!{iid} — {mr_title}</a></p>
<p><strong>Merged:</strong> {YYYY-MM-DD}</p>
<p><strong>Modules affected:</strong> {comma-separated list of Maven modules}</p>
<table>
  <thead><tr><th>File</th><th>Change</th><th>Description</th></tr></thead>
  <tbody>
    <tr><td><code>{file_path}</code></td><td>{Added|Modified|Deleted}</td><td>{One-line description of what changed in this file}</td></tr>
    {... repeat for each file, limit to 20 most significant files ...}
  </tbody>
</table>

<h2>Key Design Decisions</h2>
<ul>
  <li>{Decision 1 — e.g., "Used three-way merge for additionalInfo to preserve existing keys while allowing removals via explicit null."}</li>
  <li>{Decision 2 — e.g., "Bypassed commerce validation for metadata-only updates to reduce coupling."}</li>
  {... 2-5 bullet points derived from the implementation plan and feature spec ...}
</ul>

<h2>Testing</h2>
<table>
  <thead><tr><th>Test Type</th><th>Test Class</th><th>Project</th><th>Status</th></tr></thead>
  <tbody>
    <tr><td>Unit</td><td><code>{TestClassName}</code></td><td>{project}</td><td>Pass</td></tr>
    <tr><td>E2E</td><td><code>{E2ETestClassName}</code></td><td>{project}</td><td>Pass</td></tr>
    {... repeat for each test class added or modified ...}
  </tbody>
</table>

<h2>Commits</h2>
<table>
  <thead><tr><th>Project</th><th>Hash</th><th>Message</th></tr></thead>
  <tbody>
    <tr><td>{project}</td><td><code>{short_hash}</code></td><td>{commit message}</td></tr>
    {... repeat for each commit ...}
  </tbody>
</table>

<h2>Artifacts</h2>
<ul>
  <li><strong>Feature Spec:</strong> <code>ai/feature-specs/{ISSUE_ID}/feature-spec.md</code></li>
  <li><strong>Implementation Plan:</strong> <code>ai/feature-specs/{ISSUE_ID}/implementation-plan.md</code></li>
  <li><strong>Project History:</strong> <code>ai/project-history/{project}.md</code> (per impacted project)</li>
</ul>
```

**Content rules:**
- All text must be derived from actual data gathered in Steps 5–8. Do not invent or hallucinate details.
- The Functional Summary should be business-oriented and non-technical — suitable for a PM or stakeholder audience.
- The Technical Summary should be developer-oriented — suitable for peer engineers reviewing the architecture.
- File descriptions in the "Changes by Project" table should be one-line functional summaries (e.g., "Added null-removal logic for additionalInfo merge"), not raw diffs.
- Limit file tables to 20 rows per project. If more files were changed, add a final row: `<tr><td colspan="3"><em>... and {N} more files</em></td></tr>`.
- Key Design Decisions should focus on non-obvious choices — things a future developer would want to know.

#### 9.5 — Create the Confluence page

```bash
curl -s --request POST \
  --header "Authorization: Bearer $CONFLUENCE_PAT" \
  --header "Content-Type: application/json" \
  --data '{
    "type": "page",
    "title": "<PAGE_TITLE>",
    "ancestors": [{"id": <PARENT_PAGE_ID>}],
    "space": {"key": "<SPACE_KEY>"},
    "body": {
      "storage": {
        "value": "<ESCAPED_HTML_CONTENT>",
        "representation": "storage"
      }
    }
  }' \
  "https://confluence.dell.com/rest/api/content"
```

**Important:** The HTML content in `body.storage.value` must be properly JSON-escaped (escape double quotes, backslashes, newlines).

#### 9.6 — Error handling

| Response | Action |
|---|---|
| `200` | Success. Record the page URL from `response._links.webui` for the final report. |
| `401`/`403` | Auth failure. Log warning: "Confluence auth failed — skipping page creation." Continue workflow. |
| `404` | Parent page not found. Log warning. Continue workflow. |
| `409` | Page title already exists. Log warning: "Confluence page '{PAGE_TITLE}' already exists — skipping creation." Continue workflow. |
| Network error | Log warning. Continue workflow. |

**Confluence failure is NOT a workflow failure.** This step is entirely best-effort. Branch cleanup, JIRA updates, and project history are the primary objectives.

---

### Step 10 — Report Results

Produce a final summary covering all actions taken.

```
=== wrap_up Results for {ISSUE_ID} ===

--- Branch Cleanup ---

|| Project              | Local Deleted | Remote Deleted | Status  |
||----------------------|---------------|----------------|---------|
|| clip-app             | YES           | YES            | Clean   |
|| clip-integrations    | YES           | YES            | Clean   |
|| clip-control-plane   | —             | —              | Skipped |
|| clip-app-query       | YES           | —              | Clean   |
|| clip-client-java     | —             | —              | Skipped |
|| clip-delegated-server| —             | —              | Skipped |

--- JIRA Update ---

  Issue:       {ISSUE_ID}
  Comment:     Posted (or: FAILED — <reason>)
  Label:       AI-Delivered added (or: FAILED — <reason>)
  Transition:  Complete (or: FAILED — <reason> / Already in status "Done")

--- Project History ---

  Updated: ai/project-history/clip-app.md
  Updated: ai/project-history/clip-integrations.md
  (or: No projects required history updates)

--- Confluence ---

  Page: {PAGE_TITLE}
  URL:  {confluence_page_url}
  (or: Skipped — CONFLUENCE_PARENT not configured)
  (or: FAILED — <reason>)

--- Summary ---

  Feature branches cleaned across N projects.
  M commits across N merge requests.
  JIRA issue updated and transitioned to Complete.
  Project history updated for N projects.
  Confluence page published (or: skipped).

--- Artifacts Retained ---

  - ai/feature-specs/{ISSUE_ID}/feature-spec.md
  - ai/feature-specs/{ISSUE_ID}/implementation-plan.md
  - ai/project-history/{project}.md (per impacted project)
  - .devin/ session artifacts
  - Git history preserved on develop branch
```

---

## Important Rules

1. **Never merge anything.** This skill only runs AFTER all MRs are already merged.
2. **Always verify MR status before deleting branches.** If any MR is still open, halt completely.
3. **Use `git branch -D`** (force delete) for local branches since the MR is confirmed merged.
4. **If `-D` fails with "not fully merged"**, STOP — this indicates an anomaly that needs investigation.
5. **JIRA failures do not block the workflow.** Branch cleanup is the primary objective. JIRA updates are best-effort.
6. **Present the verification summary** (Step 3.5) and get confirmation before deleting any branches.
7. **Do not delete the `develop` branch** — only delete `develop-{ISSUE_ID}` feature branches.
8. **Preserve artifacts.** Do not delete feature specs, implementation plans, or any files in the working tree. Only git branches are cleaned up.
9. **Never force-push.** Only delete branches and prune.
10. **Project history is append-only.** Never overwrite, reorder, or compact existing entries in `ai/project-history/*.md`. New entries are always inserted after the file header (reverse chronological).
11. **Project history failure is non-blocking.** If writing history files fails, report and continue. The primary objectives (branch cleanup, JIRA update) take priority.
12. **Confluence failure is non-blocking.** If Confluence config is missing, the API is unreachable, or the page already exists, skip silently and continue. Never fail the workflow due to Confluence issues.

---

## API Reference

### GitLab

|| Action | Method | Endpoint |
||---|---|---|
|| List merged MRs | `GET` | `/projects/:id/merge_requests?source_branch=:branch&target_branch=develop&state=merged` |
|| List open MRs | `GET` | `/projects/:id/merge_requests?source_branch=:branch&target_branch=develop&state=opened` |
|| Get MR details | `GET` | `/projects/:id/merge_requests/:iid` |
|| Get MR changes | `GET` | `/projects/:id/merge_requests/:iid/changes` |

**Base URL**: `https://gitlab.dell.com/api/v4`
**Auth header**: `PRIVATE-TOKEN: <GIT_PAT from local.config>`
**Project ID**: Use URL-encoded project path (see table in Step 3).

### JIRA

|| Action | Method | Endpoint |
||---|---|---|
|| Get issue | `GET` | `/rest/api/2/issue/:issueKey` |
|| Get issue status | `GET` | `/rest/api/2/issue/:issueKey?fields=status` |
|| Add comment | `POST` | `/rest/api/2/issue/:issueKey/comment` |
|| Add label | `PUT` | `/rest/api/2/issue/:issueKey` (body: `{"update":{"labels":[{"add":"AI-Delivered"}]}}`) |
|| Get transitions | `GET` | `/rest/api/2/issue/:issueKey/transitions` |
|| Execute transition | `POST` | `/rest/api/2/issue/:issueKey/transitions` |

**Base URL**: `https://jira.dell.com`
**Auth header**: `Authorization: Bearer <JIRA_PAT from local.config>`

### Confluence

|| Action | Method | Endpoint |
|---|---|---|
| Get page by ID | `GET` | `/rest/api/content/:pageId?expand=space` |
| Create page | `POST` | `/rest/api/content` |

**Base URL**: `https://confluence.dell.com`
**Auth header**: `Authorization: Bearer <CONFLUENCE_PAT from local.config>`
**Parent page**: Extracted from `CONFLUENCE_PARENT` URL in `local.config`.
