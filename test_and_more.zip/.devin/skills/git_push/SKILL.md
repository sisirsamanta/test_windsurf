# Skill: git_push
> Push feature branches to origin and create GitLab Merge Requests targeting `develop`.
---

## Purpose

Automate the end-to-end workflow of pushing one or more project branches for a JIRA issue to the GitLab remote (`origin`) and creating Merge Requests (MRs) that target the `develop` branch. This skill handles multi-project mono-workspace scenarios, performs pre-push safety checks, creates MRs via the GitLab API, and produces a summary document linking every MR.

**CRITICAL: The target branch MUST always be `develop`. NEVER use `main` or `master` as the target branch.**

---

## Prerequisites

- Git is installed and available on `PATH`.
- The workspace contains one or more Git repositories (projects) with an `origin` remote pointing to GitLab (`https://gitlab.dell.com/...`).
- A `local.config` file exists in the workspace root (`C:\Users\Karan_K\Workspaces\cloud-licensing\local.config`) containing at minimum:
  - `GIT_PAT` — a GitLab Personal Access Token with `api` scope (used for MR creation and existing-MR queries).
  - `JIRA_PAT` — (optional) a JIRA Personal Access Token; used to fetch the issue summary for MR titles.
- The developer has already committed changes locally on branches named `develop-{ISSUE_ID}` in the relevant projects.
- Network access to `https://gitlab.dell.com` is available.

---

## Workflow Steps

### Step 1 — Obtain JIRA Issue ID

Determine the JIRA issue ID that ties all branches together. The branch naming convention is:

```
develop-{ISSUE_ID}
```

For example, if the issue is `CL-12345`, the branch name in every affected project is `develop-CL-12345`.

**How to obtain the ID:**
1. If the user provides it explicitly, use that value.
2. Otherwise, inspect the current checked-out branch in the current working directory. If it matches the pattern `develop-*`, extract the `{ISSUE_ID}` portion.
3. If neither works, ask the user for the JIRA Issue ID.

Store the value in a variable `ISSUE_ID` for use in all subsequent steps.

---

### Step 2 — Determine Which Projects to Push

Auto-detect every project directory in the workspace that has a local branch named `develop-{ISSUE_ID}`.

**Detection procedure:**

1. Iterate over each top-level subdirectory (project) under the workspace root.
2. Inside each project directory, run:
   ```bash
   git branch --list "develop-{ISSUE_ID}"
   ```
3. If the branch exists, add the project to the push list.
4. For each detected project, show the commits that will be pushed:
   ```bash
   git log origin/develop..develop-{ISSUE_ID} --oneline
   ```
   This shows commits ahead of `origin/develop` on the feature branch.

**Present the list to the user** in a table format:

| # | Project         | Branch                  | Commits Ahead |
|---|-----------------|-------------------------|---------------|
| 1 | project-alpha   | develop-CL-12345        | 3             |
| 2 | project-beta    | develop-CL-12345        | 1             |

Ask the user to confirm or adjust the list (add/remove projects).

**Fallback:** If auto-detection finds nothing, ask the user to specify which project directories contain changes, or list all projects and let the user choose.

---

### Step 3 — Pre-Push Checks

For **each** project in the push list, perform these safety checks before pushing:

1. **Correct branch is checked out:**
   ```bash
   git rev-parse --abbrev-ref HEAD
   ```
   Verify the output equals `develop-{ISSUE_ID}`. If not, run `git checkout develop-{ISSUE_ID}` or warn the user.

2. **Clean working tree:**
   ```bash
   git status --porcelain
   ```
   If the output is non-empty, warn the user about uncommitted changes. Ask whether to proceed (push existing commits only) or abort so they can commit/stash first.

3. **Commits exist to push:**
   ```bash
   git log origin/develop..develop-{ISSUE_ID} --oneline
   ```
   If no output, warn that there are no new commits to push for this project. Ask whether to skip it or push anyway (e.g., to create the remote branch for an MR).

If any check fails critically, remove that project from the push list and note it in the final report.

---

### Step 4 — Push Each Project

For each project that passed pre-push checks, execute:

```bash
git push -u origin develop-{ISSUE_ID}
```

The `-u` flag sets the upstream tracking reference so future `git push` / `git pull` commands work without specifying the remote branch.

**Error handling:**

| Error Scenario | Detection | Action |
|---|---|---|
| **Non-fast-forward** (remote has diverged) | Exit code non-zero + stderr contains `non-fast-forward` or `rejected` | Ask the user: (a) `git push --force-with-lease origin develop-{ISSUE_ID}` to force-push safely, or (b) `git pull --rebase origin develop-{ISSUE_ID}` first then retry push. |
| **Authentication error** | stderr contains `401`, `403`, `Authentication failed`, or `could not read Username` | Report the error clearly. Suggest the user check their Git credentials / credential manager. Do NOT retry. |
| **Network error** | stderr contains `Could not resolve host`, `Connection refused`, `Connection timed out`, or `fatal: unable to access` | Retry the push **once** after a 5-second wait. If the retry also fails, report the error and skip this project. |
| **Remote branch already exists** | This is **not** an error. `git push -u` will update the remote branch. | Proceed normally. The push updates the existing remote branch. |

Record the push result (success/failure + details) for each project for the final report.

---

### Step 5 — Create Merge Requests

For each project that was pushed successfully, create a GitLab Merge Request via the API.

**GitLab API base URL:** `https://gitlab.dell.com/api/v4`
**Authentication header:** `PRIVATE-TOKEN: {GIT_PAT}`

#### Step 5.1 — Load `local.config` for `GIT_PAT`

Read the `local.config` file from the workspace root:

```
C:\Users\Karan_K\Workspaces\cloud-licensing\local.config
```

Parse it to extract the `GIT_PAT` value. The file format is expected to be simple key-value pairs (e.g., `GIT_PAT=glpat-xxxxxxxxxxxxxxxxxxxx`), one per line. Also extract `JIRA_PAT` if present (used in Step 5.5).

If `GIT_PAT` is missing or empty, report the error and skip MR creation for all projects.

#### Step 5.2 — Determine GitLab Remote URL and Encoded Project Path

For each project, get the remote URL:

```bash
git remote get-url origin
```

Example output: `https://gitlab.dell.com/cloud-licensing/services/auth-service.git`

Extract the project path by:
1. Removing the `https://gitlab.dell.com/` prefix.
2. Removing the `.git` suffix (if present).
3. URL-encoding the path: replace `/` with `%2F`.

Example:
- Raw path: `cloud-licensing/services/auth-service`
- Encoded path: `cloud-licensing%2Fservices%2Fauth-service`

Store as `ENCODED_PATH`.

#### Step 5.3 — Check for Existing Merge Request

Before creating a new MR, check if one already exists:

```
GET https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests?source_branch=develop-{ISSUE_ID}&target_branch=develop&state=opened
```

Headers:
```
PRIVATE-TOKEN: {GIT_PAT}
```

- If the response is a non-empty array (i.e., an open MR already exists), **skip creation**. Record the existing MR's `iid` and `web_url` for the report.
- If the response is an empty array `[]`, proceed to create a new MR.

#### Step 5.4 — Create the Merge Request

```
POST https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests
```

Headers:
```
PRIVATE-TOKEN: {GIT_PAT}
Content-Type: application/json
```

Request body:
```json
{
  "source_branch": "develop-{ISSUE_ID}",
  "target_branch": "develop",
  "title": "JIRA#{ISSUE_ID}; {JIRA_SUMMARY}",
  "remove_source_branch": true
}
```

**CRITICAL RULES:**
- `target_branch` MUST be `"develop"`. **NEVER** set it to `"main"` or `"master"`.
- `remove_source_branch` is `true` so the feature branch is cleaned up after merge.
- `title` follows the format `"JIRA#{ISSUE_ID}; {JIRA_SUMMARY}"` (e.g., `"JIRA#CL-12345; Add OAuth2 token refresh logic"`). The summary is obtained in Step 5.5. This format is **required** by the GitLab pre-receive hook pattern `(JIRA#[A-Za-z0-9]{2,}-\d+;)`.

On success (HTTP 201), record the MR `iid` and `web_url` from the response.

#### Step 5.5 — Get JIRA Summary for MR Title

The MR title requires the JIRA issue summary. Obtain it using one of these methods (in order of preference):

1. **From `local.config` JIRA_PAT:** If `JIRA_PAT` is available, call the JIRA REST API:
   ```
   GET https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=summary
   ```
   Headers:
   ```
   Authorization: Bearer {JIRA_PAT}
   ```
   Extract `response.fields.summary`.

2. **From `feature-spec.md` header:** If JIRA API is unavailable, look for the feature spec file:
   ```
   ai/feature-specs/{ISSUE_ID}/feature-spec.md
   ```
   Parse the first `# ` heading line and use its text as the summary.

3. **Fallback:** If neither source is available, use a generic title: `"JIRA#{ISSUE_ID}; Feature branch merge"` and inform the user they can update the MR title manually.

#### Step 5 — Error Handling

| HTTP Status | Meaning | Action |
|---|---|---|
| **401 Unauthorized** | `GIT_PAT` token is invalid or expired. | Report error. Suggest the user regenerate their GitLab PAT and update `local.config`. Skip this project. |
| **403 Forbidden** | Token lacks permission to create MRs in this project. | Report error. Suggest checking project access level (Developer or higher required). Skip this project. |
| **409 Conflict** | MR already exists (race condition with Step 5.3 check). | Treat as success. Query existing MR to get `iid` and `web_url`. |
| **Network error** | Connection failure, timeout, DNS resolution failure. | Best-effort: retry once after 5 seconds. If still failing, report the error and continue with remaining projects. |

---

### Step 6 — Generate `merge-requests.md`

Create (or overwrite) a summary document at:

```
ai/feature-specs/{ISSUE_ID}/merge-requests.md
```

The file should contain:

```markdown
# Merge Requests for {ISSUE_ID}

> Auto-generated by Devin git_push skill

| Project | MR | Status | URL |
|---|---|---|---|
| auth-service | !142 | Created | https://gitlab.dell.com/cloud-licensing/services/auth-service/-/merge_requests/142 |
| user-service | !87 | Existing | https://gitlab.dell.com/cloud-licensing/services/user-service/-/merge_requests/87 |
| api-gateway | — | Push Failed | — |

**Target branch:** `develop`
**Source branch:** `develop-{ISSUE_ID}`
**Generated:** {YYYY-MM-DD HH:MM UTC}
```

Column definitions:
- **Project**: The project/repository name.
- **MR**: The MR iid prefixed with `!` (GitLab convention), or `—` if MR creation was skipped/failed.
- **Status**: One of `Created`, `Existing` (MR already existed), `Failed` (MR creation failed), `Push Failed` (push itself failed, so no MR attempted), `Skipped` (project was removed during pre-checks).
- **URL**: The full `web_url` of the MR, or `—` if unavailable.

---

### Step 7 — Report Results

Present a final summary to the user:

```
═══════════════════════════════════════════════════════
  Git Push & Merge Request Summary — {ISSUE_ID}
═══════════════════════════════════════════════════════

  Project          Push Status    MR Status    MR URL
  ───────────────  ────────────   ──────────   ──────
  auth-service     ✅ Pushed      ✅ Created    https://gitlab.dell.com/.../!142
  user-service     ✅ Pushed      ℹ️ Existing   https://gitlab.dell.com/.../!87
  api-gateway      ❌ Failed      ⏭️ Skipped    —

  Target branch: develop ✅
  Merge requests doc: ai/feature-specs/{ISSUE_ID}/merge-requests.md

═══════════════════════════════════════════════════════
```

**Final confirmation checklist (verify and state explicitly):**
- ✅ All pushes targeted `origin` remote.
- ✅ All MRs target `develop` branch — **NOT `main`, NOT `master`**.
- ✅ `merge-requests.md` has been written.
- ⚠️ List any projects that failed or were skipped, with reasons.

If any MR creation failed, suggest the user create it manually via the GitLab web UI and provide the direct URL:
```
https://gitlab.dell.com/{PROJECT_PATH}/-/merge_requests/new?merge_request[source_branch]=develop-{ISSUE_ID}&merge_request[target_branch]=develop
```
