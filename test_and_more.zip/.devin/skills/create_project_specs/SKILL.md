# Skill: create_project_specs

> Generate comprehensive project specification documents (functional, technical, data model, API, integration, security, deployment, NFR) by analyzing the current repository's codebase.

---

## Purpose

This workflow analyses a repository's codebase — its languages, frameworks, modules, configuration, tests, and documentation — and produces up to eight specification documents that fully describe the project. Each spec is written as a standalone Markdown file in `ai/project-specs/` (or a user-chosen directory).

Supported spec types:

1. **Functional Specs** — includes functional flows and variations as Mermaid diagrams
2. **Technical Specs**
3. **Data Model Specs**
4. **API Specs**
5. **Integration Specs**
6. **Security Specs**
7. **Deployment / Infrastructure Specs**
8. **Non-Functional Requirements (NFR) Specs**

---

## Prerequisites

- The current working directory is the root of a git repository (or a subdirectory of one).
- The repository contains source code, configuration, and/or documentation to analyse.
- Write access to the output directory (default `ai/project-specs/`).

---

## Workflow Steps

### Step 1 — Discover Project Structure

Scan the repository to build a comprehensive understanding of the project before generating any specs.

**1.1 — Languages & Frameworks**

```bash
# Identify primary languages by file extension counts
find . -type f | sed 's/.*\.//' | sort | uniq -c | sort -rn | head -20

# Look for framework indicators
cat pom.xml package.json build.gradle settings.gradle requirements.txt Gemfile go.mod Cargo.toml 2>/dev/null
```

**1.2 — Module / Package Layout**

```bash
# Map top-level and second-level directory structure
find . -maxdepth 2 -type d | grep -v '\.git' | sort

# For Java/Kotlin projects, list all modules
find . -name "pom.xml" -o -name "build.gradle" | sort
```

**1.3 — Configuration Files**

Locate and read all configuration files: `application.yml`, `application.properties`, `.env`, `docker-compose.yml`, `Dockerfile`, `Makefile`, CI/CD pipelines (`.gitlab-ci.yml`, `.github/workflows/`), Kubernetes manifests, Terraform files, etc.

**1.4 — Tests**

```bash
# Find test directories and count test files
find . -type d -name "test" -o -type d -name "tests" -o -type d -name "__tests__" -o -type d -name "spec" | sort
find . -type f -name "*Test.*" -o -name "*Spec.*" -o -name "test_*" -o -name "*.test.*" | wc -l
```

**1.5 — Existing Documentation**

```bash
# Check for existing docs
find . -type f -name "*.md" -o -name "*.adoc" -o -name "*.rst" | grep -iv changelog | sort
ls -la docs/ doc/ ai/ 2>/dev/null
```

**1.6 — Build a Mental Model**

From the above, determine:
- Primary language(s) and framework(s)
- Architectural style (monolith, microservice, modular monolith, library, CLI tool, etc.)
- Key modules/packages and their responsibilities
- External dependencies (databases, message brokers, external APIs, cloud services)
- Build system and toolchain
- Test strategy (unit, integration, e2e)

### Step 2 — Ask User Which Specs to Generate

Present the list of eight spec types and ask the user which ones to generate. **Default: all eight.**

Also ask for the output directory. **Default: `ai/project-specs/`.**

```bash
# Create the output directory
mkdir -p ai/project-specs
```

If the user requests only a subset, skip the corresponding steps below.

### Step 3 — Generate Functional Specs

**Output file:** `ai/project-specs/functional-spec.md`

Analyse the codebase to identify actors, features, use cases, business rules, and functional flows. Write the spec with the following sections:

**3.1 — Overview**
- Project name and one-paragraph summary of what the system does.
- High-level goals and scope.

**3.2 — Actors / Personas**
- List every actor that interacts with the system (end users, admins, external systems, scheduled jobs, etc.).
- For each actor: name, description, and key interactions.

**3.3 — Features & Use Cases**
- Group features by domain area or module.
- For each feature:
  - **Feature name**
  - **Description** — what it does from the user's perspective.
  - **Actors involved**
  - **Preconditions**
  - **Postconditions / Expected outcomes**
  - **Use cases** — numbered list of specific scenarios (UC-001, UC-002, etc.).

**3.4 — Business Rules**
- Extract business rules from the code (validation logic, state machines, conditional branches, access control rules).
- Number each rule (BR-001, BR-002, etc.) with a clear description.

**3.5 — Functional Flows**
This section is critical. For every significant feature or use case, produce **Mermaid diagrams** showing the flow.

**3.5.1 — Happy-Path Flows**
For each major flow, create a Mermaid `sequenceDiagram` or `flowchart` showing the normal/successful path:

````markdown
```mermaid
sequenceDiagram
    participant User
    participant API
    participant Service
    participant Database

    User->>API: POST /resource
    API->>Service: validate & process
    Service->>Database: INSERT record
    Database-->>Service: OK
    Service-->>API: 201 Created
    API-->>User: 201 + resource body
```
````

**3.5.2 — Variation Flows**
For each happy-path flow, identify variations (alternate paths that still succeed but take a different route):

````markdown
```mermaid
flowchart TD
    A[Request received] --> B{Has cached data?}
    B -->|Yes| C[Return cached response]
    B -->|No| D[Fetch from database]
    D --> E[Update cache]
    E --> C
```
````

**3.5.3 — Error Flows**
For each flow, identify error/exception paths and diagram them:

````markdown
```mermaid
sequenceDiagram
    participant User
    participant API
    participant Service

    User->>API: POST /resource (invalid payload)
    API->>Service: validate
    Service-->>API: ValidationException
    API-->>User: 400 Bad Request + error details
```
````

**Formatting rules for Mermaid diagrams:**
- Use `sequenceDiagram` for request/response flows between components.
- Use `flowchart TD` (top-down) for decision trees and branching logic.
- Use `stateDiagram-v2` for state machine / lifecycle flows.
- Label every arrow with the action or message.
- Keep diagrams focused — one flow per diagram, not the entire system.
- Use participant aliases to keep diagrams readable.

### Step 4 — Generate Technical Specs

**Output file:** `ai/project-specs/technical-spec.md`

**4.1 — Architecture Overview**
- Architectural style (microservices, modular monolith, etc.).
- High-level component diagram (as Mermaid `flowchart` or `C4Context`).
- Key design decisions and patterns used (CQRS, event sourcing, hexagonal, etc.).

**4.2 — Technology Stack**

| Layer | Technology | Version | Notes |
|---|---|---|---|
| Language | e.g. Java | 17 | From `pom.xml` / `build.gradle` |
| Framework | e.g. Spring Boot | 3.x | From dependencies |
| Database | e.g. PostgreSQL | 15 | From config / docker-compose |
| ... | ... | ... | ... |

**4.3 — Module Breakdown**
For each module/package:
- Name and responsibility.
- Key classes/files and their roles.
- Dependencies on other modules.
- Public API surface.

**4.4 — Control Flow**
Trace the request lifecycle from entry point to response:
- HTTP request handling → controller → service → repository → response.
- Message consumption → handler → processing → acknowledgement.
- Scheduled job → trigger → processing → completion.

**4.5 — Error Handling Strategy**
- Global exception handlers.
- Error response format.
- Retry policies.
- Dead-letter queues / fallback mechanisms.

**4.6 — Configuration Management**
- Configuration sources (files, environment variables, config server).
- Key configuration properties and their purpose.
- Environment-specific overrides.

**4.7 — Testing Strategy**
- Unit test framework and patterns.
- Integration test setup (testcontainers, embedded databases, etc.).
- Test coverage areas and any gaps identified.

### Step 5 — Generate Data Model Specs

**Output file:** `ai/project-specs/data-model-spec.md`

**5.1 — Entities / Tables**
For each entity:
- Entity/table name.
- All fields: name, type, constraints (NOT NULL, UNIQUE, DEFAULT, etc.).
- Primary key.
- Description of what the entity represents.

**5.2 — Relationships**
- All foreign keys and associations.
- Cardinality (one-to-one, one-to-many, many-to-many).
- Join tables if applicable.
- Mermaid `erDiagram` showing all entities and relationships:

````markdown
```mermaid
erDiagram
    USER ||--o{ ORDER : places
    ORDER ||--|{ ORDER_ITEM : contains
    ORDER_ITEM }o--|| PRODUCT : references
```
````

**5.3 — Indexes**
- All declared indexes (from entity annotations, migration scripts, or DDL).
- Composite indexes.
- Unique constraints.

**5.4 — Enums & Reference Data**
- All enums used in the data model.
- Static reference data / lookup tables.

**5.5 — Migrations**
- Migration tool (Flyway, Liquibase, Alembic, etc.).
- List of migration scripts and what each one does.
- Current schema version.

**5.6 — ER Summary**
A complete Entity-Relationship diagram as a Mermaid `erDiagram` covering all entities, with field-level detail for key entities.

### Step 6 — Generate API Specs

**Output file:** `ai/project-specs/api-spec.md`

**6.1 — API Overview**
- API style (REST, GraphQL, gRPC, etc.).
- Base URL / path prefix.
- Versioning strategy.
- Content types.

**6.2 — Endpoints**
For each endpoint:

| Field | Detail |
|---|---|
| **Method** | `GET`, `POST`, `PUT`, `DELETE`, `PATCH` |
| **Path** | `/api/v1/resource/:id` |
| **Description** | What this endpoint does |
| **Request headers** | Required headers (auth, content-type, custom) |
| **Path parameters** | Name, type, description |
| **Query parameters** | Name, type, required/optional, description |
| **Request body** | JSON schema or example with all fields documented |
| **Response (success)** | Status code + JSON schema or example |
| **Response (error)** | Possible error codes and their meanings |
| **Authorization** | Required roles/permissions |

**6.3 — Authentication & Authorization**
- Auth mechanism (JWT, OAuth2, API key, session, etc.).
- Token format and claims.
- How auth is enforced (filters, middleware, annotations).

**6.4 — Common Patterns**
- Pagination (format, default/max page sizes).
- Filtering and sorting conventions.
- Error response format (standard error envelope).
- Rate limiting (if applicable).

**6.5 — Outbound API Clients**
- External APIs consumed by the project.
- For each: base URL, endpoints called, auth method, retry policy.

### Step 7 — Generate Integration Specs

**Output file:** `ai/project-specs/integration-spec.md`

**7.1 — External Dependencies**
For each external system the project integrates with:
- System name and purpose.
- Integration type (REST API, database, message queue, file transfer, etc.).
- Connection configuration (from config files — redact secrets).
- Failure handling (circuit breakers, retries, fallbacks).

**7.2 — Messaging & Events**
- Message broker (Kafka, RabbitMQ, SQS, etc.).
- Topics/queues produced to and consumed from.
- Message schemas/formats.
- Consumer group configuration.
- Dead-letter topic handling.
- Ordering and idempotency guarantees.

**7.3 — Synchronous Integrations**
- REST/gRPC calls to other services.
- Client configuration (timeouts, retries, connection pools).
- Circuit breaker settings.

**7.4 — Data Synchronisation**
- Batch jobs that sync data between systems.
- ETL pipelines.
- Data consistency strategies (eventual consistency, saga pattern, etc.).

### Step 8 — Generate Security Specs

**Output file:** `ai/project-specs/security-spec.md`

**8.1 — Authentication**
- Authentication mechanism and flow.
- Identity provider(s).
- Token lifecycle (issuance, validation, refresh, revocation).
- Session management (if applicable).

**8.2 — Authorization**
- Authorization model (RBAC, ABAC, ACL, etc.).
- Roles and permissions defined in the system.
- How authorization is enforced (annotations, middleware, policy engine).
- Resource-level access control.

**8.3 — Data Protection**
- Encryption at rest (database encryption, encrypted columns).
- Encryption in transit (TLS configuration).
- Sensitive data handling (PII masking, audit logging redaction).
- Secrets management (vault, environment variables, sealed secrets).

**8.4 — Security Dependencies**
- Security libraries used (Spring Security, Passport.js, etc.).
- Known security configurations (CORS, CSP, CSRF protection).
- Input validation and sanitisation approach.
- Dependency vulnerability scanning (if configured).

### Step 9 — Generate Deployment Specs

**Output file:** `ai/project-specs/deployment-spec.md`

**9.1 — Build & Package**
- Build tool and commands.
- Artifact type (JAR, WAR, Docker image, npm package, binary, etc.).
- Build profiles / configurations.

**9.2 — Containerisation**
- Dockerfile analysis (base image, layers, exposed ports, entrypoint).
- Docker Compose setup (services, networks, volumes).
- Image registry and tagging strategy.

**9.3 — Orchestration**
- Kubernetes manifests (Deployments, Services, ConfigMaps, Secrets, Ingress).
- Helm charts (if present).
- Resource requests/limits.
- Health checks (liveness, readiness, startup probes).
- Horizontal Pod Autoscaler configuration.

**9.4 — CI/CD Pipeline**
- Pipeline definition file and tool (GitLab CI, GitHub Actions, Jenkins, etc.).
- Pipeline stages and what each stage does.
- Deployment strategy (rolling update, blue-green, canary).
- Environment promotion flow (dev → staging → prod).

**9.5 — Environment Configuration**
- Environment-specific settings and how they are managed.
- Feature flags (if present).
- Infrastructure-as-code (Terraform, CloudFormation, Pulumi).

**9.6 — Observability**
- Logging framework and configuration (log levels, structured logging, log aggregation).
- Metrics collection (Prometheus, Micrometer, StatsD, etc.).
- Distributed tracing (OpenTelemetry, Jaeger, Zipkin).
- Alerting rules (if defined in code/config).
- Dashboards (Grafana, Datadog, etc.).

### Step 10 — Generate NFR Specs

**Output file:** `ai/project-specs/nfr-spec.md`

**10.1 — Performance**
- Response time requirements/expectations (inferred from timeouts, SLAs in config).
- Throughput expectations (from thread pool sizes, connection pool sizes, consumer concurrency).
- Known performance optimisations (caching, connection pooling, async processing).

**10.2 — Scalability**
- Horizontal scaling capability (stateless services, HPA configuration).
- Vertical scaling considerations.
- Database scaling (read replicas, sharding, partitioning).
- Message processing scalability (consumer groups, partitions).

**10.3 — Availability**
- Deployment redundancy (replica counts, multi-AZ).
- Health check configuration.
- Graceful shutdown handling.
- Dependency failure tolerance.

**10.4 — Reliability**
- Retry mechanisms and policies.
- Circuit breaker configuration.
- Idempotency guarantees.
- Data durability (backup, replication).
- Transaction management.

**10.5 — Observability (NFR Perspective)**
- Monitoring coverage (what is monitored, what gaps exist).
- Alerting thresholds.
- Log retention policies.
- Trace sampling rates.

**10.6 — Maintainability**
- Code organisation and modularity.
- Documentation coverage.
- Test coverage.
- Dependency management (how up-to-date are dependencies).
- Code quality tools (linters, formatters, static analysis).

### Step 11 — Review & Finalise

After generating all requested specs:

**11.1 — Present Summary**

```
=== create_project_specs Summary ===

Output directory: ai/project-specs/

Generated specs:
  1. functional-spec.md    — X sections, Y Mermaid diagrams
  2. technical-spec.md     — X sections
  3. data-model-spec.md    — X entities, Y relationships
  4. api-spec.md           — X endpoints documented
  5. integration-spec.md   — X external integrations
  6. security-spec.md      — X sections
  7. deployment-spec.md    — X sections
  8. nfr-spec.md           — X sections

Total files generated: N
```

**11.2 — User Review**
- Ask the user to review the generated specs.
- Offer to expand any section that needs more detail.
- Offer to add additional Mermaid diagrams for specific flows.
- Offer to regenerate any spec with a different focus or scope.

---

## Important Rules

1. **Analyse the actual codebase.** Do not guess or hallucinate — every fact in the specs must be traceable to code, configuration, or documentation found in the repository.
2. **Use Mermaid diagrams liberally** in functional specs. Every significant flow should have at least a happy-path diagram.
3. **Keep specs self-contained.** Each spec file should be readable on its own without needing to cross-reference other specs (though cross-references are allowed for convenience).
4. **Preserve existing files.** Do not overwrite files outside the output directory. If specs already exist in the output directory, ask the user before overwriting.
5. **Use consistent formatting.** All specs should use the same Markdown style: H1 for title, H2 for major sections, H3 for subsections, tables for structured data, code blocks for examples.
6. **Redact secrets.** Never include actual passwords, API keys, tokens, or connection strings in the specs. Use placeholder values like `<REDACTED>` or `***`.
7. **Document unknowns.** If something cannot be determined from the codebase alone, note it explicitly (e.g., "**TODO:** Confirm expected response time SLA with team").
8. **Default output directory is `ai/project-specs/`.** Respect user overrides if a different path is requested.
