# Skill: create_feature_specs

> Generate a comprehensive feature-spec.md for a JIRA issue by fetching its content and cross-referencing the project codebase and existing specs.

---

## Purpose

This workflow takes a JIRA issue ID, pulls the full issue details from JIRA (summary, description, acceptance criteria, etc.), analyses the codebase against existing project specs, and produces a self-contained `feature-spec.md` under `ai/feature-specs/{ISSUE_ID}/`. The generated spec serves as the single source of truth for implementing the feature.

---

## Prerequisites

- `local.config` at the workspace root contains `JIRA_PAT` for JIRA REST API authentication.
- JIRA instance is reachable at `https://jira.dell.com`.
- Project specs exist under `ai/project-specs/` (functional-spec.md, technical-spec.md, data-model-spec.md, api-spec.md, flows/).
- The workspace codebase is checked out and up to date.

---

## Workflow Steps

### Step 1 — Obtain JIRA Issue ID

If the JIRA issue ID (e.g., `SCLP-1234`) was **not** provided as input, prompt the user for it before proceeding. The issue ID is required for all subsequent steps.

### Step 2 — Fetch JIRA Issue

Read the JIRA Personal Access Token:

```bash
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
```

Fetch the issue from JIRA REST API:

```bash
curl -s \
  --header "Authorization: Bearer $JIRA_PAT" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=summary,description,issuetype,priority,labels,components,customfield_10208"
```

**Extract the following fields from the JSON response:**

| Field | JSON Path | Notes |
|---|---|---|
| Summary | `fields.summary` | Issue title |
| Description | `fields.description` | Full body text (may contain wiki/markdown) |
| Acceptance Criteria | `fields.customfield_10208` | Custom field — may be Gherkin `Given/When/Then` format |
| Issue Type | `fields.issuetype.name` | Story, Bug, Task, Epic, etc. |
| Priority | `fields.priority.name` | Critical, Major, Minor, etc. |
| Labels | `fields.labels[]` | Array of label strings |
| Components | `fields.components[].name` | Array of component names |

### Step 3 — Load Existing Project Specs

Read the following project specification files to build context for the feature:

| File | Purpose |
|---|---|
| `ai/project-specs/functional-spec.md` | High-level functional requirements and business rules |
| `ai/project-specs/technical-spec.md` | Architecture, technology stack, design patterns |
| `ai/project-specs/data-model-spec.md` | Database schemas, entity relationships, field definitions |
| `ai/project-specs/api-spec.md` | REST/gRPC endpoints, request/response contracts |
| `ai/project-specs/flows/*.md` | Detailed process flows (registration, provisioning, etc.) |

If any file is missing, note its absence but continue with the files that are available.

### Step 4 — Analyse Codebase for Context

Cross-reference the JIRA issue description and acceptance criteria against the project specs and source code to identify:

1. **Impacted modules/services** — which projects or modules are affected (e.g., `clip-app`, `clip-integrations`, `clip-control-plane`).
2. **Impacted endpoints** — REST or gRPC endpoints that will need changes, referencing `api-spec.md`.
3. **Impacted data models** — database tables, entities, or DTOs that are affected, referencing `data-model-spec.md`.
4. **Impacted configuration files** — application properties, feature flags, environment config.
5. **Existing tests** — test classes or test suites that cover the impacted areas and will need updates.
6. **Related flows** — process flows from `ai/project-specs/flows/` that are relevant to the feature.

Search the codebase using grep/find to locate concrete file paths, class names, and method signatures for each impacted area. Record specific references (file path, class name, line range) rather than vague descriptions.

### Step 5 — Generate the Feature Spec

Create the output file at:

```
ai/feature-specs/{ISSUE_ID}/feature-spec.md
```

The generated spec **must** contain the following sections in order:

---

#### Section 4.1 — Header

```markdown
# Feature Spec: {ISSUE_ID}

| Field       | Value                              |
|-------------|------------------------------------|
| Issue ID    | {ISSUE_ID}                         |
| Issue Type  | {issuetype.name}                   |
| Priority    | {priority.name}                    |
| Labels      | {comma-separated labels}           |
| Components  | {comma-separated components}       |
| Generated   | {YYYY-MM-DD}                       |
```

---

#### Section 4.2 — Overview

A 2-5 sentence business-level summary of what this feature does and why it matters. Written in plain language for stakeholders. Derived from the JIRA summary and description.

```markdown
## Overview

{2-5 sentence business summary derived from JIRA summary and description. Explain what the feature does, who it impacts, and the business value.}
```

---

#### Section 4.3 — Background & Context

Combine context from:
- The JIRA description (full text)
- Cross-references to existing project specs (cite specific sections)

```markdown
## Background & Context

### JIRA Description

{Full description from JIRA, cleaned up for readability}

### Project Spec References

- **Functional Spec** § {section}: {brief note on relevance}
- **Technical Spec** § {section}: {brief note on relevance}
- **Data Model Spec** § {section}: {brief note on relevance}
- **API Spec** § {section}: {brief note on relevance}
- **Flow**: `flows/{flow-name}.md` — {brief note on relevance}
```

---

#### Section 4.4 — Scope

Two clearly separated bullet lists:

```markdown
## Scope

### In Scope

- {Specific deliverable or behaviour that IS part of this feature}
- {Another in-scope item}

### Out of Scope

- {Specific item that is explicitly NOT part of this feature}
- {Another out-of-scope item}
```

Derive scope from the JIRA description, acceptance criteria, and analysis of what the issue does and does not cover.

---

#### Section 4.5 — Functional Requirements

A numbered requirements table with traceability back to source:

```markdown
## Functional Requirements

| ID    | Requirement                                                      | Source                  |
|-------|------------------------------------------------------------------|-------------------------|
| FR-01 | {Concise requirement statement}                                  | JIRA description        |
| FR-02 | {Concise requirement statement}                                  | Acceptance criteria     |
| FR-03 | {Concise requirement statement}                                  | functional-spec.md § X  |
```

Each requirement should be:
- Atomic (one testable behaviour per row)
- Written as a "shall" statement where possible
- Traceable to a specific source (JIRA field, linked issue, or project spec section)

---

#### Section 4.6 — Acceptance Criteria

Reproduce the acceptance criteria **verbatim** from `customfield_10208`. If the criteria are in Gherkin format (`Given / When / Then`), preserve that format exactly:

```markdown
## Acceptance Criteria

> Copied verbatim from JIRA {ISSUE_ID} — customfield_10208

{Paste the raw acceptance criteria here, preserving Gherkin format if present}
```

If the custom field is empty or missing, note that explicitly:

```markdown
## Acceptance Criteria

> No acceptance criteria defined in JIRA {ISSUE_ID} (customfield_10208 is empty).
```

---

#### Section 4.7 — Non-Functional Requirements

Identify any non-functional requirements implied by the feature:

```markdown
## Non-Functional Requirements

| Category       | Requirement                                                        |
|----------------|--------------------------------------------------------------------|
| Performance    | {e.g., API response time < 200ms for the new endpoint}             |
| Security       | {e.g., Endpoint must enforce RBAC per existing auth patterns}      |
| Scalability    | {e.g., Must handle N concurrent requests}                          |
| Observability  | {e.g., Add metrics/logging for new operations}                     |
| Compatibility  | {e.g., Backward-compatible with existing API consumers}            |
```

Derive these from the technical spec, the nature of the change, and any explicit mentions in the JIRA issue.

---

#### Section 4.8 — Impacted Areas

A table mapping every impacted area to concrete code references:

```markdown
## Impacted Areas

| Area                  | File / Class / Endpoint                        | Nature of Change        | Project Spec Reference         |
|-----------------------|------------------------------------------------|-------------------------|--------------------------------|
| REST API              | `com.dell.clip.controller.XxxController`       | New endpoint / Modified | api-spec.md § {section}        |
| Service Layer         | `com.dell.clip.service.XxxService`             | New method              | functional-spec.md § {section} |
| Data Model            | `com.dell.clip.entity.XxxEntity`               | New field               | data-model-spec.md § {section} |
| Database Migration    | `db/migration/V{N}__description.sql`           | New migration           | data-model-spec.md § {section} |
| Configuration         | `application.yml` / `application.properties`   | New property            | technical-spec.md § {section}  |
| Unit Tests            | `com.dell.clip.service.XxxServiceTest`         | New / updated tests     | —                              |
| Integration Tests     | `com.dell.clip.integration.XxxIT`              | New / updated tests     | —                              |
```

Populate this table with **actual file paths and class names** found during the codebase analysis in Step 4. Do not use placeholder names if real references were found.

---

#### Section 4.9 — Open Questions & Assumptions

```markdown
## Open Questions & Assumptions

### Open Questions

1. {Question that could not be answered from the JIRA issue or project specs}
2. {Another open question}

### Assumptions

1. {Assumption made during spec generation, with rationale}
2. {Another assumption}
```

Flag anything ambiguous in the JIRA description, missing acceptance criteria, or gaps between the JIRA issue and the existing project specs.

---

#### Section 4.10 — Definition of Done

```markdown
## Definition of Done

- [ ] All functional requirements (FR-01 through FR-XX) implemented
- [ ] All acceptance criteria passing
- [ ] Unit tests written/updated for impacted areas
- [ ] Integration tests written/updated for impacted areas
- [ ] Non-functional requirements validated
- [ ] Code reviewed and approved
- [ ] No regressions in existing test suites
- [ ] Documentation updated (if applicable)
- [ ] Feature spec reviewed against implementation for completeness
```

---

### Step 6 — Transition JIRA to "Defining Details"

After writing the feature spec, transition the JIRA issue to **Defining Details** to signal that requirements analysis is underway.

#### 6a. Obtain JIRA Credentials

```bash
JIRA_PAT=$(grep JIRA_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
JIRA_BASE="https://jira.dell.com"
```

#### 6b. Fetch current issue status

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name`. If already "Defining Details", skip the transition.

#### 6c. Get available transitions and execute

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Find the transition whose `name` matches **"Defining Details"** (case-insensitive). Execute it:

```bash
curl -s -X POST \
  -H "Authorization: Bearer $JIRA_PAT" \
  -H "Content-Type: application/json" \
  -d '{"transition": {"id": "<TRANSITION_ID>"}}' \
  "${JIRA_BASE}/rest/api/2/issue/{ISSUE_ID}/transitions"
```

#### 6d. Error handling

JIRA transition failure is **non-blocking**. If the PAT is missing, the API returns an error, or no matching transition exists, log a warning and continue to Step 7. The feature spec generation is the primary deliverable.

---

### Step 7 — Confirm Output

After writing the file, report to the user:

1. **File path**: `ai/feature-specs/{ISSUE_ID}/feature-spec.md`
2. **Summary**: A brief recap of what was generated (issue title, number of functional requirements, number of impacted areas).
3. **Open questions**: List any open questions from Section 4.9 that need human input before implementation begins.
4. **JIRA status**: Whether the transition to "Defining Details" succeeded or was skipped.

```
=== create_feature_specs Summary ===

Issue:       {ISSUE_ID} — {summary}
Output:      ai/feature-specs/{ISSUE_ID}/feature-spec.md
FRs:         {N} functional requirements identified
Impacted:    {N} areas across {N} projects
Open Qs:     {N} questions requiring human input
JIRA Status: Transitioned to "Defining Details" (or skipped/failed)

Open Questions:
  1. {question}
  2. {question}
```

---

## Important Rules

1. **Preserve acceptance criteria verbatim.** Do not rephrase, reorder, or summarize the Gherkin criteria from `customfield_10208`.
2. **Use real code references.** After codebase analysis, populate the Impacted Areas table with actual file paths, class names, and endpoints — not placeholders.
3. **Cite sources in functional requirements.** Every FR row must have a traceable Source column pointing back to JIRA or a project spec section.
4. **Flag ambiguity as open questions.** If the JIRA issue is vague or contradicts the project specs, do not guess — add it to Open Questions.
5. **Do not invent requirements.** Only include functional requirements that are directly supported by the JIRA issue or existing project specs.
6. **Read all project spec files before generating.** Even if a spec file seems unrelated, skim it for cross-cutting concerns (auth, logging, error handling).
7. **Create the output directory if it does not exist.** Ensure `ai/feature-specs/{ISSUE_ID}/` is created before writing the file.
8. **One spec per issue.** Each JIRA issue gets its own directory under `ai/feature-specs/`.

---

## JIRA API Reference

| Action | Method | Endpoint |
|---|---|---|
| Fetch issue with specific fields | `GET` | `/rest/api/2/issue/{ISSUE_ID}?fields=summary,description,issuetype,priority,labels,components,customfield_10208` |

**Base URL**: `https://jira.dell.com`
**Auth header**: `Authorization: Bearer <JIRA_PAT>`
**PAT location**: `local.config` at workspace root. Read the value of `JIRA_PAT` from it.
