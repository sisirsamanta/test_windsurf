# Skill: git_fix_comments

> Resolve GitLab MR review comments across all impacted CLIP projects for a feature branch.

---

## Purpose

This workflow scans all git projects in the `cloud-licensing/` workspace, identifies feature branches with open Merge Requests that have unresolved review comments, analyses each comment, makes code changes (or provides reasoning to reject), builds with unit tests, commits, and pushes to the same feature branch on each impacted project.

---

## Prerequisites

- `local.config` at workspace root contains `GIT_PAT` for GitLab API access.
- Each git project has an `origin` remote pointing to `gitlab.dell.com`.
- Feature branches follow the naming convention `develop-SCLP-XXXX` or `develop-<author>-<id>`.

---

## Workflow Steps

### Step 1 — Read GitLab PAT

```bash
GIT_PAT=$(grep GIT_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
```

### Step 2 — Identify impacted git projects

Iterate over all git project directories in the workspace. For each project, determine the **current local branch** and find any **open MRs** originating from that branch.

**Git projects to scan** (each is a separate git repo):

| Project | GitLab Path (URL-encoded for API) |
|---|---|
| `clip-app` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app` |
| `clip-integrations` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-integrations` |
| `clip-control-plane` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-control-plane` |
| `clip-app-query` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app-query` |
| `clip-client-java` | `globalops%2FBPM%2FDF%2Fclp%2Fclp-active%2Fclip-client-java` |
| `clip-delegated-server` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-delegated-server` |

For each project directory:
1. `cd <project-dir>`
2. `git branch --show-current` to get the current branch name.
3. If the branch is `main` or `develop`, **skip** — no feature branch checked out.
4. Otherwise, query GitLab for open MRs with that `source_branch`:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests?state=opened&source_branch=<BRANCH_NAME>"
```

5. If an open MR exists, record the project, branch, MR IID, and MR title.

### Step 3 — Fetch MR discussions and identify actionable comments

For each MR found, fetch its discussions:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests/<MR_IID>/discussions"
```

**Filter to actionable comments only.** Ignore:
- System notes (`"system": true`)
- Bot/CI notes (author `svc_prdmrvalidator` or similar)
- Already resolved discussions (`"resolved": true`)
- Notes that are purely informational (e.g., "mentioned in merge request", "assigned to", "requested review from")

**Collect for each actionable comment:**

| Field | Source |
|---|---|
| `discussion_id` | `discussion.id` |
| `note_id` | `note.id` |
| `author` | `note.author.username` |
| `body` | `note.body` (the actual comment text) |
| `type` | `note.type` — `"DiffNote"` (inline code comment) or `"DiscussionNote"` (general MR comment) |
| `file_path` | `note.position.new_path` (only for `DiffNote`) |
| `old_path` | `note.position.old_path` (only for `DiffNote`) |
| `line` | `note.position.new_line` or `note.position.old_line` (only for `DiffNote`) |
| `line_range` | `note.position.line_range` (only for `DiffNote`, if present) |

### Step 4 — Fetch MR diff for context

For each MR, also fetch the changes to understand what was modified:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests/<MR_IID>/changes"
```

This returns the `changes[]` array with `old_path`, `new_path`, and `diff` for each file. Use this to correlate inline comments to specific code changes.

### Step 5 — Analyse each comment and decide: fix or reject

For each actionable comment, perform thorough analysis:

1. **Read the comment body** carefully.
2. **If it's a `DiffNote`** (inline comment):
   - Read the referenced file at the specified line(s) in the local working tree.
   - Understand the surrounding code context (read 50+ lines around the target).
   - Read related files if the comment references other classes/methods.
3. **If it's a `DiscussionNote`** (general comment):
   - Read the MR description and full diff to understand the scope.
   - Determine which files are relevant to the feedback.
4. **Consult project specs if needed**:
   - Registration logic → `ai/project-specs/flows/*.md`
   - API changes → `ai/project-specs/api-spec.md`
   - Data model → `ai/project-specs/data-model-spec.md`
   - Feature specs → `ai/feature-specs/SCLP-XXXX/feature-spec.md` (if referenced in MR description)
5. **Decide**:
   - **Accept** — the comment points out a valid issue, improvement, or missing case. Implement the change.
   - **Reject** — the comment is based on a misunderstanding, is already handled, or conflicts with requirements. Prepare a clear reply explaining why.

### Step 6 — Make code changes

For each accepted comment:

1. Ensure you're on the correct feature branch: `git checkout <branch-name>`
2. Pull latest: `git pull origin <branch-name>`
3. Make the code changes following existing conventions (read surrounding code, imports, patterns).
4. If the comment spans multiple related changes, batch them logically.

### Step 7 — Build with unit tests

After all changes for a project are complete, build with full unit tests to verify nothing is broken:

```bash
# For clip-app, clip-integrations, clip-control-plane, clip-app-query:
cd <project-dir>
mvn clean install

# For clip-client-java (has bundled mvnw):
cd clip-client-java
./mvnw clean install
```

**This must pass.** If the build fails:
1. Read the failure output carefully.
2. Fix the issue (could be a compilation error, test failure, or checkstyle violation).
3. Re-run the build until it passes.

### Step 8 — Commit and push

Once the build passes:

```bash
git add -A
git commit -m "$(cat <<'EOF'
JIRA#{ISSUE_ID}; Fix MR review comments for <MR_REFERENCE>

- <brief summary of each accepted comment and what was changed>
- <any rejected comments noted with reasoning>

Generated with [Devin](https://cli.devin.ai/docs)

Co-Authored-By: Devin <158243242+devin-ai-integration[bot]@users.noreply.github.com>
EOF
)"
git push origin <branch-name>
```

### Step 9 — Reply to comments on GitLab

After pushing, reply to each discussion on the MR:

**For accepted comments** — reply confirming the fix was made:

```bash
curl -s --request POST \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"body": "<reply explaining what was changed>"}' \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests/<MR_IID>/discussions/<DISCUSSION_ID>/notes"
```

**For rejected comments** — reply with clear reasoning:

```bash
curl -s --request POST \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"body": "<explanation of why the comment was not actioned>"}' \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests/<MR_IID>/discussions/<DISCUSSION_ID>/notes"
```

**Resolve the discussion** after replying (for accepted comments only):

```bash
curl -s --request PUT \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"resolved": true}' \
  "https://gitlab.dell.com/api/v4/projects/<URL_ENCODED_PATH>/merge_requests/<MR_IID>/discussions/<DISCUSSION_ID>"
```

### Step 10 — Summary report

After processing all projects, produce a summary:

```
=== git_fix_comments Summary ===

Project: clip-app
  Branch: develop-SCLP-XXXX
  MR: !1264 — "<title>"
  Comments processed: N
    Accepted: X (list each with 1-line summary)
    Rejected: Y (list each with 1-line reasoning)
  Build: PASSED
  Pushed: YES

Project: clip-integrations
  Branch: develop-SCLP-XXXX
  MR: !456 — "<title>"
  ...

Projects with no feature branch or no open MR: clip-control-plane, clip-app-query, ...
```

---

## Important Rules

1. **Never force-push.** Always use regular `git push`.
2. **Always build with full unit tests** before pushing. Do not use `-DskipTests`.
3. **Do not modify files unrelated to the review comments.** Stay scoped.
4. **Preserve existing code style.** Read surrounding code before editing.
5. **Do not resolve discussions you reject.** Only resolve accepted ones after replying.
6. **If a comment asks for a large architectural change**, flag it for human review rather than implementing — reply on the MR explaining it needs discussion.
7. **If the feature branch has merge conflicts**, alert the user rather than attempting to resolve them.
8. **Read the feature spec** (`ai/feature-specs/SCLP-XXXX/`) if it exists and is referenced in the MR description — this provides the intended behavior for the feature.

---

## GitLab API Reference

| Action | Method | Endpoint |
|---|---|---|
| List open MRs | `GET` | `/projects/:id/merge_requests?state=opened&source_branch=:branch` |
| Get MR discussions | `GET` | `/projects/:id/merge_requests/:iid/discussions` |
| Get MR changes (diff) | `GET` | `/projects/:id/merge_requests/:iid/changes` |
| Reply to discussion | `POST` | `/projects/:id/merge_requests/:iid/discussions/:discussion_id/notes` |
| Resolve discussion | `PUT` | `/projects/:id/merge_requests/:iid/discussions/:discussion_id` |

**Base URL**: `https://gitlab.dell.com/api/v4`
**Auth header**: `PRIVATE-TOKEN: <GIT_PAT from local.config>`
**Project ID**: Use URL-encoded project path (see table in Step 2).
