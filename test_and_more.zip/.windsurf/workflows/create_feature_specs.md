---
description: Generate a feature spec for a JIRA issue by fetching its description and acceptance criteria, then writing ai/feature-specs/{JIRA Issue ID}/feature-spec.md
---

# Create Feature Specs Workflow

Generate a `feature-spec.md` for a given JIRA issue by pulling its content and analysing the codebase for relevant context.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now before proceeding.

---

## Step 2: Fetch the JIRA Issue

### 2.1 Load the JIRA Personal Access Token

Read the file `local.config` at the workspace root using the read_file tool. The file contains credentials in `KEY=VALUE` format, one per line. Extract the `JIRA_PAT` value:

```
JIRA_PAT=<token>
```

Parse the value after `JIRA_PAT=` and store it as the PAT for use in Step 2.2.

If the file does not exist or `JIRA_PAT` is empty, stop and tell the user:
> `local.config` not found or `JIRA_PAT` is missing. Please create `local.config` at the workspace root with the line `JIRA_PAT=<your-personal-access-token>` before running this workflow.

### 2.2 Call the JIRA REST API

Using the PAT loaded in Step 2.1, run the following PowerShell command to fetch the issue (replace `{ISSUE_ID}` and `{PAT}` accordingly):

```powershell
$pat = "{PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
Invoke-RestMethod `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=summary,description,issuetype,priority,labels,components,customfield_10208" `
  -Headers $headers | ConvertTo-Json -Depth 10
```

From the JSON response, extract:

- **Summary / Title** — `fields.summary`
- **Description** — `fields.description`
- **Acceptance Criteria** — `fields.customfield_10208` (or any field labelled "Acceptance Criteria" / containing "Given / When / Then" structure)
- **Issue Type** — `fields.issuetype.name`
- **Priority** — `fields.priority.name`
- **Labels / Components** — `fields.labels`, `fields.components[].name`

If the API call fails (e.g. token expired or network error), stop and ask the user to update `local.config` with a valid `JIRA_PAT`. Or alternatively prompt the user to enter the PAT in the chat window.

---

## Step 3: Load Existing Project Specs

Before analysing the codebase, read the existing project-level specs from `ai/project-specs/` to use as authoritative context throughout spec generation:

- `ai/project-specs/functional-spec.md` — existing features, use cases, business rules, and functional flows.
- `ai/project-specs/technical-spec.md` — architecture, technology stack, module breakdown, and design patterns.
- `ai/project-specs/data-model-spec.md` — entities, relationships, enums, and schema details.
- `ai/project-specs/api-spec.md` — existing endpoints, request/response schemas, auth, and API conventions.
- `ai/project-specs/flows/` — detailed flow diagrams for existing features (read any files relevant to the JIRA issue domain).

Note which sections of these specs are relevant to the JIRA issue before proceeding. Reference them explicitly when populating Sections 4.3, 4.5, 4.7, and 4.8 of the feature spec.

---

## Step 4: Analyse the Codebase for Context

Using the extracted description and acceptance criteria as a guide, search the repository for relevant context:

- Cross-reference the project specs loaded in Step 3 to identify which existing modules, services, controllers, or entities are likely touched by this feature.
- Note any existing API endpoints (from `api-spec.md`) or data models (from `data-model-spec.md`) related to the feature domain.
- Check the functional flows in `ai/project-specs/flows/` for any flows that overlap with or will be modified by this feature.
- Identify configuration or feature-flag files that may be relevant.
- Check for existing tests covering related functionality.

Summarise the relevant codebase areas and the project-spec sections referenced before proceeding.

---

## Step 5: Generate the Feature Spec

Create the file `ai/feature-specs/{ISSUE_ID}/feature-spec.md` with the following structure:

---

### 4.1 Header

```markdown
# Feature Spec — {ISSUE_ID}: {Summary / Title}

- **JIRA Issue:** [{ISSUE_ID}](https://jira.dell.com/browse/{ISSUE_ID})
- **Issue Type:** {Issue Type}
- **Priority:** {Priority}
- **Generated:** {today's date}
```

---

### 4.2 Overview

A concise (2–5 sentence) business-level summary of what this feature/change is about, derived from the JIRA description. Explain *why* it is needed and what problem it solves.

---

### 4.3 Background & Context

Any relevant background information from the JIRA description: existing behaviour, constraints, prior decisions, or related systems. Where applicable, cross-reference the existing project specs (e.g. "see `functional-spec.md` §3.2" or "existing endpoint documented in `api-spec.md` §6.2") to give reviewers precise pointers into the current system design.

---

### 4.4 Scope

Two sub-sections:

**In Scope** — Bullet list of what this issue explicitly covers.

**Out of Scope** — Bullet list of what is explicitly excluded or deferred (if mentioned in the JIRA description or inferable from acceptance criteria).

---

### 4.5 Functional Requirements

Derived from the JIRA description and acceptance criteria. Each requirement must be:

- Written as a clear, testable statement (e.g. "The system SHALL …").
- Numbered sequentially: `FR-01`, `FR-02`, etc.
- Grouped by logical area where applicable.

Example format:

```markdown
| ID    | Requirement                                      | Source (AC / Description) |
|-------|--------------------------------------------------|---------------------------|
| FR-01 | The system SHALL …                               | AC #1                     |
| FR-02 | The system SHALL …                               | Description               |
```

---

### 4.6 Acceptance Criteria

Reproduce the acceptance criteria verbatim from JIRA (or as closely as possible), formatted as a numbered list. If criteria are written in Gherkin (Given/When/Then), preserve that format.

---

### 4.7 Non-Functional Requirements

List any NFRs mentioned or implied by the JIRA issue (performance targets, security constraints, compliance requirements, backward compatibility, etc.). If none are explicitly stated, note "None explicitly stated — standard NFRs apply."

---

### 4.8 Impacted Areas (from Codebase Analysis)

Based on Steps 3 and 4, list the modules, classes, endpoints, or data models that are likely to be affected, using the project specs as the authoritative reference for existing names and structure. Use this format:

```markdown
| Area              | File / Class / Endpoint          | Nature of Change        | Project Spec Reference              |
|-------------------|----------------------------------|-------------------------|-------------------------------------|
| Service Layer     | `SomeService.java`               | New method required     | `technical-spec.md` §4.3            |
| API               | `POST /api/v1/resource`          | New endpoint            | `api-spec.md` §6.2                  |
| Data Model        | `SomeEntity` — add `field`       | Schema change           | `data-model-spec.md` §5.1           |
```

---

### 4.9 Open Questions & Assumptions

List any ambiguities in the JIRA description or acceptance criteria that need clarification, and any assumptions made while writing this spec.

---

### 4.10 Definition of Done

Derived from the acceptance criteria and standard project practices:

- All functional requirements are implemented.
- All acceptance criteria pass.
- Unit and integration tests cover the new behaviour.
- No regression in existing tests.
- Code reviewed and merged.
- JIRA issue updated / closed.

---

## Step 6: Transition JIRA to "Defining Details"

After writing the feature spec, transition the JIRA issue to **Defining Details** to signal that requirements analysis is underway.

### 6.1 Obtain JIRA Credentials

Read the JIRA PAT from `local.config` at the workspace root:

```bash
JIRA_PAT=$(grep JIRA_PAT local.config | cut -d= -f2)
```

### 6.2 Fetch Current Status

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name`. If already "Defining Details", skip the transition.

### 6.3 Get Available Transitions and Execute

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Find the transition whose `name` matches `Defining Details` (case-insensitive). Execute it:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"transition": {"id": "{TRANSITION_ID}"}}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

### Error Handling

JIRA transition failure is **non-blocking**. If the PAT is missing, the API returns an error, or no matching transition exists, log a warning and continue. The feature spec generation is the primary deliverable.

---

## Step 7: Confirm Output

After writing the file, report:

- The full path of the generated file: `ai/feature-specs/{ISSUE_ID}/feature-spec.md`
- A one-line summary of what was captured (issue title, number of FRs, number of ACs).
- Any open questions or assumptions that need the user's attention (from Section 4.9).
- JIRA status transition result: transitioned to "Defining Details" (or skipped/failed).
