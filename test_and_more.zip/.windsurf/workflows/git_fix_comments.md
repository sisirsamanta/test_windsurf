---
description: Read unresolved MR review comments from GitLab for all impacted projects, analyse each comment, implement fixes or reply with rejection reasoning, build with unit tests, commit, and push to the same feature branch
---

# Git Fix Comments Workflow

Resolve GitLab Merge Request review comments across all impacted CLIP projects for a feature branch. For each unresolved comment, analyse the feedback, decide whether to accept (implement the change) or reject (reply with reasoning), then build, commit, and push.

**Pre-condition:** Feature branches have been pushed and MRs created (via `/git_push`). At least one MR has unresolved review comments.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now. The feature branch name is `develop-{ISSUE_ID}`.

---

## Step 2: Load Authentication Token

Read `local.config` at the workspace root to extract `GIT_PAT`:

```bash
GIT_PAT=$(grep GIT_PAT "$WORKSPACE_ROOT/local.config" | cut -d= -f2)
```

If the file does not exist or the token is missing, ask the user to provide it.

---

## Step 3: Identify Impacted Projects with Open MRs

The workspace contains the following Git repositories:

| # | Project | GitLab API Path (URL-encoded) |
|---|---|---|
| 1 | `clip-app` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app` |
| 2 | `clip-integrations` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-integrations` |
| 3 | `clip-control-plane` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-control-plane` |
| 4 | `clip-app-query` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-app-query` |
| 5 | `clip-client-java` | `globalops%2FBPM%2FDF%2Fclp%2Fclp-active%2Fclip-client-java` |
| 6 | `clip-delegated-server` | `infrastructure%2Fase%2Fdlf%2Fcloud-licensing-solution%2Fclip-delegated-server` |

For each project directory:

1. Check if the feature branch exists locally:
   ```bash
   cd {WORKSPACE_ROOT}/{project}
   git branch --list "develop-{ISSUE_ID}"
   ```

2. If the branch does not exist, **skip** this project.

3. If the branch exists, query GitLab for an open MR from that branch:
   ```bash
   curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
     "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests?state=opened&source_branch=develop-{ISSUE_ID}"
   ```

4. If no open MR is found, **skip** this project and note it in the report.

5. If an open MR exists, record: project name, branch, MR `iid`, MR `title`, MR `web_url`.

Present the list to the user:

> Found open MRs for `develop-SCLP-3394`:
> - `clip-app`: MR !1264 — "JIRA#SCLP-3394; Additional Info Only Update Registration"
>
> Projects skipped (no feature branch or no open MR): clip-integrations, clip-control-plane, ...
>
> Proceed to fetch and analyse comments?

---

## Step 4: Fetch MR Discussions

For each MR, fetch all discussions:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/discussions"
```

### Filter to actionable comments only

**Ignore** (do not process):
- System notes: `"system": true` (e.g., "assigned to", "requested review from", "mentioned in")
- Bot/CI notes: author username is `svc_prdmrvalidator` or similar CI service accounts
- Already resolved discussions: `"resolved": true`
- Notes that are purely informational with no actionable request

**Collect** each actionable comment:

| Field | Source | Notes |
|---|---|---|
| `discussion_id` | `discussion.id` | Needed for replies and resolution |
| `note_id` | `note.id` | Individual note identifier |
| `author` | `note.author.username` | Who left the comment |
| `body` | `note.body` | The actual comment text |
| `type` | `note.type` | `"DiffNote"` = inline code comment, `"DiscussionNote"` = general MR comment |
| `file_path` | `note.position.new_path` | Only for `DiffNote` — the file being commented on |
| `old_path` | `note.position.old_path` | Only for `DiffNote` — original file path (if renamed) |
| `new_line` | `note.position.new_line` | Only for `DiffNote` — line number in the new version |
| `old_line` | `note.position.old_line` | Only for `DiffNote` — line number in the old version |
| `line_range` | `note.position.line_range` | Only for `DiffNote` — range if comment spans multiple lines |

If there are zero actionable comments across all MRs, report this and stop.

---

## Step 5: Fetch MR Diff for Context

For each MR with actionable comments, fetch the full changeset:

```bash
curl -s --header "PRIVATE-TOKEN: $GIT_PAT" \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/changes"
```

This returns the `changes[]` array with `old_path`, `new_path`, and `diff` for each modified file. Use this to correlate inline comments to specific code changes and understand the full scope of the MR.

---

## Step 6: Analyse Each Comment — Accept or Reject

For each actionable comment, perform a thorough analysis:

### 6.1 Gather context

**For `DiffNote` (inline code comment):**
- Read the referenced file at the specified line(s) in the local working tree.
- Read at least 50 lines of surrounding context above and below the target line.
- Read related files if the comment references other classes, methods, or interfaces.
- Check the MR diff to understand what was changed at that location.

**For `DiscussionNote` (general MR comment):**
- Read the MR description and full diff to understand scope.
- Determine which files and code paths are relevant to the feedback.

### 6.2 Consult specs if needed

- **Registration logic** → `ai/project-specs/flows/*.md`
- **API changes** → `ai/project-specs/api-spec.md`
- **Data model** → `ai/project-specs/data-model-spec.md`
- **Feature requirements** → `ai/feature-specs/{ISSUE_ID}/feature-spec.md` (if it exists and is referenced in the MR description)
- **Implementation plan** → `ai/feature-specs/{ISSUE_ID}/implementation_plan.md`

### 6.3 Decide

| Decision | Criteria | Action |
|---|---|---|
| **Accept** | Comment points out a valid bug, improvement, missing edge case, naming issue, or code style problem | Implement the change |
| **Reject** | Comment is based on a misunderstanding, the concern is already handled elsewhere, it conflicts with feature requirements, or it would introduce a regression | Prepare a clear reply explaining why |
| **Escalate** | Comment requests a large architectural change, a design discussion, or something outside the scope of this feature | Flag for human review — reply on the MR explaining it needs discussion |

Present the analysis to the user before making changes:

> ### Comment Analysis for clip-app MR !1264
>
> | # | Author | File | Comment (summary) | Decision | Reasoning |
> |---|---|---|---|---|---|
> | 1 | @kumars274 | `RegistrationValidator.java:56` | "Add null check for additionalInfo" | **Accept** | Valid — NPE possible if field is null |
> | 2 | @kumars274 | (general) | "Should this also handle metaData updates?" | **Reject** | Already handled in `mergeMetaData()` per feature spec FR-3 |
>
> Proceed with changes?

Wait for user confirmation before making code changes. If the user disagrees with any decision, adjust accordingly.

---

## Step 7: Make Code Changes

For each accepted comment:

1. Ensure the correct branch is checked out:
   ```bash
   cd {WORKSPACE_ROOT}/{project}
   git checkout develop-{ISSUE_ID}
   git pull origin develop-{ISSUE_ID}
   ```

2. Make the code changes following existing conventions:
   - Read surrounding code, imports, and patterns before editing.
   - Preserve existing code style (indentation, naming, Lombok annotations, etc.).
   - Do NOT modify files unrelated to the review comments.

3. If the comment requires a new or modified unit test, add it following the project's existing test patterns.

4. Batch logically related changes from multiple comments together.

---

## Step 8: Build with Unit Tests

After all changes for a project are complete, build with full unit tests:

```bash
# For clip-app, clip-integrations, clip-control-plane, clip-app-query:
cd {WORKSPACE_ROOT}/{project}
mvn clean install

# For clip-client-java (has bundled mvnw):
cd {WORKSPACE_ROOT}/clip-client-java
./mvnw clean install
```

**The build MUST pass before proceeding.** If the build fails:

1. Read the failure output carefully.
2. Identify the cause (compilation error, test failure, checkstyle violation).
3. Fix the issue.
4. Re-run the build.
5. Repeat until the build passes.

Do NOT skip tests. Do NOT use `-DskipTests`.

---

## Step 9: Commit and Push

Once the build passes for a project:

```bash
cd {WORKSPACE_ROOT}/{project}
git add -A
git status

git commit -m "$(cat <<'EOF'
JIRA#{ISSUE_ID}; Fix MR review comments

Accepted:
- {1-line summary of each accepted comment and what was changed}

Rejected:
- {1-line summary of each rejected comment and why}

Generated with [Devin](https://cli.devin.ai/docs)

Co-Authored-By: Devin <158243242+devin-ai-integration[bot]@users.noreply.github.com>
EOF
)"

git push origin develop-{ISSUE_ID}
```

### Error Handling

| Error | Action |
|---|---|
| Push rejected (non-fast-forward) | `git pull --rebase origin develop-{ISSUE_ID}` then retry push. If rebase has conflicts, **STOP** and report to user. |
| Push fails with auth error | Report to user, do not retry. |
| No changes to commit | All comments were rejected — skip commit/push for this project. |

**Never force-push.** Always use regular `git push`.

---

## Step 10: Reply to Comments on GitLab

After pushing, reply to each discussion thread on the MR.

### For accepted comments — confirm the fix:

```bash
curl -s --request POST \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"body": "Fixed in commit {SHORT_SHA}. {Brief description of what was changed}."}' \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/discussions/{DISCUSSION_ID}/notes"
```

Then resolve the discussion:

```bash
curl -s --request PUT \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"resolved": true}' \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/discussions/{DISCUSSION_ID}"
```

### For rejected comments — reply with reasoning:

```bash
curl -s --request POST \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"body": "{Clear explanation of why the comment was not actioned, referencing code or specs as appropriate}."}' \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/discussions/{DISCUSSION_ID}/notes"
```

**Do NOT resolve rejected discussions.** Leave them open for the reviewer to respond.

### For escalated comments — flag for discussion:

```bash
curl -s --request POST \
  --header "PRIVATE-TOKEN: $GIT_PAT" \
  --header "Content-Type: application/json" \
  --data '{"body": "This requires further discussion — flagging for review. {Brief explanation of the concern and why it may be out of scope}."}' \
  "https://gitlab.dell.com/api/v4/projects/{ENCODED_PATH}/merge_requests/{MR_IID}/discussions/{DISCUSSION_ID}/notes"
```

### Error Handling

| Problem | Action |
|---|---|
| 401 Unauthorized | Token may be expired. Report to user. |
| 403 Forbidden | User may lack permission to comment. Report to user. |
| Network error | Report to user. Code changes are already pushed — replies can be posted manually. |

Do NOT treat a reply failure as a workflow failure. The code changes and push are the critical path; GitLab replies are best-effort.

---

## Step 11: Report Results

After processing all projects, report a summary:

```
=== git_fix_comments Summary ===

Project: clip-app
  Branch: develop-{ISSUE_ID}
  MR: !1264 — "{title}"
  Comments processed: 5
    Accepted: 3
      - #{note_id}: {file}:{line} — {1-line summary of fix}
      - #{note_id}: {file}:{line} — {1-line summary of fix}
      - #{note_id}: (general) — {1-line summary of fix}
    Rejected: 1
      - #{note_id}: {file}:{line} — {1-line reasoning}
    Escalated: 1
      - #{note_id}: (general) — {1-line reasoning}
  Build: PASSED
  Pushed: YES (commit {SHORT_SHA})
  Replies posted: 5/5

Project: clip-integrations
  Branch: develop-{ISSUE_ID}
  MR: !456 — "{title}"
  Comments processed: 0 (no unresolved comments)
  No action needed.

Projects with no feature branch or no open MR:
  clip-control-plane, clip-app-query, clip-client-java, clip-delegated-server
```

---

## Important Rules

1. **Never force-push.** Always use regular `git push`.
2. **Always build with full unit tests** before pushing. Never use `-DskipTests`.
3. **Do not modify files unrelated to the review comments.** Stay scoped to the feedback.
4. **Preserve existing code style.** Read surrounding code before editing.
5. **Do not resolve discussions you reject.** Only resolve accepted ones after replying.
6. **Present analysis to the user before making changes.** Wait for confirmation in Step 6.
7. **If a comment asks for a large architectural change**, escalate it rather than implementing — reply on the MR explaining it needs discussion.
8. **If the feature branch has merge conflicts with the remote**, alert the user rather than attempting to resolve them.
9. **Read the feature spec** (`ai/feature-specs/{ISSUE_ID}/`) if it exists — this provides the intended behavior and requirements for the feature.
10. **Commit messages must follow the convention**: `JIRA#{ISSUE_ID}; {description}` (enforced by GitLab pre-receive hook).

---

## GitLab API Quick Reference

| Action | Method | Endpoint |
|---|---|---|
| List open MRs by branch | `GET` | `/projects/:id/merge_requests?state=opened&source_branch=:branch` |
| Get MR discussions | `GET` | `/projects/:id/merge_requests/:iid/discussions` |
| Get MR changes (diff) | `GET` | `/projects/:id/merge_requests/:iid/changes` |
| Reply to a discussion | `POST` | `/projects/:id/merge_requests/:iid/discussions/:discussion_id/notes` |
| Resolve a discussion | `PUT` | `/projects/:id/merge_requests/:iid/discussions/:discussion_id` |

**Base URL**: `https://gitlab.dell.com/api/v4`
**Auth header**: `PRIVATE-TOKEN: {GIT_PAT from local.config}`
**Project ID**: Use URL-encoded project path (see table in Step 3).
