---
description: Push all (or selected) project directories for a feature branch to origin and create a Merge Request from the feature branch to develop
---

# Git Push Workflow

Push feature branches to the remote and create Merge Requests (MRs) targeting `develop` for each project.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now. The feature branch name is derived as `develop-{ISSUE_ID}`.

---

## Step 2: Determine Which Projects to Push

The workspace contains the following Git repositories:

| # | Project | Description |
|---|---|---|
| 1 | `clip-app` | Core CLIP API (modular monolith) |
| 2 | `clip-integrations` | Dell-specific integration wrapper over clip-app |
| 3 | `clip-control-plane` | Background processing & control-plane operations |
| 4 | `clip-app-query` | Read-side query service (CQRS) |
| 5 | `clip-client-java` | Java SDK for product integration |
| 6 | `clip-client-c` | C/C++ native SDK |
| 7 | `clip-config-server` | Configuration server |
| 8 | `clip-delegated-server` | Delegated operations server |
| 9 | `clip-demo-app` | Reference / demo application |
| 10 | `clip-mcp-server` | MCP server for AI assistants |
| 11 | `ai` | AI specs, feature specs, project history (separate Git repo) |

> **Note:** The `ai` directory is a separate Git repository. It should always be included in auto-detection. If it has a feature branch with commits, push it alongside the other projects.

Use the following priority order to determine which projects to push:

### Priority 1: Auto-detect from current branches (preferred)

For each project directory, check if the feature branch `develop-{ISSUE_ID}` exists locally:

```powershell
cd {WORKSPACE_ROOT}/{project}
git branch --list "develop-{ISSUE_ID}"
```

Collect all projects where the branch exists. Present the list to the user for confirmation:

> The following projects have branch `develop-SCLP-3394`:
> - `clip-app` (3 commits ahead of develop)
> - `clip-integrations` (1 commit ahead of develop)
>
> Push these? (or specify different projects)

To show commits ahead, run:
```powershell
git log "origin/develop..develop-{ISSUE_ID}" --oneline
```

### Priority 2: User-specified projects

If the user has already specified projects in their message, use their selection directly — skip auto-detection.

### Priority 3: Ask the user

If no projects have the branch, ask the user which projects to push.

---

## Step 3: Pre-Push Checks

For each selected project, verify the working tree is clean and the branch is correct:

```powershell
cd {WORKSPACE_ROOT}/{project}

# 1. Confirm we are on the correct branch
git branch --show-current

# 2. Check for uncommitted changes
git status --porcelain

# 3. Check there are commits to push
git log "origin/develop..HEAD" --oneline
```

If a project:
- **Is not on `develop-{ISSUE_ID}`** — switch to it: `git checkout develop-{ISSUE_ID}`
- **Has uncommitted changes** — stop and ask the user: commit them, stash them, or skip this project.
- **Has no new commits** (branch is identical to develop) — warn the user and ask whether to push anyway or skip.

---

## Step 4: Push Each Project

For each selected project, push the feature branch to origin:

```powershell
cd {WORKSPACE_ROOT}/{project}
git push -u origin develop-{ISSUE_ID}
```

### Error Handling

| Error | Likely Cause | Action |
|---|---|---|
| `push` rejected (non-fast-forward) | Remote has diverged | Ask user: force push (`git push --force-with-lease origin develop-{ISSUE_ID}`) or pull first? |
| `push` fails with auth error | Credentials / SSH key issue | Report to user, skip this project |
| `push` fails with network error | Connectivity issue | Report to user, retry once, then skip |
| Remote branch already exists | Previous push | This is fine — `git push -u` will update it |

Execute projects sequentially so errors are caught clearly.

---

## Step 5: Create Merge Requests

After all projects are pushed, create a Merge Request (MR) for each project.

**CRITICAL: The target branch MUST be `develop`. NEVER create an MR targeting `main` or `master`.**

### 5.1 Obtain Authentication

Read `local.config` at the workspace root using the read_file tool. The file contains credentials in `KEY=VALUE` format, one per line. Extract `GIT_PAT` for the GitLab `PRIVATE-TOKEN` header, and `JIRA_PAT` if present (used in Step 5.5).

### 5.2 Determine the GitLab Remote URL

For each project, extract the GitLab remote URL:

```powershell
cd {WORKSPACE_ROOT}/{project}
git remote get-url origin
```

From the remote URL, derive the GitLab API project path. For example:
- SSH: `git@gitlab.example.com:group/project.git` → `group%2Fproject`
- HTTPS: `https://gitlab.example.com/group/project.git` → `group%2Fproject`

URL-encode the project path (replace `/` with `%2F`, strip `.git` suffix).

### 5.3 Check for Existing MR

Before creating a new MR, check if one already exists:

```powershell
$token = "{GITLAB_TOKEN}"
$headers = @{ "PRIVATE-TOKEN" = $token }
Invoke-RestMethod `
  -Uri "https://{GITLAB_HOST}/api/v4/projects/{ENCODED_PROJECT_PATH}/merge_requests?source_branch=develop-{ISSUE_ID}&target_branch=develop&state=opened" `
  -Headers $headers
```

If an MR already exists, report its URL to the user and skip creation for that project.

### 5.4 Create the MR

```powershell
$token = "{GITLAB_TOKEN}"
$headers = @{ "PRIVATE-TOKEN" = $token; "Content-Type" = "application/json" }
$body = @{
    source_branch = "develop-{ISSUE_ID}"
    target_branch = "develop"
    title = "JIRA#{ISSUE_ID}; {JIRA_SUMMARY}"
    description = "## JIRA`n`n[{ISSUE_ID}](https://jira.dell.com/browse/{ISSUE_ID})`n`n## Changes`n`nSee feature spec: `ai/feature-specs/{ISSUE_ID}/feature-spec.md`"
    remove_source_branch = $true
    squash = $false
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "https://{GITLAB_HOST}/api/v4/projects/{ENCODED_PROJECT_PATH}/merge_requests" `
  -Headers $headers `
  -Body $body
```

**Key parameters:**
- `source_branch`: `develop-{ISSUE_ID}`
- `target_branch`: **`develop`** (NEVER `main` or `master`)
- `title`: `JIRA#{ISSUE_ID}; {summary from JIRA or feature spec}` — **required** by the GitLab pre-receive hook pattern `(JIRA#[A-Za-z0-9]{2,}-\d+;)`
- `remove_source_branch`: `true` (clean up after merge)

### 5.5 Fetch JIRA Summary for MR Title

To populate the MR title with the JIRA summary, use `JIRA_PAT` from `local.config` and call:

```powershell
$pat = "{JIRA_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$issue = Invoke-RestMethod `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=summary" `
  -Headers $headers
$issue.fields.summary
```

Alternatively, if `ai/feature-specs/{ISSUE_ID}/feature-spec.md` exists, extract the summary from its header line.

### Error Handling

| Problem | Solution |
|---|---|
| **401 Unauthorized** | GitLab token is invalid or expired. Ask user for a new one. |
| **403 Forbidden** | User lacks permission to create MRs. Report to user. |
| **409 Conflict** | MR already exists. Report existing MR URL. |
| **Network error** | Report to user. Branches are already pushed — MR can be created manually. |
| **Cannot determine GitLab host** | Ask the user for the GitLab API base URL. |

Do NOT treat an MR creation failure as a workflow failure. The branches are already pushed; MR creation is best-effort.

---

## Step 6: Generate `merge-requests.md`

After all pushes and MR creations are complete, create (or overwrite) a file at `ai/feature-specs/{ISSUE_ID}/merge-requests.md` that records every impacted project and its MR details.

Use the following template:

```markdown
# Merge Requests — {ISSUE_ID}

- **JIRA Issue:** [{ISSUE_ID}](https://jira.dell.com/browse/{ISSUE_ID})
- **Branch:** `develop-{ISSUE_ID}`
- **Target:** `develop`
- **Generated:** {today's date}

---

| # | Project | MR | Status | URL |
|---|---------|-----|--------|-----|
| 1 | `clip-app` | !1264 | ✅ Created | https://gitlab.dell.com/.../merge_requests/1264 |
| 2 | `clip-integrations` | — | ⏭ No feature branch | — |

---

## Notes

- {any additional notes, e.g. "MR for clip-integrations already existed", or "clip-control-plane skipped — no changes"}
```

Populate the table with the actual results from Steps 4 and 5:
- For each project that was pushed and has an MR: include the MR `iid` (e.g. `!1264`), status (`Created` or `Already exists`), and full `web_url` from the GitLab API response.
- For projects with no feature branch: mark as `⏭ No feature branch`.
- For projects where the push or MR creation failed: mark with `❌` and a brief reason.

This file is used by subsequent workflows (`wrap_up`) to reference MR links without re-querying GitLab.

---

## Step 7: Report Results

After processing all projects, report a summary table:

```
| # | Project              | Push   | MR                                          |
|---|----------------------|--------|-----------------------------------------------|
| 1 | clip-app             | ✅ OK  | ✅ Created — https://gitlab.../merge_requests/123 |
| 2 | clip-integrations    | ✅ OK  | ⏭ Already exists — https://gitlab.../merge_requests/100 |
| 3 | clip-control-plane   | ⏭ Skip | — (no feature branch)                         |
```

Also report:
- Total projects pushed vs skipped vs failed.
- Branch name: `develop-{ISSUE_ID}`
- MR target: `develop` (confirm it is NOT `main`)
- MR URLs for quick access.
- Any projects that need manual attention.
- Path to the generated file: `ai/feature-specs/{ISSUE_ID}/merge-requests.md`
