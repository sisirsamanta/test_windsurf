---
description: Generate an implementation plan for a CLIP feature by analyzing its feature spec, tracing the codebase, and producing an actionable prompt with code references, test strategy, and file modification guide — saved to ai/feature-specs/{ISSUE_ID}/implementation_plan.md
---

# Create Implementation Plan Workflow

Generate an `implementation_plan.md` for a given JIRA feature that already has a requirements/feature spec. The plan should be detailed enough for an AI coding agent (or a developer) to implement the feature end-to-end without ambiguity.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now before proceeding.

Verify that a feature spec exists at `ai/feature-specs/{ISSUE_ID}/feature-spec.md`. If it does not exist, tell the user to run the `create_feature_specs` workflow first.

---

## Step 2: Read the Feature Spec

Read the feature spec file(s) in `ai/feature-specs/{ISSUE_ID}/`. Extract:

- **Feature summary** — what the feature does in one paragraph.
- **Functional requirements** — the FR table or list.
- **Acceptance criteria** — the numbered ACs.
- **Impacted areas** — the modules/classes/endpoints listed in the spec.
- **Open questions** — any unresolved items from the spec.

Keep these in memory; they will guide all subsequent codebase analysis.

---

## Step 3: Load Project Context

Read the workspace-level context for architecture and conventions:

- `CLAUDE.md` (workspace rules / project context at root)
- `ai/project-specs/technical-spec.md` — architecture, module layout, patterns
- `ai/project-specs/data-model-spec.md` — entities, collections, enums
- `ai/project-specs/api-spec.md` — existing endpoints, DTOs, request/response schemas
- `ai/project-specs/functional-spec.md` — existing features and business rules

Also check `ai/flows/` for any existing flow diagrams related to the feature domain.

---

## Step 4: Deep-Dive Codebase Analysis

For each impacted area identified in the feature spec, perform targeted analysis. The goal is to pin down **exact file paths, class names, method names, and line numbers** for every place that needs modification.

### 4.1 Trace the Entry Point

- Identify the router/handler that receives the request (search for the API path in `*Router.java` or `*Handler.java` files).
- Trace from router → handler → service → repository. Note each class and method in the call chain.

### 4.2 Analyze Existing Logic

For each service method that will be modified:

- Read the full method. Note its length, branching logic, and return type.
- Identify the exact line range where the new logic should be inserted.
- Look for validation methods that gate the flow — determine if they need modification.
- Identify mappers/helpers that build DTOs — determine if they need new methods.

### 4.3 Analyze DTOs and Entities

- Read the request DTO(s) and response DTO(s). Confirm whether schema changes are needed or if existing fields suffice.
- Read the entity class(es). Confirm whether new fields are needed.
- If no changes are needed, explicitly state "No DTO/entity changes required" — this prevents unnecessary work.

### 4.4 Check Cross-Cutting Concerns

- **Signing**: Does the response need to be signed? (Check `JsonSecurityService` usage in similar flows.)
- **Audit**: Does the operation need a transaction audit entry? (Check `*ContextBuilder` classes.)
- **Kafka events**: Does the operation need to publish a Kafka event? (Check outbox usage.)
- **Integrations layer**: If the request comes through `clip-integrations`, trace the integration service method to confirm the request will route correctly to clip-app.

### 4.5 Analyze Test Infrastructure

- Find the existing unit test class for the service being modified. Note its path, size, test framework, mocking patterns, and helper classes.
- Find the test helper class that builds test DTOs. Note how request/response objects are constructed.
- Find an existing E2E test in the same domain. Note its base class, setup pattern, and assertion style.

### 4.6 Identify Open Questions

As you analyze, note any discrepancies between the feature spec and the actual codebase:

- Fields referenced in the spec that don't exist in the code.
- Assumptions in the spec that don't hold (e.g., a class is a record vs. a POJO).
- Guard conditions that reference non-existent configuration.

These become "Resolve Before Coding" items in the plan.

---

## Step 5: Generate the Implementation Plan

Create `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` with the following structure:

---

### 5.1 Header

```markdown
# Implementation Plan — {ISSUE_ID}: {Feature Title}
```

---

### 5.2 Prompt Section

The core of the plan is a self-contained prompt (in a fenced code block) that can be copy-pasted to an AI coding agent. It should contain:

#### Context
- One paragraph describing what the feature does and which endpoint it modifies/adds.
- Reference the feature spec file path for full details.

#### Open Questions — Resolve Before Coding
- List every discrepancy found in Step 4.6.
- For each, describe what the spec says, what the code actually shows, and suggest options for resolution.
- Instruct the implementer to present findings and get confirmation before coding.

#### Files to Modify
For each file that needs changes:
- **Full file path** (relative to the project root).
- **What to change**: add method, modify method, add field, etc.
- **Exact details**: method signature, logic description, which existing line/method to insert near.
- **How it connects**: which other components call this code or are called by it.

#### Files NOT to Modify
Explicitly list areas that do NOT need changes and explain why (prevents scope creep).

#### Implementation Order
A numbered list of steps:
1. **Write unit tests FIRST** (TDD) — specify:
   - Which test class to add tests to (full path).
   - Test patterns to follow (link to existing tests by name).
   - Which test helper to extend for building test data.
   - Exact test cases to write (name, scenario, expected behavior).
2. **Implement the feature** — make the tests pass.
3. **Run existing unit tests** — provide the exact Maven/Gradle command.
4. **Write E2E test** — specify:
   - Which directory and naming convention.
   - Which base class to extend.
   - Setup sequence (create model → offer → entitlement → register → test).
   - Assertion expectations.
5. **Run E2E tests** — provide the exact command.

#### Critical Constraints
Bullet list of non-negotiable rules:
- Backward compatibility requirements.
- Reactive/non-blocking requirements.
- Atomicity / consistency requirements.
- Response signing requirements.
- Audit requirements.
- Code style requirements (no comment changes, match surrounding code, etc.).

---

### 5.3 Additional Considerations

After the prompt block, add supplementary guidance:

- **CheckStyle**: command to run checkstyle if the project uses it.
- **Integration layer verification**: how to trace that the request flows correctly through clip-integrations.
- **Feature spec open questions**: pointer to section 4.9 of the feature spec if there are unresolved items.

---

### 5.4 Key Code References Table

A table with columns: What | File | Lines — listing every file and line range referenced in the plan. This serves as a quick-reference index.

---

## Step 6: Validate the Plan

Before finalizing, verify:

- [ ] Every file path in the plan actually exists in the codebase.
- [ ] Every method name referenced exists at approximately the stated line number.
- [ ] Every DTO/entity field referenced exists.
- [ ] The implementation order is logically sound (tests before implementation, unit before E2E).
- [ ] Open questions are clearly flagged and not silently assumed.
- [ ] The prompt is self-contained — an implementer with no prior context can follow it.

Fix any issues found during validation.

---

## Step 7: Transition JIRA to "Waiting for Dev"

After writing the implementation plan, transition the JIRA issue to **Waiting for Dev** to signal that planning is complete and the feature is ready for development.

### 7.1 Obtain JIRA Credentials

Read the JIRA PAT from `local.config` at the workspace root:

```bash
JIRA_PAT=$(grep JIRA_PAT local.config | cut -d= -f2)
```

### 7.2 Fetch Current Status

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name`. If already "Waiting for Dev", skip the transition.

### 7.3 Get Available Transitions and Execute

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Find the transition whose `name` matches `Waiting for Dev` (case-insensitive). Execute it:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"transition": {"id": "{TRANSITION_ID}"}}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

### Error Handling

JIRA transition failure is **non-blocking**. If the PAT is missing, the API returns an error, or no matching transition exists, log a warning and continue. The implementation plan is the primary deliverable.

---

## Step 8: Confirm Output

After writing the file, report:

- The full path of the generated file.
- A summary: feature title, number of files to modify, number of test cases specified, number of open questions.
- Highlight any critical open questions that need user input before implementation can begin.
- JIRA status transition result: transitioned to "Waiting for Dev" (or skipped/failed).
