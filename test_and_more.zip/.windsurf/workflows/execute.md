---
description: Execute the implementation plan for a CLIP feature — read the plan, implement code changes across all relevant projects following TDD, run verification, commit, and update the JIRA issue
---

# Execute Workflow

Read the implementation plan for a feature and execute it end-to-end: implement code changes, write tests (TDD), verify builds pass, commit to the feature branch, and update the JIRA issue with a summary comment and status transition.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now before proceeding.

---

## Step 2: Load the Implementation Plan

Read the following files in order:

1. `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` — the primary execution guide
2. `ai/feature-specs/{ISSUE_ID}/feature-spec.md` — for functional requirements and acceptance criteria

If the implementation plan does not exist, tell the user to run the `create_implementation_plan` workflow first and stop.

From the implementation plan, extract and hold in context:

- **Merge strategy / key design decisions** — any resolved questions or constraints that affect implementation
- **Files to modify** — the ordered list of files with exact paths, method names, and change descriptions
- **Files NOT to modify** — explicit exclusions to avoid scope creep
- **Implementation order** — the numbered sequence of steps (typically: write tests → implement → run tests → write E2E → run E2E)
- **Critical constraints** — non-negotiable rules (backward compat, reactive, atomicity, etc.)
- **Test plan** — the specific test cases to write, with names, scenarios, and expected behaviour
- **Key code references** — file paths and line numbers for tracing

Also read any example data files referenced in the plan (e.g. from `ai/project-specs/data/`) to understand real request/response shapes.

---

## Step 3: Verify Branch Readiness

For each impacted project (auto-detected from the plan's "Files to Modify" section, using the same module-to-project mapping as the `git-prep` workflow):

```bash
cd {WORKSPACE_ROOT}/{project} && git branch --show-current
```

Verify the current branch is the feature branch (`develop-{ISSUE_ID}`). If not:
- If the feature branch exists locally, switch to it: `git checkout develop-{ISSUE_ID}`
- If it does not exist, tell the user to run the `git-prep` workflow first and stop.

Also run `git status --porcelain` to confirm a clean working tree before starting.

---

## Step 4: Read Existing Code

Before writing any code, read all files listed in the implementation plan's "Files to Modify" and "Key Code References" sections. This is critical for:

- Understanding the existing code patterns, imports, and style conventions
- Identifying the exact insertion points (line numbers may have drifted since the plan was written)
- Understanding how neighbouring methods are structured so new code matches
- Verifying that referenced methods, classes, and fields actually exist

For each file to modify:
1. Read the full file (or at minimum the relevant method and its surrounding context)
2. Note the actual current line numbers for the insertion points mentioned in the plan
3. Note the imports, annotations, and patterns used
4. If the plan references a test helper or existing test, read those too

Also read:
- At least one existing test in the same test class to understand the mocking/assertion pattern
- The test helper class to understand how test DTOs are constructed
- One existing E2E test to understand the setup/flow/cleanup pattern

Do NOT skip this step. Coding without reading leads to style mismatches and compilation errors.

---

## Step 5: Execute the Implementation Order

Follow the implementation plan's "Implementation Order" section step by step. The typical order is:

### 5.1 Write Unit Tests First (TDD)

For each test case listed in the plan:

1. If the plan specifies a new test helper method, write that first in the test helper class.
2. Write each test method in the specified test class, following the patterns observed in Step 4:
   - Match the test framework annotations (e.g. `@ExtendWith`, `@Mock`, `@InjectMocks`)
   - Match the assertion style (e.g. `StepVerifier`, `assertThat`, `assertEquals`)
   - Match the naming convention of existing tests
   - Use the test helper to construct test data
3. After writing each test, run a quick compilation check:
   ```bash
   cd {WORKSPACE_ROOT}/{project} && mvn compile -pl {module} -Dmaven.test.skip=true
   ```
   Fix any compilation errors before moving on.

The tests WILL fail at this point (the feature code doesn't exist yet). That's expected — this is TDD.

### 5.2 Implement the Feature

Implement the code changes specified in the plan's "Files to Modify" section, in the order listed. For each file:

1. Re-read the file to confirm current state (it may have been modified by test helper additions).
2. Make the changes described in the plan — add methods, modify existing methods, add branches.
3. After each file edit, run a compilation check:
   ```bash
   cd {WORKSPACE_ROOT}/{project} && mvn compile -pl {module} -Dmaven.test.skip=true
   ```
4. Fix any compilation errors immediately before moving to the next file.

Key rules while implementing:
- **Match existing code style exactly** — indentation, brace placement, naming conventions, Javadoc style.
- **Do NOT add or remove comments** unless the plan explicitly says to.
- **Do NOT modify files listed in "Files NOT to Modify"**.
- **Follow the critical constraints** — reactive (Mono<T>), no .block(), atomicity, etc.
- **Refer to the example data files** when unsure about field names, response shapes, or merge behaviour.

### 5.3 Run Unit Tests

Run the unit tests for the modified module:

```bash
cd {WORKSPACE_ROOT}/{project} && mvn test -pl {module}
```

- If all tests pass (including the new ones), proceed to Step 5.4.
- If tests fail:
  1. Read the failure output carefully — identify the root cause.
  2. Distinguish between: (a) new tests failing due to implementation bugs, (b) existing tests regressing.
  3. Fix the implementation (NOT the tests, unless the test itself has a bug).
  4. Re-run until all tests pass.
  5. If stuck after 3 attempts on the same failure, document the issue and ask the user for guidance.

### 5.4 Write E2E Integration Tests

After all unit tests pass and the feature code is committed in the primary project (e.g. `clip-app`), write **black-box E2E tests** that exercise the feature end-to-end by submitting HTTP requests and asserting on the responses — treating all service internals as opaque.

**All E2E tests live in `clip-integrations/clip-int-e2e-test`** because all external requests originate through `clip-integrations`. This is a separate Git project from `clip-app`.

#### 5.4.1 Prep the E2E project

Ensure the `clip-integrations` project has the feature branch checked out (it may need to be created via `prepare` if not already done):

```bash
cd {WORKSPACE_ROOT}/clip-integrations && git branch --show-current
```

If the branch does not exist, create it from `develop`:
```bash
git checkout develop && git pull origin develop && git checkout -b develop-{ISSUE_ID}
```

#### 5.4.2 Understand the E2E test pattern

Before writing, read the following reference files to understand the existing conventions:

| File | Purpose |
|---|---|
| `clip-int-e2e-test/.../core/AbstractE2EUseCaseApp.java` | Base class — provides `clipClients`, `clipIntClients`, `productRegistrationIntegrationsClient`, `gateWayClient`, `preAuthorizationFilter`. Has `injectWebClientOnRandomPortToClipClients(port)` for test WebClient setup. |
| `clip-int-e2e-test/.../core/AbstractE2EUseCaseIntegration.java` | Lighter base class — only `clipIntClients`. Use for tests that only call integration-layer clients. |
| `clip-int-e2e-test/.../suites/HardwareRegistrationWithInternalCustomer.java` | Reference test — shows the full setup→flow→cleanup pattern: create model → create offer → create entitlement → register product → assert response. |
| `clip-int-e2e-test/.../utility/E2ETestUtility.java` | Helpers: `generateModelId()`, `generateOfferId()`, `generateEntitlementId()`, `generateFeatureCode()`, `basepath`, `replacePlaceholder()`. |
| `clip-int-e2e-test/.../utility/E2EBaseTestConstants.java` | Shared constants (e.g. `cswid`). |
| `clip-int-e2e-test/.../data/ProductModelRequestDtoBuilder.java` | Builder for product model DTOs in tests. |
| `clip-int-e2e-test/src/test/resources/jsonfiles/` | JSON fixture templates with `_PLACEHOLDER_` tokens. |

#### 5.4.3 Write the E2E test

Create a new test class under `clip-int-e2e-test/src/test/java/com/dell/delp/clip/integrations/e2e/suites/`.

Follow this pattern:

```java
@Disabled  // Remove when ready to run against a live instance
@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class {FeatureName}E2ETest extends AbstractE2EUseCaseApp {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    @LocalServerPort
    private int port;

    @BeforeEach
    @Override
    public void init() throws IOException {
        injectWebClientOnRandomPortToClipClients(port);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    @Override
    public void flow() throws IOException {
        // 1. Setup: Create product model → create offer → create entitlement → register product
        //    (use E2ETestUtility helpers and JSON fixtures from src/test/resources/jsonfiles/)
        // 2. Exercise: Call the endpoint under test with the feature-specific request
        //    (e.g. productInstanceClient.updateProductInstance() or gateWayClient.put())
        // 3. Assert: Verify response status, fields, and values
        //    - Use StepVerifier.create(mono).consumeNextWith(response -> { ... }).verifyComplete()
        //    - Assert on the response body (not internal DB state — black-box)
        // 4. Optionally: Send a second request to verify idempotency, null-removal, etc.
    }

    @AfterEach
    @Override
    public void cleanup() throws IOException {
        // Clean up test data if needed (e.g. deregister product)
    }
}
```

Key rules:
- **Black-box only** — assert on HTTP response bodies; do NOT query MongoDB directly.
- **Use existing clients** — `clipClients`, `clipIntClients`, `productRegistrationIntegrationsClient`, `gateWayClient` are injected by `AbstractE2EUseCaseApp`.
- **JSON fixtures** — if the feature needs a new request shape, create a JSON template in `src/test/resources/jsonfiles/{feature}/` with `_PLACEHOLDER_` tokens and use `E2ETestUtility.replacePlaceholder()`.
- **Setup prerequisites** — most tests need a product model + offer + entitlement + registered product before exercising the feature endpoint. Follow the existing `HardwareRegistrationWithInternalCustomer` pattern.
- **`@Disabled` by default** — E2E tests require a running environment. Mark with `@Disabled` so they don't break CI. They are run manually or via a dedicated E2E profile.

#### 5.4.4 Compile-check

```bash
cd {WORKSPACE_ROOT}/clip-integrations && mvn compile -pl clip-int-e2e-test -Dmaven.test.skip=true
```

Fix any compilation errors before proceeding.

### 5.5 Run E2E Tests

E2E tests require a running instance of `clip-integrations` (which embeds `clip-app`). There are two options:

**Option A: Run against a local instance** (if the user has one running):
```bash
cd {WORKSPACE_ROOT}/clip-integrations && mvn test -pl clip-int-e2e-test -Dspring.profiles.active=test
```

**Option B: Skip execution, verify compilation only** (typical for CI — tests are `@Disabled`):
```bash
cd {WORKSPACE_ROOT}/clip-integrations && mvn test-compile -pl clip-int-e2e-test
```

Handle failures the same way as Step 5.3. If the E2E test requires a running environment that is not available, note this in the change summary and flag it for manual verification.

#### 5.5.1 Commit E2E test changes in clip-integrations

If E2E test files were added or modified in `clip-integrations`, stage and commit them separately:

```bash
cd {WORKSPACE_ROOT}/clip-integrations && git add -A && git status
```

**IMPORTANT:** The commit message MUST follow the GitLab pre-receive hook pattern:

```bash
git commit -m "JIRA#{ISSUE_ID}; Add E2E integration test for {feature description}"
```

### 5.6 Run Full Verification

If the plan or project has additional verification steps:

- **CheckStyle**: `mvn checkstyle:check -pl {module}` (if the project uses it)
- **Full build**: `mvn clean install -DskipTests` (to verify the entire project compiles)
- **Full test suite**: `mvn test` (if scoped to the project, not the entire workspace)

Fix any issues found.

---

## Step 6: Self-Review

Before committing, perform a self-review of all changes:

```bash
cd {WORKSPACE_ROOT}/{project} && git diff
```

Check for:
- [ ] **Unintended changes** — files modified that shouldn't be, accidental whitespace changes, removed comments
- [ ] **Missing changes** — are all files from the plan's "Files to Modify" actually modified?
- [ ] **Style consistency** — do new methods match the surrounding code style?
- [ ] **Constraint compliance** — review against each item in "Critical Constraints"
- [ ] **Test coverage** — are all test cases from the plan implemented?
- [ ] **No secrets or sensitive data** — no tokens, passwords, or keys in the diff

If any issues are found, fix them and re-run the relevant tests.

---

## Step 7: Commit

Stage and commit all changes with a descriptive message:

```bash
cd {WORKSPACE_ROOT}/{project} && git add -A && git status
```

Review the staged files list. Then commit:

**IMPORTANT:** The commit message MUST follow the GitLab pre-receive hook pattern `(JIRA#[A-Za-z0-9]{2,}-\d+;)`. The message must start with `JIRA#{ISSUE_ID};` — note the `JIRA#` prefix and trailing semicolon.

```bash
git commit -m "$(cat <<'EOF'
JIRA#{ISSUE_ID}; {short description of the feature}

- {brief bullet for each major change}
- Unit tests: {N} new tests added
- E2E tests: {N} new tests added
EOF
)"
```

Do NOT push unless the user explicitly asks.

---

## Step 8: Generate `change-summary.md`

After committing, create (or overwrite) a file at `ai/feature-specs/{ISSUE_ID}/change-summary.md` that captures a complete summary of all changes made across all impacted projects for this feature.

Collect the data from:
- `git diff origin/develop..HEAD --stat` — files changed, insertions, deletions per project
- `git log origin/develop..HEAD --oneline` — commit messages per project
- The implementation plan's "Files to Modify" section — for one-line descriptions of each change
- Test run results from Steps 5.3 and 5.5

Use the following template:

```markdown
# Change Summary — {ISSUE_ID}

- **JIRA Issue:** [{ISSUE_ID}](https://jira.dell.com/browse/{ISSUE_ID})
- **Branch:** `develop-{ISSUE_ID}`
- **Generated:** {today's date}

---

## Overview

{one-paragraph summary of what was implemented, from the feature spec}

---

## Projects Impacted

| # | Project | Files Changed | Insertions | Deletions | Commits |
|---|---------|--------------|------------|-----------|--------|
| 1 | `clip-app` | 5 | +575 | -1 | 1 |

---

## Files Modified

### `clip-app`

| # | File | Change |
|---|------|--------|
| 1 | `RegistrationValidator.java` | Added `isAdditionalInfoOnlyUpdate()` detection method |
| 2 | `ProductInstanceService.java` | Added early-return branch for additional-info-only updates |
{INSERT: one row per modified file per project}

---

## Tests

### Unit Tests

| # | Test Name | Scenario | Result |
|---|-----------|----------|--------|
| 1 | `updateProductInstance_additionalInfoOnly_success` | Happy path: merge additionalInfo, response includes thresholds | ✅ Pass |
{INSERT: one row per test}

**Total:** {PASS}/{TOTAL} passed

### E2E Tests

{INSERT: same format, or "No E2E tests added" if not applicable}

---

## Commits

| # | Project | Hash | Message |
|---|---------|------|---------|
| 1 | `clip-app` | `86e01bbd7` | JIRA#SCLP-3394; Add additionalInfo-only update path |
{INSERT: one row per commit per project}

---

## Verification

- **Compilation:** ✅ Clean
- **Unit tests:** {PASS}/{TOTAL} passed
- **E2E tests:** {PASS}/{TOTAL} passed (or N/A)
- **CheckStyle:** ✅ Pass (or N/A)
```

This file is used by subsequent workflows (`git_push`, `wrap_up`) as the authoritative record of what was changed.

---

## Step 9: Commit `ai/` Repo Changes

The `ai/` directory is a separate Git repository. After generating the change-summary (and any other files written to `ai/` during this workflow — feature specs, LEARNINGS.md, etc.), commit those changes on the feature branch.

### 9.1 Sync workspace-level config files

If any workspace-level configuration files were modified during this session (CLAUDE.md, `.devin/skills/*`, `.windsurf/workflows/*`), copy them to the `ai` repo's mirror:

```powershell
# Only needed if workspace-level files were actually modified
Copy-Item "{WORKSPACE_ROOT}/CLAUDE.md" "{WORKSPACE_ROOT}/ai/do-not-use/CLAUDE.md"
Copy-Item -Recurse -Force "{WORKSPACE_ROOT}/.devin/skills/*" "{WORKSPACE_ROOT}/ai/do-not-use/.devin/skills/"
Copy-Item -Recurse -Force "{WORKSPACE_ROOT}/.windsurf/workflows/*" "{WORKSPACE_ROOT}/ai/do-not-use/.windsurf/workflows/"
```

Skip this sub-step if no workspace-level config files were modified.

### 9.2 Stage and commit

```powershell
cd {WORKSPACE_ROOT}/ai
git add -A
git status
```

If there are staged changes, commit them:

```powershell
git commit -m "JIRA#{ISSUE_ID}; Update feature specs and change summary"
```

If there are no changes to commit, skip this step silently.

**Do NOT push** — the `ai` repo is pushed alongside other projects by the `git_push` workflow.

---

## Step 10: Update JIRA Issue

After committing, update the JIRA issue with a summary of the changes and ensure it is in the correct status.

The JIRA base URL is: `https://jira.dell.com`

### 10.1 Obtain JIRA Credentials

JIRA REST API calls require authentication. Ask the user how they want to authenticate (choose one):

1. **Personal Access Token (PAT)** — passed as `Authorization: Bearer {TOKEN}` header.
2. **Username + API Token / Password** — passed as HTTP Basic Auth (`-u user:token`).

Store the chosen credential for use in steps 10.2 and 10.3. Do **not** log or persist the credential anywhere.

### 10.2 Post a Summary Comment

Add a structured comment to the JIRA issue summarising the files modified, tests written, and verification results. Build the comment body in **JIRA wiki markup** (not Markdown).

#### Comment Template

```
{panel:title=Implementation Complete — develop-{ISSUE_ID}|borderStyle=solid|borderColor=#00875A|bgColor=#E3FCEF}

Commit: {{{{monospace|{SHORT_COMMIT_HASH}}}}} on branch {{develop-{ISSUE_ID}}}

{panel}

h3. Files Modified

||  || File || Change ||
{INSERT: for each modified file, one row: | # | {file path} | {one-line description of what changed} |}

h3. Tests

* *Unit tests added:* {N}
{INSERT: bullet list of each new test by name with its one-line scenario}

* *E2E tests added:* {N} (if applicable)

h3. Verification Results

* *Unit tests:* {PASS_COUNT}/{TOTAL_COUNT} passed
* *Full build:* ✅ Clean (or ❌ with details)

----

_Auto-generated by AI workflow. See attached implementation plan for full details._
```

Escape the comment body for JSON and send via:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"body": "{COMMENT_BODY}"}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/comment"
```

Notes:
- The `{COMMENT_BODY}` must be a JSON-escaped string. Use a Python script or heredoc to handle newlines and special characters properly.
- JIRA wiki markup reference: `{panel}` = bordered box, `h3.` = heading, `||header||` = table header, `|cell|` = table cell, `*bold*` = bold, `* item` = bullet list, `----` = horizontal rule.
- Verify the response returns HTTP 201 with a comment `id`.
- If the upload fails (e.g. 401/403), report the error to the user and ask them to verify credentials and permissions.

### 10.3 Transition to "In Development"

Check the current status of the JIRA issue and transition it to **In Development** if it is not already in that status.

#### 10.3.1 Fetch Current Status

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name` from the response. If the status is already `In Development` (or equivalent), skip the transition and inform the user.

#### 10.3.2 Get Available Transitions

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Search the `transitions` array for an entry whose `name` matches `In Development` (case-insensitive). Extract its `id`.

If no matching transition is found:
- The issue may not have a valid transition path to "In Development" from its current status.
- Report the current status and available transitions to the user and ask how to proceed.

#### 10.3.3 Execute the Transition

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"transition": {"id": "{TRANSITION_ID}"}}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Verify the response returns HTTP 204 (no content = success).

Report to the user:
- Previous status → New status (`In Development`)
- Or: "Status already In Development — no transition needed."

---

## Step 11: Report Results

After all projects are complete, report:

### Summary Table

```
| # | Project   | Files Modified | Tests Added | Tests Passed | Status |
|---|-----------|---------------|-------------|-------------|--------|
| 1 | clip-app  | 4             | 7 unit + 1 E2E | 142/142  | ✅ OK  |
```

### Changes Made
- List each file modified with a one-line description of what changed.

### Tests Written
- List each new test by name with its scenario.

### Verification Results
- Unit tests: pass/fail count
- E2E tests: pass/fail count
- CheckStyle: pass/fail
- Compilation: clean

### Commit
- Branch: `develop-{ISSUE_ID}`
- Commit hash: `{short hash}`
- Commit message: (show it)

### Next Steps
- Suggest: "Push with `git push -u origin develop-{ISSUE_ID}` when ready"
- Suggest: "Create MR to `develop` on GitLab"
- Flag any items that need manual attention (e.g. E2E tests that need a running environment)
- Report JIRA update result: comment posted (or skipped), status transitioned (or already correct / skipped)
- Path to the generated file: `ai/feature-specs/{ISSUE_ID}/change-summary.md`

---

## Error Recovery

If at any point the implementation gets stuck:

1. **Compilation error loop** — if the same compilation error persists after 3 fix attempts, read the surrounding code more carefully. Check imports, generics, and method signatures. If still stuck, ask the user.
2. **Test failure loop** — if a test fails repeatedly, add targeted logging/print statements to isolate the issue. Check whether the mock setup matches the actual call chain.
3. **Scope creep** — if implementing a change requires modifying a file listed in "Files NOT to Modify", stop and ask the user. The plan may need updating.
4. **Missing dependency** — if the code needs a class, method, or field that doesn't exist and isn't mentioned in the plan, search the codebase for it. If truly missing, ask the user whether to create it or adjust the approach.
5. **Merge conflict** — if `git pull` during branch prep causes conflicts, report them to the user rather than attempting to resolve automatically.
6. **JIRA update failure** — if posting the comment or transitioning the status fails (401/403/404), report the error to the user but do NOT treat it as a workflow failure. The code changes and commit are already complete; the JIRA update is a best-effort post-commit step. Ask the user to verify credentials/permissions and retry manually if needed.

At any failure point, ensure the working tree is in a compilable state before asking for help. If you've made partial changes that compile, commit them with a `WIP:` prefix so work isn't lost.
