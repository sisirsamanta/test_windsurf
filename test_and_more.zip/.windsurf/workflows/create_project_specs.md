---
description: Generate project specs (functional, technical, data model, API, integration, security, deployment, NFR) by analyzing the codebase
---

# Create Specs Workflow

Generate comprehensive specification documents by analyzing the current repository. Supports the following spec types:

1. **Functional Specs** (includes functional flows & variations as Mermaid diagrams)
2. **Technical Specs**
3. **Data Model Specs**
4. **API Specs**
5. **Integration Specs**
6. **Security Specs**
7. **Deployment / Infrastructure Specs**
8. **Non-Functional Requirements (NFR) Specs**

---

## Step 1: Discover Project Structure

Scan the repository to understand the project layout:

- Identify the programming language(s), frameworks, and build tools in use.
- List all modules/packages/services and their purpose.
- Identify configuration files (application.yml, pom.xml, package.json, Dockerfile, etc.).
- Identify test directories and test frameworks.
- Identify any existing documentation (README, docs/, wiki/, specs/).

Summarize findings before proceeding.

---

## Step 2: Ask the User Which Specs to Generate

Ask the user which spec types to generate from the list above. Default is all 8 if no preference is given.
Also ask where the output files should be written (default: `ai/specs/` in the repo root).

---

## Step 3: Generate Functional Specs

Create `ai/specs/functional-spec.md` covering:

### 3.1 Overview
- Purpose of the application / service.
- Key business problems it solves.

### 3.2 Actors & Roles
- Who are the users / systems interacting with this application?
- What roles and permissions exist?

### 3.3 Features & Use Cases
- For each module/feature discovered in Step 1, document:
  - **Feature name**
  - **Description** — what it does in business terms.
  - **Inputs / Triggers** — what initiates this feature.
  - **Expected behavior / Outputs** — what the system does.
  - **Edge cases & error handling** — known failure modes.

### 3.4 Business Rules
- List all business rules, validations, and constraints found in the code (annotations, validators, conditional logic).

### 3.5 Functional Flows & Variations
For each key feature / use case, trace the actual function call chain through the codebase and produce:

- **Happy-path flow** — a Mermaid `sequenceDiagram` or `flowchart` showing the primary call chain from entry point (controller/router) through service, repository, and external calls to the final response.
- **Variation / alternate flows** — additional Mermaid diagrams for significant branches (e.g., cache hit vs. miss, sync vs. async path, batch vs. single item).
- **Error / exception flows** — Mermaid diagrams showing how exceptions propagate and where they are caught or translated.

For each flow diagram, include:
- The **trigger** (HTTP request, scheduled job, message consumed, etc.).
- Each **class/method** involved, in call order.
- **Decision points** (conditionals, feature flags, role checks) as diamond nodes or alt blocks.
- **External interactions** (DB queries, API calls, message publishes) clearly labeled.

Example format to use in the generated spec:

````markdown
#### 3.5.1 Create Product — Happy Path

```mermaid
sequenceDiagram
    participant Client
    participant ProductController
    participant ProductService
    participant ValidationUtil
    participant ProductRepository
    participant AuditService

    Client->>ProductController: POST /api/v1/products
    ProductController->>ProductService: createProduct(dto)
    ProductService->>ValidationUtil: validate(dto)
    ValidationUtil-->>ProductService: valid
    ProductService->>ProductRepository: save(entity)
    ProductRepository-->>ProductService: savedEntity
    ProductService->>AuditService: logCreation(entity)
    ProductService-->>ProductController: responseDto
    ProductController-->>Client: 201 Created
```

#### 3.5.2 Create Product — Validation Failure

```mermaid
sequenceDiagram
    participant Client
    participant ProductController
    participant ProductService
    participant ValidationUtil

    Client->>ProductController: POST /api/v1/products
    ProductController->>ProductService: createProduct(dto)
    ProductService->>ValidationUtil: validate(dto)
    ValidationUtil-->>ProductService: ValidationException
    ProductService-->>ProductController: throws ValidationException
    ProductController-->>Client: 400 Bad Request
```
````

---

## Step 4: Generate Technical Specs

Create `ai/specs/technical-spec.md` covering:

### 4.1 Architecture Overview
- High-level architecture style (monolith, microservices, modular monolith, event-driven, etc.).
- Component / service diagram description (list services and how they connect).

### 4.2 Technology Stack
- Language version, framework version, key libraries with versions.
- Build tool, dependency management.
- Database(s), message brokers, caches.

### 4.3 Module / Package Breakdown
- For each module:
  - **Purpose**
  - **Key classes / files** and their responsibilities.
  - **Design patterns** used (repository, factory, strategy, etc.).

### 4.4 Control Flow
- Request lifecycle: how a request enters the system, gets processed, and returns a response.
- Key processing pipelines or workflows.

### 4.5 Error Handling Strategy
- Exception hierarchy, global error handlers, retry logic.

### 4.6 Configuration & Environment
- Configuration properties and what they control.
- Environment-specific behavior.

### 4.7 Testing Strategy
- Test types present (unit, integration, e2e, contract).
- Test frameworks and coverage tools.

---

## Step 5: Generate Data Model Specs

Create `ai/specs/data-model-spec.md` covering:

### 5.1 Entities / Tables
- For each entity/model class or DB table:
  - **Entity name**
  - **Table name** (if different)
  - **Fields**: name, type, constraints (nullable, unique, default, length).
  - **Primary key** and generation strategy.

### 5.2 Relationships
- Document all relationships (one-to-one, one-to-many, many-to-many).
- Foreign keys and join tables.
- Cascade and fetch strategies.

### 5.3 Indexes & Constraints
- Unique constraints, composite keys, custom indexes.

### 5.4 Enums & Reference Data
- All enums and lookup/reference tables.

### 5.5 Migration / Schema Management
- How schema changes are managed (Flyway, Liquibase, Alembic, manual SQL, etc.).
- List existing migration scripts if any.

### 5.6 Entity Relationship Summary
- A text-based ER summary showing all entities and their relationships in a concise format.

---

## Step 6: Generate API Specs

Create `ai/specs/api-spec.md` covering:

### 6.1 API Style
- REST, GraphQL, gRPC, SOAP, or a mix.

### 6.2 Endpoints
- For each endpoint:
  - **Method + Path** (e.g., `POST /api/v1/products`)
  - **Description**
  - **Request** — headers, path params, query params, request body (with field types).
  - **Response** — status codes, response body schema.
  - **Authentication / Authorization** — required roles or scopes.

### 6.3 Common Patterns
- Pagination, sorting, filtering conventions.
- Error response format.
- Versioning strategy.

### 6.4 API Clients (outbound)
- External APIs this service calls, including base URLs, auth, and endpoints used.

---

## Step 7: Generate Integration Specs (if applicable)

Create `ai/specs/integration-spec.md` covering:

### 7.1 External System Dependencies
- For each external system:
  - **System name**
  - **Protocol** (HTTP, gRPC, messaging, file, DB link).
  - **Direction** (inbound, outbound, bidirectional).
  - **Data exchanged** — key fields and formats.

### 7.2 Messaging / Events
- Message brokers in use (Kafka, RabbitMQ, SQS, etc.).
- Topics/queues — producers and consumers.
- Event schemas and contracts.

### 7.3 Synchronous Integrations
- Service-to-service calls, Feign clients, REST templates, gRPC stubs.

### 7.4 Data Synchronization
- Batch jobs, ETL, CDC, or scheduled sync processes.

---

## Step 8: Generate Security Specs

Create `ai/specs/security-spec.md` covering:

### 8.1 Authentication
- Mechanism (OAuth2, JWT, SAML, API keys, basic auth).
- Token handling, session management.

### 8.2 Authorization
- Role-based or attribute-based access control.
- Endpoint-level security annotations/config.
- Resource-level permissions.

### 8.3 Data Protection
- Encryption at rest and in transit.
- Sensitive data handling (PII masking, secrets management).
- Input validation and sanitization.

### 8.4 Security Dependencies
- Security libraries and frameworks used.

---

## Step 9: Generate Deployment / Infrastructure Specs

Create `ai/specs/deployment-spec.md` covering:

### 9.1 Build & Package
- Build commands, artifact type (JAR, Docker image, binary).

### 9.2 Containerization
- Dockerfile analysis, base image, exposed ports, entrypoint.

### 9.3 Orchestration
- Kubernetes manifests, Helm charts, docker-compose, ECS task definitions.
- Replicas, resource limits, health probes.

### 9.4 CI/CD
- Pipeline files (Jenkinsfile, GitHub Actions, GitLab CI, etc.).
- Stages: build, test, scan, deploy.

### 9.5 Environment Configuration
- Environment variables and config maps.
- Secrets management approach.

### 9.6 Observability
- Logging framework and format.
- Metrics (Prometheus, Micrometer, etc.).
- Tracing (OpenTelemetry, Zipkin, Jaeger).
- Alerting rules if present.

---

## Step 10: Generate Non-Functional Requirements (NFR) Specs

Create `ai/specs/nfr-spec.md` covering:

### 10.1 Performance
- Caching strategies observed (in-memory, Redis, HTTP cache headers).
- Async / non-blocking patterns (CompletableFuture, reactive streams, async annotations).
- Batch processing and bulk operations.
- Connection pooling configuration.
- Known performance-sensitive code paths.

### 10.2 Scalability
- Horizontal scaling indicators (stateless design, distributed caching, partitioning).
- Rate limiting or throttling mechanisms.
- Queue-based load leveling.

### 10.3 Availability & Resilience
- Retry policies and configuration (exponential backoff, max retries).
- Circuit breaker patterns (Resilience4j, Hystrix, Polly).
- Health check endpoints and liveness/readiness probes.
- Graceful shutdown handling.
- Failover or redundancy patterns.

### 10.4 Reliability
- Idempotency guarantees on writes.
- Transaction management (boundaries, isolation levels, distributed transactions).
- Data consistency strategies (eventual vs. strong).
- Dead-letter queue handling.

### 10.5 Observability
- Logging levels, structured logging, correlation IDs.
- Metrics exposed (Micrometer, Prometheus, custom counters).
- Distributed tracing (OpenTelemetry, Zipkin, Jaeger).
- Alerting rules or SLO/SLI definitions if present.

### 10.6 Maintainability
- Code modularity and separation of concerns.
- Configuration externalization.
- Feature flags or toggles.
- Documentation coverage.

---

## Step 11: Review & Finalize

- Present a summary of all generated spec files with line counts.
- Ask the user to review and flag any sections that need more detail.
- Offer to regenerate or expand specific sections on request.
