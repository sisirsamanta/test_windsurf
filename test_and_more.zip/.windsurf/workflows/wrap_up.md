---
description: Clean up feature branches after all MRs are merged to develop, update per-project functional history, publish a Confluence summary page, then transition the JIRA issue to Complete with a coding summary comment
---

# Wrap Up Workflow

Delete local (and optionally remote) feature branches after all Merge Requests have been merged to `develop`, update per-project functional modification history, publish a Confluence summary page, post a coding summary comment to the JIRA issue, and transition it to **Complete**.

**Pre-condition:** All MRs for this feature must already be merged. This workflow does NOT merge anything — it only cleans up afterwards.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now. The feature branch name is `develop-{ISSUE_ID}`.

---

## Step 2: Load Authentication Tokens

Read the file `local.config` at the workspace root using the read_file tool. Parse the `KEY=VALUE` pairs to extract:

- `JIRA_PAT` — for JIRA REST API calls
- `GIT_PAT` — for GitLab API calls (if needed to verify MR status)
- `CONFLUENCE_PAT` — (optional) for Confluence REST API calls
- `CONFLUENCE_PARENT` — (optional) full URL of the parent Confluence page

If the file does not exist or `JIRA_PAT`/`GIT_PAT` are missing, ask the user to provide them. If `CONFLUENCE_PAT` or `CONFLUENCE_PARENT` are missing, the Confluence step (Step 9) will be silently skipped.

---

## Step 3: Verify All MRs Are Merged

Before deleting any branches, confirm that every MR from `develop-{ISSUE_ID}` to `develop` has been merged.

For each project that has the feature branch locally, check the remote:

```powershell
cd {WORKSPACE_ROOT}/{project}
git fetch origin
git branch -r --list "origin/develop-{ISSUE_ID}"
```

If the remote branch still exists, check its MR status via the GitLab API:

```powershell
$token = "{GIT_PAT}"
$headers = @{ "PRIVATE-TOKEN" = $token }
Invoke-RestMethod `
  -Uri "https://gitlab.dell.com/api/v4/projects/{ENCODED_PROJECT_PATH}/merge_requests?source_branch=develop-{ISSUE_ID}&target_branch=develop&state=merged" `
  -Headers $headers
```

For each project, determine the status:

|| MR State | Action |
||---|---|
|| **merged** | Safe to delete branch — proceed |
|| **opened** (still open) | **STOP** — report to user that this MR is not yet merged. Do NOT delete the branch. |
|| **no MR found** but remote branch exists | Warn user — branch was pushed but no MR was created or it was closed without merging. Ask how to proceed. |
|| **no remote branch, no MR** but local branch exists | The remote branch was already deleted (likely by GitLab after MR merge). Safe to delete local branch. |

Present a summary to the user for confirmation before proceeding:

> MR verification for `develop-SCLP-3394`:
> - `clip-app`: MR !1264 merged — safe to delete
> - `clip-integrations`: no feature branch — nothing to do
>
> Proceed with branch cleanup?

**Do NOT proceed if any MR is still open.** Ask the user to merge or close it first.

---

## Step 4: Delete Feature Branches

For each project where the MR is confirmed merged (or the remote branch is already gone):

### 4.1 Switch to `develop` and pull latest

```powershell
cd {WORKSPACE_ROOT}/{project}
git checkout develop
git pull origin develop
```

### 4.2 Delete the local feature branch

```powershell
git branch -D develop-{ISSUE_ID}
```

### 4.3 Delete the remote feature branch (if it still exists)

GitLab's "Remove source branch on merge" setting usually handles this automatically. But if the remote branch still exists:

```powershell
git push origin --delete develop-{ISSUE_ID}
```

### 4.4 Prune stale remote-tracking references

```powershell
git fetch --prune
```

### Error Handling

|| Error | Action |
||---|---|
|| `checkout develop` fails | Try `git fetch origin develop && git checkout develop` |
|| `branch -D` fails ("not fully merged") | The branch has unmerged commits. **STOP** and report to user — this may indicate the MR was not actually merged, or there are extra local commits not in the MR. |
|| `push --delete` fails (branch not found) | Already deleted remotely — this is fine, continue. |
|| `push --delete` fails (permission denied) | Report to user — they may need to delete it manually via GitLab UI. Non-blocking. |

---

## Step 5: Gather Coding Summary

Before updating JIRA, collect a summary of all work done for this feature. Read the following sources:

### 5.1 From the feature spec and implementation plan

Read `ai/feature-specs/{ISSUE_ID}/feature-spec.md` and `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` to extract:

- **Feature summary** — one-paragraph description of what was implemented
- **Functional requirements** — count of FRs and brief list
- **Files modified** — from the implementation plan's "Files to Modify" section

### 5.2 From Git history

For each project that had the feature branch, retrieve the commit log that was merged:

```powershell
cd {WORKSPACE_ROOT}/{project}
git log "origin/develop" --oneline --grep="JIRA#{ISSUE_ID}" -n 20
```

Extract:
- Number of commits
- Short commit messages
- Files changed (from the merge commit or squashed commit)

### 5.3 From GitLab MR

For each project, fetch the merged MR details:

```powershell
$token = "{GIT_PAT}"
$headers = @{ "PRIVATE-TOKEN" = $token }
$mr = Invoke-RestMethod `
  -Uri "https://gitlab.dell.com/api/v4/projects/{ENCODED_PROJECT_PATH}/merge_requests?source_branch=develop-{ISSUE_ID}&target_branch=develop&state=merged" `
  -Headers $headers
$mr | ConvertTo-Json -Depth 5
```

Extract: MR title, MR URL, merge date, number of changes.

---

## Step 6: Post Coding Summary Comment to JIRA

Using the JIRA PAT from `local.config`, post a structured summary comment to the JIRA issue.

### Comment Template (JIRA Wiki Markup)

```
{panel:title=Feature Complete — develop-{ISSUE_ID}|borderStyle=solid|borderColor=#00875A|bgColor=#E3FCEF}

All merge requests have been merged to {{develop}} and feature branches cleaned up.

{panel}

h3. Summary

{INSERT: one-paragraph feature summary from the feature spec}

h3. Merge Requests

||| # || Project || MR || Status || Merged ||
{INSERT: for each project with an MR: | # | project name | MR link | Merged | merge date |}

h3. Files Modified

||| # || File || Change ||
{INSERT: for each modified file: | # | file path | one-line description |}

h3. Tests

* *Unit tests added:* {N}
* *E2E tests added:* {N}
{INSERT: bullet list of test names if available from the implementation plan}

h3. Commits

{INSERT: list of commit hashes and messages from git log}

h3. Artifacts

* Feature spec: {{ai/feature-specs/{ISSUE_ID}/feature-spec.md}}
* Implementation plan: {{ai/feature-specs/{ISSUE_ID}/implementation_plan.md}}

----

_Auto-generated by wrap_up workflow._
```

### Post the comment

```powershell
$pat = "{JIRA_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$body = @{ body = "{COMMENT_BODY}" } | ConvertTo-Json
Invoke-RestMethod `
  -Method Post `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/comment" `
  -Headers $headers `
  -Body $body
```

Verify the response returns HTTP 201 with a comment `id`.

---

## Step 6b: Add `AI-Delivered` Label to JIRA

Add a static label `AI-Delivered` to the JIRA issue so AI-delivered work can be tracked for reporting purposes.

```powershell
$pat = "{JIRA_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$body = @{
  update = @{
    labels = @(
      @{ add = "AI-Delivered" }
    )
  }
} | ConvertTo-Json -Depth 5
Invoke-RestMethod `
  -Method Put `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}" `
  -Headers $headers `
  -Body $body
```

This uses the JIRA `update` field operation to **add** the label without removing any existing labels on the issue.

### Error Handling

|| Problem | Solution |
||---|---|
|| **200/204** | Success — label added. |
|| **401/403** | Authentication or permission failure. Report but do NOT fail the workflow. |
|| **404** | Issue not found. Report. |
|| **Network error** | Report but do NOT fail the workflow. Branch cleanup is already done. |

Do NOT treat a JIRA label failure as a workflow failure. Branch cleanup is already done; JIRA updates are best-effort.

---

## Step 7: Transition JIRA to Complete

### 7.1 Fetch Current Status

```powershell
$pat = "{JIRA_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$issue = Invoke-RestMethod `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=status" `
  -Headers $headers
$issue.fields.status.name
```

If the status is already `Complete` (or equivalent like `Done`, `Closed`), skip the transition and inform the user.

### 7.2 Get Available Transitions

```powershell
$transitions = Invoke-RestMethod `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions" `
  -Headers $headers
$transitions.transitions | Select-Object id, name | ConvertTo-Json
```

Search for a transition whose `name` matches `Complete` or `Done` (case-insensitive). Extract its `id`.

If no matching transition is found:
- Report the current status and all available transitions to the user.
- Ask which transition to use, or whether to skip.

### 7.3 Execute the Transition

```powershell
$body = @{ transition = @{ id = "{TRANSITION_ID}" } } | ConvertTo-Json
Invoke-RestMethod `
  -Method Post `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions" `
  -Headers $headers `
  -Body $body `
  -StatusCodeVariable "statusCode"
```

Verify the response returns HTTP 204 (success).

### Error Handling

|| Problem | Solution |
||---|---|
|| **401 Unauthorized** | PAT may be expired. Ask user to update `local.config`. |
|| **403 Forbidden** | User may lack "Transition Issues" permission. Report to user. |
|| **No matching transition** | Report current status and available transitions; ask user which one to use. |
|| **Network error** | Report to user. Branches are already cleaned up — JIRA update can be retried manually. |

Do NOT treat a JIRA update failure as a workflow failure. Branch cleanup is already done; JIRA updates are best-effort.

---

## Step 8: Update Per-Project Functional Modification History

Append a reverse-chronological entry to the functional modification history file for each project that had a merged MR in this feature. This provides a durable, human- and AI-readable changelog per project.

### 8.1 Directory and file structure

History files live at:

```
ai/project-history/
├── clip-app.md
├── clip-integrations.md
├── clip-control-plane.md
├── clip-app-query.md
├── clip-client-java.md
└── clip-client-c.md
```

Each file corresponds to one Git project. If the directory or file does not exist, create it.

### 8.2 Determine issue type

Fetch the JIRA issue type if not already known:

```powershell
$pat = "{JIRA_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$issue = Invoke-RestMethod `
  -Uri "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=issuetype,summary" `
  -Headers $headers
$issue.fields.issuetype.name
```

Map `fields.issuetype.name` to the entry type:
- `Story`, `Feature`, `Enhancement` → **Feature**
- `Bug`, `Defect` → **Defect**
- `Task`, `Sub-task`, `Config Change` → **Task**
- Anything else → use the raw issue type name

### 8.3 Gather entry data (from Step 5 outputs)

For each project with a merged MR, collect:
- **Date**: Use the MR `merged_at` date, formatted as `YYYY-MM-DD`.
- **ISSUE_ID**: The JIRA issue ID (e.g., `SCLP-3394`).
- **Title**: The JIRA issue summary (e.g., "Additional Info Only Update Registration").
- **Type**: From Step 8.2 above.
- **Modules affected**: Infer from the MR file paths — extract the Maven module name from the path (e.g., `clip-product-instance/src/...` → `clip-product-instance`). List unique modules.
- **Files modified**: List the key source files changed (from Step 5.3 MR changes), excluding test files. Use just the file name (e.g., `RegistrationValidator.java`), not the full path. Limit to 10 files; if more, append `(+N more)`.
- **Summary**: 1–3 sentence functional description of what changed and why. Derive from the feature spec summary or MR title. Focus on **business/functional intent**, not code-level detail.
- **MR**: The MR reference in the format `!{iid}` (e.g., `!1264`).

### 8.4 Entry format

Each entry follows this exact markdown format:

```markdown
## {YYYY-MM-DD} | {ISSUE_ID} | {JIRA Summary Title}

**Type**: {Feature|Defect|Task}
**Modules affected**: {module-1}, {module-2}
**Files modified**: {File1.java}, {File2.java}, {File3.java}
**Summary**: {1-3 sentence functional description of what changed and why}
**MR**: !{iid}
```

### 8.5 Append to history file

For each project with a merged MR:

1. **If the file does not exist**, create it with a title header:
   ```markdown
   # {project-name} — Functional Modification History

   ```
   Then append the entry below the header.

2. **If the file already exists**, insert the new entry **immediately after the title header line** (and any blank line following it). This keeps the file in **reverse chronological order** (newest first).

3. **Ensure a blank line** separates the new entry from any existing entries below it.

### 8.6 Cross-project entries

If the feature spans multiple projects (e.g., `clip-app` and `clip-integrations` both had MRs), append an entry to **each** project's history file. Each entry should reference only the modules and files relevant to **that specific project**.

### 8.7 Error handling

- If the `ai/project-history/` directory does not exist, create it.
- If writing a history file fails, report the failure but do NOT fail the workflow. This step is best-effort.
- Never overwrite or compact existing history entries. This file is append-only (prepend to body).

### 8.8 Commit `ai/` repo changes

The `ai/` directory is a separate Git repository. After updating project-history files, sync any modified workspace-level config files and commit.

**Sync workspace-level config files** (only if modified during this session):

```powershell
Copy-Item "{WORKSPACE_ROOT}/CLAUDE.md" "{WORKSPACE_ROOT}/ai/do-not-use/CLAUDE.md"
Copy-Item -Recurse -Force "{WORKSPACE_ROOT}/.devin/skills/*" "{WORKSPACE_ROOT}/ai/do-not-use/.devin/skills/"
Copy-Item -Recurse -Force "{WORKSPACE_ROOT}/.windsurf/workflows/*" "{WORKSPACE_ROOT}/ai/do-not-use/.windsurf/workflows/"
```

**Stage and commit:**

```powershell
cd {WORKSPACE_ROOT}/ai
git add -A
git status
```

If there are staged changes, commit them:

```powershell
git commit -m "JIRA#{ISSUE_ID}; Update project history after wrap-up"
```

If there are no changes to commit, skip silently. If the `ai` repo is on `develop` (not a feature branch), push the commit directly — project-history updates are low-risk, append-only changes.

---

## Step 9: Publish Confluence Summary Page

Create a detailed summary page on Confluence under the configured parent page. **This entire step is optional** — skip it silently if any of the following are true:

- `CONFLUENCE_PAT` is missing, empty, or not set in `local.config`
- `CONFLUENCE_PARENT` is missing, empty, or not set in `local.config`
- The parent page ID cannot be extracted from `CONFLUENCE_PARENT`
- The Confluence API is unreachable

### 9.1 Parse parent page URL

Extract the **space key** and **parent page ID** from the `CONFLUENCE_PARENT` URL.

The URL follows the pattern: `https://confluence.dell.com/spaces/{SPACE_KEY}/pages/{PAGE_ID}/{Page+Title}`

```powershell
# Example: https://confluence.dell.com/spaces/DF/pages/1286841426/FY27+-+DL+Features+Delivery
$url = "{CONFLUENCE_PARENT}"
if ($url -match '/spaces/([^/]+)/pages/(\d+)') {
    $spaceKey = $Matches[1]
    $parentPageId = $Matches[2]
}
```

If either `$spaceKey` or `$parentPageId` is empty after parsing, log a warning and skip this step.

### 9.2 Verify parent page exists

```powershell
$pat = "{CONFLUENCE_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$response = Invoke-RestMethod `
  -Uri "https://confluence.dell.com/rest/api/content/${parentPageId}?expand=space" `
  -Headers $headers
```

If the request fails, log a warning ("Confluence parent page not accessible — skipping Confluence publish") and skip this step. Do NOT fail the workflow.

### 9.3 Generate page title

Construct the page title in the format:

```
{ISSUE_ID} - {Short Heading}
```

Where `{Short Heading}` is a **maximum 5-word** summary derived from the JIRA issue summary. Condense the JIRA summary into at most 5 words that capture the essence of the change.

Examples:
- JIRA summary "Additional Info Only Update Registration" → `SCLP-3394 - AdditionalInfo Only Update Registration`
- JIRA summary "Fix entitlement count mismatch when multiple pools exist for same model" → `SCLP-3380 - Fix Entitlement Count Mismatch`
- JIRA summary "Add hardware serial validation to registration endpoint" → `SCLP-3401 - HW Serial Registration Validation`

### 9.4 Build page content

Compose the page body in **Confluence Storage Format** (XHTML). The page must contain the following sections in order:

```html
<h2>Overview</h2>
<table>
  <tbody>
    <tr><th>JIRA Issue</th><td><a href="https://jira.dell.com/browse/{ISSUE_ID}">{ISSUE_ID}</a></td></tr>
    <tr><th>Type</th><td>{Issue Type — Feature/Defect/Task}</td></tr>
    <tr><th>Priority</th><td>{Priority from JIRA}</td></tr>
    <tr><th>Status</th><td>Complete</td></tr>
    <tr><th>Completion Date</th><td>{YYYY-MM-DD — date of the last MR merge}</td></tr>
    <tr><th>Delivered By</th><td>AI-Assisted (Devin/Windsurf)</td></tr>
  </tbody>
</table>

<h2>Functional Summary</h2>
<p>{2-4 sentence description of what was implemented, the business problem it solves, and who is impacted. Derive from feature-spec.md overview section.}</p>

<h2>Technical Summary</h2>
<p>{2-4 sentence description of the technical approach taken — architecture patterns used, key design decisions, technology choices. Derive from the implementation plan approach section.}</p>

<h2>Changes by Project</h2>
{For each project that had a merged MR, include a sub-section:}

<h3>{project-name} (MR !{iid})</h3>
<p><strong>MR Link:</strong> <a href="{mr_web_url}">!{iid} — {mr_title}</a></p>
<p><strong>Merged:</strong> {YYYY-MM-DD}</p>
<p><strong>Modules affected:</strong> {comma-separated list of Maven modules}</p>
<table>
  <thead><tr><th>File</th><th>Change</th><th>Description</th></tr></thead>
  <tbody>
    <tr><td><code>{file_path}</code></td><td>{Added|Modified|Deleted}</td><td>{One-line description of what changed in this file}</td></tr>
    {... repeat for each file, limit to 20 most significant files ...}
  </tbody>
</table>

<h2>Key Design Decisions</h2>
<ul>
  <li>{Decision 1 — e.g., "Used three-way merge for additionalInfo to preserve existing keys while allowing removals via explicit null."}</li>
  <li>{Decision 2 — e.g., "Bypassed commerce validation for metadata-only updates to reduce coupling."}</li>
  {... 2-5 bullet points derived from the implementation plan and feature spec ...}
</ul>

<h2>Testing</h2>
<table>
  <thead><tr><th>Test Type</th><th>Test Class</th><th>Project</th><th>Status</th></tr></thead>
  <tbody>
    <tr><td>Unit</td><td><code>{TestClassName}</code></td><td>{project}</td><td>Pass</td></tr>
    <tr><td>E2E</td><td><code>{E2ETestClassName}</code></td><td>{project}</td><td>Pass</td></tr>
    {... repeat for each test class added or modified ...}
  </tbody>
</table>

<h2>Commits</h2>
<table>
  <thead><tr><th>Project</th><th>Hash</th><th>Message</th></tr></thead>
  <tbody>
    <tr><td>{project}</td><td><code>{short_hash}</code></td><td>{commit message}</td></tr>
    {... repeat for each commit ...}
  </tbody>
</table>

<h2>Artifacts</h2>
<ul>
  <li><strong>Feature Spec:</strong> <code>ai/feature-specs/{ISSUE_ID}/feature-spec.md</code></li>
  <li><strong>Implementation Plan:</strong> <code>ai/feature-specs/{ISSUE_ID}/implementation-plan.md</code></li>
  <li><strong>Project History:</strong> <code>ai/project-history/{project}.md</code> (per impacted project)</li>
</ul>
```

**Content rules:**
- All text must be derived from actual data gathered in Steps 5–8. Do not invent or hallucinate details.
- The Functional Summary should be business-oriented and non-technical — suitable for a PM or stakeholder audience.
- The Technical Summary should be developer-oriented — suitable for peer engineers reviewing the architecture.
- File descriptions in the "Changes by Project" table should be one-line functional summaries, not raw diffs.
- Limit file tables to 20 rows per project. If more files were changed, add a final row: `<tr><td colspan="3"><em>... and {N} more files</em></td></tr>`.
- Key Design Decisions should focus on non-obvious choices — things a future developer would want to know.

### 9.5 Create the Confluence page

```powershell
$pat = "{CONFLUENCE_PAT}"
$headers = @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$body = @{
  type = "page"
  title = "{PAGE_TITLE}"
  ancestors = @( @{ id = $parentPageId } )
  space = @{ key = $spaceKey }
  body = @{
    storage = @{
      value = "{ESCAPED_HTML_CONTENT}"
      representation = "storage"
    }
  }
} | ConvertTo-Json -Depth 5
Invoke-RestMethod `
  -Method Post `
  -Uri "https://confluence.dell.com/rest/api/content" `
  -Headers $headers `
  -Body $body
```

### 9.6 Error handling

| Response | Action |
|---|---|
| `200` | Success. Record the page URL from `response._links.webui` for the final report. |
| `401`/`403` | Auth failure. Log warning: "Confluence auth failed — skipping page creation." Continue workflow. |
| `404` | Parent page not found. Log warning. Continue workflow. |
| `409` | Page title already exists. Log warning: "Confluence page already exists — skipping creation." Continue workflow. |
| Network error | Log warning. Continue workflow. |

**Confluence failure is NOT a workflow failure.** This step is entirely best-effort. Branch cleanup, JIRA updates, and project history are the primary objectives.

---

## Step 10: Report Results

After all steps are complete, report a summary:

### Branch Cleanup

```
|| # | Project            | Local Branch | Remote Branch | Status           |
||---|--------------------|-------------|---------------|------------------|
|| 1 | clip-app           | Deleted      | Deleted       | Clean            |
|| 2 | clip-integrations  | — (none)     | — (none)      | No action needed |
```

### JIRA Update

- **Comment posted:** (success or failure with reason)
- **Label added:** `AI-Delivered` (success or failure with reason)
- **Status transitioned:** `In Development` → `Complete` (or already complete / skipped / failed with reason)

### Project History

- **Updated:** `ai/project-history/clip-app.md` (or list of updated files)
- (or: No projects required history updates)

### Confluence

- **Page created:** [{PAGE_TITLE}]({PAGE_URL}) under [{PARENT_PAGE_TITLE}]({CONFLUENCE_PARENT})
- (or: Skipped — `CONFLUENCE_PAT` / `CONFLUENCE_PARENT` not configured)
- (or: Skipped — error: {reason})

### Summary

- Feature branch `develop-{ISSUE_ID}` has been fully cleaned up.
- All projects are back on `develop` with latest changes pulled.
- JIRA issue {ISSUE_ID} is marked Complete.
- Project history updated for N project(s).
- Confluence summary page published (or skipped).

### Artifacts Retained

- `ai/feature-specs/{ISSUE_ID}/feature-spec.md` — feature specification (kept for reference)
- `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` — implementation plan (kept for reference)
- `ai/project-history/{project}.md` — per-project functional changelog
