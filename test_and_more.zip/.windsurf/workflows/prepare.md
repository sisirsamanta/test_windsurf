---
description: Prepare for feature implementation by attaching specs to JIRA, creating feature branches across workspace repos, and transitioning the JIRA issue to In Development
---

# Prepare Workflow

Attach the generated spec documents (`feature-spec.md`, `implementation_plan.md`) to a JIRA issue, post a structured summary comment, create feature branches across all impacted projects, and transition the issue to **In Development**.

---

## Step 1: Obtain the JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), ask for it now. This ID is used to name the feature branch: `develop-{ISSUE_ID}`.

---

## Step 2: Verify Local Artifacts Exist

Check that the following files exist under `ai/feature-specs/{ISSUE_ID}/`:

- `feature-spec.md`
- `implementation_plan.md`

If either file is missing, inform the user and suggest running the appropriate workflow first (`create_feature_specs` or `create_implementation_plan`).

Read both files so their content is available for building the summary comment in Step 6.

---

## Step 3: Determine Which Projects to Prep

The workspace contains the following Git repositories:

| # | Project | Description |
|---|---|---|
| 1 | `clip-app` | Core CLIP API (modular monolith) |
| 2 | `clip-integrations` | Dell-specific integration wrapper over clip-app |
| 3 | `clip-control-plane` | Background processing & control-plane operations |
| 4 | `clip-app-query` | Read-side query service (CQRS) |
| 5 | `clip-client-java` | Java SDK for product integration |
| 6 | `clip-client-c` | C/C++ native SDK |
| 7 | `clip-config-server` | Configuration server |
| 8 | `clip-delegated-server` | Delegated operations server |
| 9 | `clip-demo-app` | Reference / demo application |
| 10 | `clip-mcp-server` | MCP server for AI assistants |
| 11 | `ai` | AI specs, project specs, flows, scripts |

> **Note:** The `ai` project should **always be included** in the prep list regardless of detection method. Every SDLC workflow writes files to `ai/` (feature specs, implementation plans, change summaries, project history, LEARNINGS.md), so it always needs a feature branch.

Use the following priority order to determine which projects to prep:

### Priority 1: Auto-detect from feature spec (preferred)

Check if `ai/feature-specs/{ISSUE_ID}/feature-spec.md` or `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` exists. If so, read both files and extract the impacted projects by looking for:

- Explicit project references (e.g. "clip-app project only", "clip-integrations changes needed")
- Module paths that imply a project (e.g. `clip-product-instance/src/...` → `clip-app`, `clip-int-product/src/...` → `clip-integrations`)
- "Files to Modify" and "Files NOT to Modify" sections in the implementation plan
- "Impacted Areas" table in the feature spec

Map module paths to projects using this lookup:

| Path prefix / module | Project |
|---|---|
| `clip-model`, `clip-commons`, `clip-offer`, `clip-entitlement`, `clip-product-instance`, `clip-product-client`, `clip-product-model`, `clip-consumption`, `clip-audit`, `clip-reservations`, `clip-clients`, `clip-app-service`, `clip-e2e-test` | `clip-app` |
| `clip-int-*`, `clip-audit-event-listener`, `clip-int-service`, `clip-int-e2e-test` | `clip-integrations` |
| `clip-control-plane-*`, `clip-scheduler`, `clip-sdr-event-listener`, `clip-transaction-audit`, `clip-data-migration-service` | `clip-control-plane` |
| `clip-*-query`, `clip-app-query-service` | `clip-app-query` |
| `ai` (any file path under `ai/`) | `ai` |

Present the auto-detected list to the user for confirmation before proceeding. Example:

> Based on the feature spec for SCLP-3394, the following projects are impacted:
> - `clip-app` (files to modify: RegistrationValidator, ProductInstanceService, ProductInstanceMapper)
> - `clip-integrations` (pass-through verification needed)
>
> Proceed with these? (or specify different projects)

### Priority 2: User-specified projects

If the user has already specified projects in their message (e.g. "prep clip-app and clip-integrations"), use their selection directly — skip auto-detection.

### Priority 3: Ask the user

If no feature spec exists and the user has not specified projects, ask them to choose:

- **All** — prep every Git repository listed above.
- **Specific projects** — provide a comma-separated list (e.g. `clip-app, clip-integrations`).

---

## Step 4: Pre-Flight Checks & Context Switching

Before making any Git changes, check the **current branch** and **working tree status** on each selected project:

```bash
cd {WORKSPACE_ROOT}/{project}
CURRENT_BRANCH=$(git branch --show-current)
git status --porcelain
```

Evaluate each project against the cases below.

### Case A: On a different feature branch (context switch)

The current branch matches `develop-{OTHER_ID}` where `OTHER_ID` is a **different** issue from `{ISSUE_ID}`. This means the user was previously working on another feature and is now switching to a new one.

1. **If the working tree is dirty** (uncommitted changes exist):
   - Extract the previous issue ID: `OTHER_ID` = the part after `develop-` in the branch name.
   - **Auto-commit** all changes with the proper JIRA commit message format:
     ```bash
     cd {WORKSPACE_ROOT}/{project}
     git add -A
     git commit -m "JIRA#{OTHER_ID}; WIP: save in-progress work before switching to {ISSUE_ID}"
     ```
   - Log: `"Auto-committed in-progress work on develop-{OTHER_ID} in {project}."`

2. **If the working tree is clean**, no action needed.

In both sub-cases, the project proceeds to Step 5 normally (checkout `develop`, pull, create new branch).

### Case B: On `develop`, `main`, or any non-feature branch with a dirty working tree

**Stop and report** which projects have dirty working trees. Ask the user how to proceed:
- **Stash** — run `git stash push -m "prepare auto-stash before develop-{ISSUE_ID}"` in those projects before continuing.
- **Skip** — skip those projects and prep only the clean ones.
- **Abort** — stop the entire workflow.

### Case C: Already on `develop-{ISSUE_ID}` (same feature branch as the new issue)

The branch for this issue already exists and is checked out. Ask the user:
- **Keep** — stay on the existing branch. Skip Git prep (Step 5) for this project — it is already set up.
- **Recreate** — delete the local branch, re-checkout `develop`, pull latest, and recreate `develop-{ISSUE_ID}`. **Warn** that any local-only commits on the old branch will be lost.

### Case D: Clean working tree (any branch, no uncommitted changes, and not Case C)

No action needed — proceed directly to Step 5.

---

Only proceed to Step 5 once all selected projects have been processed (auto-committed, stashed, skipped, or already clean).

Do NOT silently discard uncommitted work.

---

## Step 5: Execute Git Prep for Each Project

For each selected (and clean) project, run the following sequence. Execute projects sequentially (not in parallel) so that errors are caught and reported clearly.

```bash
cd {WORKSPACE_ROOT}/{project}

# 1. Switch to develop
git checkout develop

# 2. Pull latest develop
git pull origin develop

# 3. Create feature branch from develop
git checkout -b develop-{ISSUE_ID}

# 4. Confirm branch is up-to-date with origin/develop
git pull origin develop
```

### Error Handling

For each step, check the exit code. If any step fails:

| Error | Likely Cause | Action |
|---|---|---|
| `checkout develop` fails | Branch doesn't exist locally | Try `git fetch origin develop && git checkout -b develop --track origin/develop` |
| `pull origin develop` fails | Network issue or auth problem | Report to user, skip this project |
| `checkout -b develop-{ISSUE_ID}` fails | Branch already exists locally | Ask user: switch to existing branch (`git checkout develop-{ISSUE_ID}`) and pull, or delete and recreate (`git branch -D develop-{ISSUE_ID}` then retry)? |
| Second `pull origin develop` fails | Network issue | Report to user; branch was still created successfully from the first pull |

---

## Step 6: Attach Specs to JIRA

Upload both spec files as attachments to the JIRA issue.

### 6a. Obtain JIRA Credentials

Read the JIRA PAT from `local.config` at the workspace root:

```bash
JIRA_PAT=$(grep JIRA_PAT local.config | cut -d= -f2)
```

The JIRA base URL is: `https://jira.dell.com`

If the PAT is not found, ask the user to provide credentials.

### 6b. Upload Attachments

```bash
curl -X POST \
  -H "X-Atlassian-Token: no-check" \
  -H "Authorization: Bearer {TOKEN}" \
  -F "file=@ai/feature-specs/{ISSUE_ID}/feature-spec.md" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/attachments"

curl -X POST \
  -H "X-Atlassian-Token: no-check" \
  -H "Authorization: Bearer {TOKEN}" \
  -F "file=@ai/feature-specs/{ISSUE_ID}/implementation_plan.md" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/attachments"
```

Notes:
- The `X-Atlassian-Token: no-check` header is **required** by JIRA to bypass XSRF protection on attachment uploads.
- Verify each upload returns HTTP 200 with a JSON response containing the attachment `id` and `filename`.
- If the upload fails, report the error but continue to the next step. JIRA failures are non-blocking.

---

## Step 7: Post a Summary Comment

Add a single structured comment to the JIRA issue that summarises both documents, so reviewers can see the key details directly in the JIRA activity feed without opening attachments.

**Endpoint:** `POST /rest/api/2/issue/{ISSUE_ID}/comment`

Build the comment body in **JIRA wiki markup** (not Markdown — JIRA Server/Data Center comments use wiki notation). Use the content read in Step 2 to populate the sections below.

### Comment Template

```
{panel:title=AI-Generated Specs Attached|borderStyle=solid|borderColor=#0052CC|bgColor=#F4F5F7}

Two spec documents have been attached to this issue:
* [^feature-spec.md] — Feature specification
* [^implementation_plan.md] — Implementation plan & coding prompt

{panel}

h3. Feature Spec Summary

*Overview:* {INSERT: 2-3 sentence overview from section 4.2 of feature-spec.md}

*Functional Requirements:*
{INSERT: list each FR-ID and its one-line requirement from section 4.5, formatted as}
* *FR-01:* {requirement}
* *FR-02:* {requirement}
...

*Acceptance Criteria:*
{INSERT: the GIVEN/WHEN/THEN block from section 4.6}

----

h3. Implementation Plan Summary

*Files to Modify:*
{INSERT: numbered list of files from the "Files to Modify" section, with the one-line description of each change}

*Test Plan:*
{INSERT: list the unit test names (a-e) and one-line descriptions from "Tests to write"}

*Critical Constraints:*
{INSERT: bullet list of constraints from the "Critical Constraints" section}

----

h3. Open Questions

{INSERT: list only UNRESOLVED open questions from section 4.9 of feature-spec.md, formatted as:}
* *Q3:* {question text}
* *Q5:* {question text}
...

{color:#de350b}Please review and resolve open questions before implementation begins.{color}
```

Send the comment via:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"body": "{COMMENT_BODY}"}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/comment"
```

Notes:
- The `{COMMENT_BODY}` must be a JSON-escaped string. Use a script or heredoc to handle newlines and special characters properly.
- Verify the response returns HTTP 201 with the comment `id`.

---

## Step 8: Transition JIRA to "In Development"

### 8.1 Fetch Current Status

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}?fields=status"
```

Parse `fields.status.name` from the response. If the status is already `In Development`, skip the transition.

### 8.2 Get Available Transitions

```bash
curl -s -H "Authorization: Bearer {TOKEN}" \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Search the `transitions` array for an entry whose `name` matches `In Development` (case-insensitive). Extract its `id`.

If no matching transition is found, report the current status and available transitions to the user.

### 8.3 Execute the Transition

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -d '{"transition": {"id": "{TRANSITION_ID}"}}' \
  "https://jira.dell.com/rest/api/2/issue/{ISSUE_ID}/transitions"
```

Verify the response returns HTTP 204 (no content = success).

### Error Handling

| Problem | Solution |
|---|---|
| **401 Unauthorized** | Verify PAT/credentials. For JIRA Data Center, PATs are created under Profile → Personal Access Tokens. |
| **403 Forbidden** | User may lack "Transition Issues" permission on the project. Check with JIRA admin. |
| **No matching transition** | Report current status and available transitions; ask user which one to use. |
| **Network error** | Report to user. The branches are already created — JIRA update can be retried manually. |

Do NOT treat a JIRA update failure as a workflow failure. The branches are already created successfully; the status transition is a best-effort post-step.

---

## Step 9: Report Results

After processing all projects, report a summary:

### Git Prep Summary

```
| # | Project              | Status  | Branch                  | Details                    |
|---|----------------------|---------|-------------------------|----------------------------|
| 1 | clip-app             | OK      | develop-SCLP-3394       | Created from develop@abc123 |
| 2 | clip-integrations    | OK      | develop-SCLP-3394       | Created from develop@def456 (auto-committed WIP on develop-SCLP-3200) |
| 3 | clip-control-plane   | Skip    | —                       | Dirty working tree (user chose skip) |
| 4 | ai                   | OK      | develop-SCLP-3394       | Created from develop@ghi789 (auto-committed WIP on develop-SCLP-3200) |
```

For each successful project, include the short commit hash that `develop` was at when the branch was created (from `git rev-parse --short HEAD`). If a context switch occurred, note which previous branch had work auto-committed.

### JIRA Summary

- Attachments uploaded: `feature-spec.md`, `implementation_plan.md`
- Summary comment posted with: overview, {N} functional requirements, {N} test cases, {N} open questions.
- JIRA status transitioned to "In Development" (or already in that status / skipped / failed with reason).

### Reminders

- Total projects prepped vs skipped vs failed.
- The branch name used: `develop-{ISSUE_ID}`.
- "These branches are local only. Push with `git push -u origin develop-{ISSUE_ID}` when ready."
- Any open questions that need attention before implementation.

---

## Troubleshooting

| Problem | Solution |
|---|---|
| **401 Unauthorized** | Verify PAT/credentials. For JIRA Data Center, PATs are created under Profile → Personal Access Tokens. |
| **403 Forbidden** | User may lack "Add Attachments", "Add Comments", or "Transition Issues" permission on the project. Check with JIRA admin. |
| **413 Request Entity Too Large** | Attachment exceeds JIRA's max size (default 10MB). The markdown files should be well under this. |
| **XSRF check failed** | Ensure `X-Atlassian-Token: no-check` header is present on attachment uploads. |
| **Wiki markup not rendering** | If the JIRA instance uses "new editor" (Atlassian Document Format / ADF), the comment body format changes to ADF JSON. Check with user which editor their instance uses. |
| **Git checkout fails** | Unmerged files or dirty state. Run pre-flight checks first. Stash or skip dirty repos. |
| **Branch already exists** | Prior prep run for same issue. Ask user: switch to existing or recreate. |
| **Auto-commit on context switch fails** | Likely a merge conflict or hook rejection. Report the error to the user and offer to stash instead. |
