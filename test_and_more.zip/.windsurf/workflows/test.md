---
description: Pre-push quality gate — runs comprehensive tests (unit tests, E2E tests, lint) across all impacted projects before code is pushed to remote.
---

# Workflow: test

> Pre-push quality gate: runs comprehensive tests (unit tests, E2E tests, lint) across all impacted projects before code is pushed to remote.

---

## Purpose

This workflow provides a **final verification step** between implementation (`/execute`) and push (`/git_push`). While the `/execute` workflow runs module-level tests during TDD, this workflow runs the **full test suite** across every impacted project to catch cross-module regressions and ensure the codebase is clean before creating a Merge Request.

It is **technology-agnostic** — it reads test commands from the **Test Commands Reference** table in `CLAUDE.md` at the workspace root. To add or change test commands for any project, update that table; this workflow will pick up the changes automatically.

---

## Prerequisites

- Feature branch `develop-{ISSUE_ID}` is checked out in at least one project.
- Code has been committed (the `/execute` workflow should have run first).
- `CLAUDE.md` exists at the workspace root and contains a `### Test Commands Reference` section with the test command table.

---

## Step 1: Determine JIRA Issue ID

If the user has not already provided a JIRA issue ID (e.g. `SCLP-3394`), detect it from the current branch:

```bash
BRANCH=$(git branch --show-current)
ISSUE_ID=$(echo "$BRANCH" | grep -oP '[A-Z]+-\d+')
```

If no issue ID can be determined, ask the user.

---

## Step 2: Identify Impacted Projects

Scan every project directory under the workspace root. For each, check the current branch:

```bash
cd {WORKSPACE_ROOT}/{project}
git branch --show-current
```

A project is **impacted** if its current branch is `develop-{ISSUE_ID}`.

If no projects are on the feature branch, check if the user has specified projects explicitly. If not, stop and report: "No projects found on branch `develop-{ISSUE_ID}`. Run `/prepare` first or specify projects manually."

Present the list of impacted projects to the user for confirmation before running tests.

---

## Step 3: Load Test Configuration

Read the **Test Commands Reference** table from `CLAUDE.md` at the workspace root. This table is the single source of truth for all test commands.

Parse the table to build a lookup: for each impacted project, extract its test entries grouped by type (`unit`, `e2e`, `lint`).

If an impacted project has **no entry** in the Test Commands Reference, log a warning and skip it:
```
WARNING: No test commands found for project '{project}' in CLAUDE.md Test Commands Reference. Skipping.
```

---

## Step 4: Check for Uncommitted Changes

Before running tests, verify each impacted project has a clean working tree:

```bash
cd {WORKSPACE_ROOT}/{project}
git status --porcelain
```

If any project has uncommitted changes, **warn the user**:
```
WARNING: {project} has uncommitted changes. Test results may not reflect the final committed state.
```

Ask the user whether to:
- **Continue** — run tests anyway (changes will be included in the build).
- **Commit first** — stage and commit changes with `JIRA#{ISSUE_ID}; WIP: pre-test commit`, then run tests.
- **Abort** — stop and let the user handle the uncommitted changes manually.

---

## Step 5: Run Unit Tests

For each impacted project, run the `unit` type command(s) from the Test Commands Reference. Execute projects **sequentially** (not in parallel) to keep output clean and isolate failures.

For each project:

```bash
cd {WORKSPACE_ROOT}/{working_directory}
{unit_test_command}
```

**Capture and evaluate the result:**

- **Exit code 0** — PASS. Log the result and continue.
- **Non-zero exit code** — FAIL. Capture the output (last 100 lines of failure output is sufficient for diagnosis).

**On unit test failure:**

1. Read the failure output carefully.
2. Identify the failing test(s) and the root cause.
3. If the failure is in a **newly written test** (from the current feature), the implementation likely has a bug. Report the specific test name, error, and a root cause hypothesis.
4. If the failure is in an **existing test** (regression), report it as a regression with the test name and error.
5. **Do NOT automatically fix code** — report the failure and let the user decide. If running as part of the `/sdlc` orchestrator, the agent should attempt a fix (up to 3 retries) before escalating.

Continue to the next project regardless of failure (run all projects, then report aggregate results).

---

## Step 6: Run Lint / Static Analysis (if configured)

For each impacted project that has a `lint` type entry in the Test Commands Reference:

```bash
cd {WORKSPACE_ROOT}/{working_directory}
{lint_command}
```

- **Exit code 0** — PASS.
- **Non-zero exit code** — FAIL. Capture the violations/errors.

Lint failures are **warnings**, not blockers. Report them but do not stop the workflow.

---

## Step 7: Run E2E Tests (conditional)

E2E tests are **only run** when one of these conditions is true:
1. The user explicitly requests E2E tests (e.g., `/test SCLP-1234 --e2e`).
2. The implementation plan specifies E2E tests (check `ai/feature-specs/{ISSUE_ID}/implementation_plan.md` for an "E2E" or "End-to-End" section).
3. The `/sdlc` orchestrator passes an E2E flag.

If none of these conditions are met, **skip E2E tests** and note it in the report.

### 7a. Pre-requisites Check

E2E tests typically require a running service instance. Before executing E2E commands:

1. Check if the service is already running (attempt a health check or port check).
2. If not running, **inform the user** that E2E tests require a running instance and provide the start command from the "Service JAR Locations" / "Running Locally" sections of `CLAUDE.md`.
3. If the user confirms the service is running (or the agent can detect it), proceed.
4. If the service cannot be started, **skip E2E tests** and note the reason in the report.

### 7b. Execute E2E Tests

For each impacted project with an `e2e` type entry:

```bash
cd {WORKSPACE_ROOT}/{working_directory}
{e2e_test_command}
```

Evaluate results the same way as unit tests (Step 5).

---

## Step 8: Report Results

Produce a structured summary report.

### Test Results Summary

```
| # | Project            | Unit Tests | Lint   | E2E Tests | Status  |
|---|--------------------|------------|--------|-----------|---------|
| 1 | clip-app           | PASS       | N/A    | SKIP      | OK      |
| 2 | clip-integrations  | PASS       | N/A    | PASS      | OK      |
| 3 | clip-control-plane | FAIL       | N/A    | SKIP      | FAILED  |
| 4 | ai                 | N/A        | N/A    | N/A       | SKIP    |

Overall: 2 PASSED / 1 FAILED / 1 SKIPPED
```

### Failure Details (if any)

For each failed test, include:
- Project name
- Test type (unit / e2e / lint)
- Failing test name(s)
- Error message (concise — first line of assertion failure or exception)
- Root cause hypothesis (1 sentence)

### Verdict

- **ALL PASS** — "All tests passed. Safe to push with `/git_push {ISSUE_ID}`."
- **FAILURES EXIST** — "Test failures detected. Fix the issues above before pushing. Re-run with `/test {ISSUE_ID}` after fixing."
- **ONLY LINT WARNINGS** — "All tests passed. Lint warnings found (non-blocking). Safe to push."

---

## Running Standalone

This workflow can be invoked independently at any time, not just as part of the SDLC flow:

```
/test SCLP-3394
/test SCLP-3394 --e2e
/test                     (auto-detects ISSUE_ID from current branch)
```

When running standalone, the workflow follows all steps above. When running as part of the `/sdlc` orchestrator, failures trigger the agent to attempt fixes (up to 3 retries) before escalating to the user.

---

## Important Rules

1. **Read test commands from CLAUDE.md** — never hardcode project-specific commands in this workflow. The `### Test Commands Reference` table in `CLAUDE.md` is the single source of truth.
2. **Run all projects even if one fails.** Collect aggregate results before reporting. Do not stop at the first failure.
3. **Unit tests are mandatory, E2E tests are conditional.** Unit tests always run for impacted projects. E2E tests only run when explicitly requested or when the implementation plan specifies them.
4. **Do not auto-fix failures when running standalone.** Report failures and let the user decide. Auto-fix is only allowed when running inside the `/sdlc` orchestrator.
5. **Lint failures are warnings, not blockers.** Report them but do not fail the overall verdict.
6. **Process projects sequentially.** Parallel execution makes output hard to diagnose.
7. **Always report results**, even if all tests pass.
8. **Capture sufficient failure context.** Include the test name, error message, and a 1-line hypothesis. Do not dump the entire build log.
9. **Skip projects with no test configuration gracefully.** Log a warning and continue.
10. **E2E tests require running services.** Never attempt to start a service JAR automatically without user confirmation.

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| "No projects found on branch" | Feature branches not created yet | Run `/prepare {ISSUE_ID}` first |
| "No test commands found for project" | Project missing from CLAUDE.md table | Add a row to the `### Test Commands Reference` table in `CLAUDE.md` |
| Unit test fails with `OutOfMemoryError` | JVM heap too small for embedded MongoDB | Add `-Xmx4g` to `MAVEN_OPTS`: `export MAVEN_OPTS="-Xmx4g"` |
| E2E test fails with connection refused | Service not running | Start the service JAR (see "Service JAR Locations" in `CLAUDE.md`) |
| Maven build fails before tests run | Compilation error | Fix the code first. Run `mvn compile -pl <module> -am` to isolate |
| `./mvnw` permission denied | Maven wrapper not executable | Run `chmod +x ./mvnw` |
| `npm run test` fails with module not found | Dependencies not installed | Run `npm install` first |
| Lint command not found | Linter not installed in project | Install it or remove the `lint` row from the Test Commands Reference |
