#!/usr/bin/env python3
"""
Cascade pre_run_command hook: Block destructive file/folder deletion commands.

Reads JSON from stdin, inspects the command_line for delete/remove patterns,
and exits with code 2 to block the action if a match is found.
"""

import sys
import json
import re

DESTRUCTIVE_PATTERNS = [
    # Unix / Git Bash
    r"\brm\b",
    r"\brmdir\b",
    r"\bunlink\b",
    # PowerShell
    r"\bRemove-Item\b",
    r"\bri\b",
    r"\brd\b",
    r"\bdel\b",
    r"\berase\b",
    # Windows CMD
    r"\brmdir\b",
    r"\bdel\b",
    # Git destructive
    r"\bgit\s+clean\b",
]

SAFE_EXCEPTIONS = [
    r"\bgit\s+rm\s+--cached\b",
    r"\bnpm\s+(uninstall|remove)\b",
    r"\bpip\s+uninstall\b",
    r"\bmvn\s+clean\b",
    r"Remove-Item.*jira-comment\.json",
]


def is_destructive(command: str) -> str | None:
    for pattern in SAFE_EXCEPTIONS:
        if re.search(pattern, command, re.IGNORECASE):
            return None

    for pattern in DESTRUCTIVE_PATTERNS:
        match = re.search(pattern, command, re.IGNORECASE)
        if match:
            return match.group(0)

    return None


def main():
    input_data = sys.stdin.read()

    try:
        data = json.loads(input_data)
    except json.JSONDecodeError as e:
        print(f"Hook error: failed to parse JSON input: {e}", file=sys.stderr)
        sys.exit(1)

    if data.get("agent_action_name") != "pre_run_command":
        sys.exit(0)

    tool_info = data.get("tool_info", {})
    command = tool_info.get("command_line", "")
    cwd = tool_info.get("cwd", "")

    matched = is_destructive(command)
    if matched:
        print(
            f"BLOCKED: Command contains destructive operation '{matched}'. "
            f"Cascade is not allowed to delete files or folders.\n"
            f"  Command: {command}\n"
            f"  CWD: {cwd}\n"
            f"If this is intentional, the user must run it manually.",
            file=sys.stderr,
        )
        sys.exit(2)

    sys.exit(0)


if __name__ == "__main__":
    main()
