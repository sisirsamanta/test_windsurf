# Feature Spec: DAE-286

| Field      | Value                                                          |
|------------|----------------------------------------------------------------|
| Issue ID   | DAE-286                                                        |
| Issue Type | Story                                                          |
| Priority   | Major                                                          |
| Labels     | —                                                              |
| Components | subscription-domain-agent                                      |
| Generated  | 2026-04-03                                                     |

---

## Overview

DAE-286 adds a **"Get Help"** entry point to the Subscription Sub Agent. When a customer opens the Actions CTA on a specific subscription in the Manage Subscriptions page and clicks **Get Help**, the VA is invoked with the subscription name and ID pre-loaded. The agent presents three contextual support choices — Turn On/Off Auto Renew, Update Payment Method, Update Billing Notification Email — and responds with subscription-type-aware instructions for completing the selected action. This feature applies to both Dell.com and Premier channels and is initially scoped to US customers only.

---

## Background & Context

### JIRA Description

> Given customer is on Manage Subscriptions space  
> When they open the Actions CTA and click Get Help  
> Invoke the VA with the question on VA → Get help on the Subscription name and Subscription ID on both Dell.com and Premier.  
> then display the choices as per the design here [DCX-3878 Get Help care VA - Dev Handoff - V4 - Progress]  
>  
> Please see the Figma design depending the Prompt user selects  
> - Turn on/off auto renewal  
> - Update payment option  
> - Update billing formation  
>  
> Depending the Subscription type and its auto-renewal status and payemnt type (recurring vs one-time) the response and contact to care channel changes, we need to follow the steps outlined here  
>  

>  
> **For now: US only**

### Routing Matrix (extracted from JIRA attachments)

The routing logic is subscription-type-aware. 3 key attributes govern the response internally by calling the fetch_subscription_details api:
1. **Is the subscription renewable?**  when contractDetails.autoRenewalFlag is  "OPT_IN" then the subscription is renewable means autoRenewalFlag = YES, else if "OPT OUT" not renewable but can be opted in by user means autoRenewalFlag = NO. If null/blank then not the renewal option is not available for this subscription, autoRenewalFlag = NULL.
2. **Is it "Dell Services" or "Software" Subscrption** (if serviceType is  "/service/warranty or /service/warranty_consumer" then SubscriptionType = "Services"; else  SubscriptionType = "Software") 
3. **Is it a recurring or one-time payment subscription?** if currentVersions.purchasedProducts.productCadence is  "MONTHLY" or "ANNUAL" or  QUARTERLY" then "RecurringPayment" = YES else "RecurringPayment" = NO

#### Turn On/Off Auto Renew 
| autoRenewalFlag | SubscriptionType | VA Response |
|---|---|---|
| null/blank | — | "This subscription cannot be Turn On/Off for renew." |
| NO | Software | "Under Subscription Details Page find "Renewal Details" section, you can turn on your subscription. Kindly read the notes carefully."|
| YES | Software| "Under Subscription Details Page find "Renewal Details" section, you can turn off your subscription. Kindly read the notes carefully." |
| No | Services | "Under "Services Account"  page find  "Assets" tab and  check for "Auto Renew" Column, you can turn On your Services subscription." |
| YES | Services | "Under "Services Account"  page find  "Assets" tab and  check for "Auto Renew" Column, you can turn off your Services subscription. |

#### Update Payment Method 
| autoRenewalFlag|RecurringPayment| SubscriptionType | VA Response |
|---|---|---|---|
| NO/blank/null | NO | "Payment Method can not be updated for selected subscription as this subscription is paid upfront (when billing cadence is Upfront) and  can not renewed (when opetedIn is No or null)." |
| YES |YES |Software | "Under "Subscription Details" Page find "Payment"" Section, click Change Payment   CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." |
| YES |NO |Software | "Under "Subscription Details" Page find "Payment"" Section, click Change Payment   CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." |
| YES |YES|Services | "Under "Services Account"  page find  "Subscription Account Summary" tab , find  "Payment"" Section, click Change Payment   CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." |
| YES |NO|Services | "Under "Services Account"  page find  "Subscription Account Summary" tab , find  "Payment"" Section, click Change Payment   CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." |

#### Update Billing Notification Email - already handled by get_allowed_action api
| autoRenewalFlag|RecurringPayment| SubscriptionType | VA Response |
|---|---|---|---|
| NO/blank/null |NO| — | "Billing Notification Email can not be updated for selected subscription as this subscription is paid upfront / can not renewed." |
| YES |NO| Software | "Under "Subscription Details" Page   find  " Billing & Communications" Section, click for Change Billing Email CTA to open fly out and follow the instructions to provide updated Billing email id. **Note:** Billing Communication email change for any service subscription will also update email for all service subscription under same Subscription Account." |
| YES |YES| Software | "Under Payment section, click change payment method CTA to open fly out and select desired payment options." |
| YES |NO| Services | "Under "Services Account"  page find  "Subscription Account Summary" tab , find  "Update Billing Notifications" Section, click for Update Billing Notification CTA to open fly out and follow the instructions to provide updated Billing email id. **Note:** Billing Communication email change for any service subscription will also update email for all service subscription under same Subscription Account."  |
| YES |YES| Services | "Under "Services Account"  page find  "Subscription Account Summary" tab , find  "Update Billing Notifications" Section, click for Update Billing Notification CTA to open fly out and follow the instructions to provide updated Billing email id. **Note:** Billing Communication email change for any service subscription will also update email for all service subscription under same Subscription Account." |

### When customer further looking for care support  

Display issue type for user selectio from below list 
when SubscripttionType = "software" dispay below options for user selection - 
    "My Software & Subscription" 
    "Renewal/Upgrade"

    When "My Software & Subscription" is selected  then set user_selected_issue_type = "Software"  and display below sub-options - 
          softwareLicensing - I am missing software from my Order
          downloadsoftware - Cannot find or Unable to Download my Software
  
        set user_selected_issue_sub_type = "SoftwareLicensing" or "downloadsoftware" based on selection
    When ""Renewal/Upgrade"is selected  then set user_selected_issue_type = "autoRenew" and  user_selected_issue_sub_type = null

When SubscripttionType = "Services" display below option for user selection - 
    "Renewal/Upgrade"
    When ""Renewal/Upgrade"is selected  then set user_selected_issue_type = "autoRenew" and  user_selected_issue_sub_type = null


Using above user_selected_issue_type and user_selected_issue_sub_type values, route to appropriate contact page by calling eSupport MFE/API and display the contact page.
The eSupport MFE/API will require additional input parameters like encrypted data which contains subscription related information.

<!-- - **if  SubscriptionType is "services" subscription then  ** display path — "My Software & Subscription" (with care number) + "Renewal/Upgrade" (route to manage service contact page with Routing Link: `https://www.dell.com/myaccount/en-us/manage-warranty`) -->

<!-- - **if  SubscriptionType is "software" subscription then display** "My Software & Subscription" (with care number) -->

### Project Spec References

- **Functional Spec § 2.1**: Existing supported intents — `get_help` is a new addition
- **Functional Spec § 2.2**: Entry points — same `POST /api/v1/subagent/handle` and `/api/v1/subagent/handle` used
- **Functional Spec § 2.3 – 2.6**: Existing flows — `get_help` is a new single-step flow with conditional messaging
- **Technical Spec § 3**: Core processing pipeline — `get_help` follows the same `preexecute → step → execute → postexecute` pattern
- **Technical Spec § 4**: State machine — new `Intent.get_help` and `Stage_GetHelp` enum needed in `workflows/models.py` with below list start, get_help_preset, selectActionType, executeActionType, customerCareHelp(cch).SelectIssueType, cch.selectIssueSubType, end
- **Technical Spec § 5**: NLU prompt — must add `get_help` intent recognition
- **Data Model Spec § 3**: `ConversationState` — `get_help` flows through same model; new stage values needed
- **API Spec § POST /api/v1/subagent/handle**: Invocation with `messageType = "preset"` and subscription name/ID in `userQuery`; response uses `MessageType.followups` with CTAs

---

## Scope

### In Scope

- New `get_help` intent in the NLU prompt template (`nlu/prompt.py`)
- New `Intent.get_help` enum value and `Stage_GetHelp` stage enum in `workflows/models.py` with stages: `start`, `get_help_preset`, `selectActionType`, `executeActionType`, `cch_select_issue_type`, `cch_select_issue_sub_type`, `end`
- State machine transitions for `get_help` in `workflows/engine.py` — multi-turn flow
- Initial VA response with 3 CTA choices: Turn On/Off Auto Renew, Update Payment Method, Update Billing Notification Email
- Per-choice response logic based on 3 routing attributes derived from `fetch_subscription_details()`:
  - `autoRenewalFlag` — from `contractDetails.autoRenewalFlag` (OPT_IN → YES, OPT_OUT → NO, null/blank → NULL)
  - `SubscriptionType` — "Services" if serviceType is `/service/warranty` or `/service/warranty_consumer`; otherwise "Software"
  - `RecurringPayment` — YES if `productCadence` in {MONTHLY, ANNUAL, QUARTERLY}; otherwise NO
- Extraction of `autoRenewalFlag` and `productCadence` fields in both `extract_subscription_details()` and `extract_graphql_subscription_details()`; `autoRenewalFlag` added to the GraphQL query
- Processing in `subscriptionAIAgent.py`: `preexecute_step`, `execute` (engine), `postexecute_step`, new helper functions
- Care support multi-turn flow after action response: display issue type options (Software: "My Software & Subscription" + "Renewal/Upgrade"; Services: "Renewal/Upgrade" only), then optional sub-type selection, then route to eSupport MFE/API
- Subscription name and ID pre-context handling when `messageType = "preset"` and query contains subscription context
- US-only scope
- Locale-aware translation of all response messages via `StaticTranslator`

### Out of Scope

- Actual in-VA execution of payment or billing updates — VA provides navigation instructions only
- Non-US customers (explicitly deferred per JIRA: "For now: US only")
- "Renew / Upgrade subscription" as a direct VA-transactional action .
- eSupport MFE/API implementation itself — VA only calls and displays the contact page result
- Changes to v2/GraphQL flow beyond parallel `is_maverick` support

---

## Functional Requirements

| ID    | Requirement | Source |
|-------|-------------|--------|
| FR-01 | The system shall recognise a `get_help` intent when the user query or preset message contains a "Get Help" signal for a specific subscription | JIRA description; Acceptance Criteria |
| FR-02 | Upon `get_help` intent, the VA shall respond with three CTA choices: "Turn On/Off Auto Renew", "Update Payment Method", "Update Billing Notification Email" | JIRA description; Figma image-2026-04-01-14-04-02-095.png |
| FR-03 | The opening message shall be: "Hi there, I can help you with support. Could you tell me what kind of support you need?" | Figma design image-2026-04-01-14-04-02-095.png |
| FR-04 | The `get_help` VA invocation shall include the subscription name and subscription ID or entitlement id derived from the preset `userQuery` or `pageContext` , map | JIRA: "Invoke the VA with the question on VA → Get help on the Subscription name and Subscription ID or entitlement id " |
| FR-05 | **Turn On/Off Auto Renew — autoRenewalFlag = null/blank:** VA shall respond with "This subscription cannot be Turn On/Off for renew." | Routing Matrix § Turn On/Off Auto Renew |
| FR-06 | **Turn On/Off Auto Renew — autoRenewalFlag = NO + SubscriptionType = Software:** VA shall respond with "Under Subscription Details Page find 'Renewal Details' section, you can turn on your subscription. Kindly read the notes carefully." | Routing Matrix § Turn On/Off Auto Renew |
| FR-07 | **Turn On/Off Auto Renew — autoRenewalFlag = YES + SubscriptionType = Software:** VA shall respond with "Under Subscription Details Page find 'Renewal Details' section, you can turn off your subscription. Kindly read the notes carefully." | Routing Matrix § Turn On/Off Auto Renew |
| FR-08 | **Turn On/Off Auto Renew — autoRenewalFlag = NO + SubscriptionType = Services:** VA shall respond with "Under 'Services Account' page find 'Assets' tab and check for 'Auto Renew' Column, you can turn On your Services subscription." | Routing Matrix § Turn On/Off Auto Renew |
| FR-09 | **Turn On/Off Auto Renew — autoRenewalFlag = YES + SubscriptionType = Services:** VA shall respond with "Under 'Services Account' page find 'Assets' tab and check for 'Auto Renew' Column, you can turn off your Services subscription." | Routing Matrix § Turn On/Off Auto Renew |
| FR-10 | **Update Payment Method — autoRenewalFlag = NO/blank/null:** VA shall respond with "Payment Method can not be updated for selected subscription as this subscription is paid upfront (when billing cadence is Upfront) and can not renewed (when optedIn is No or null)." | Routing Matrix § Update Payment Method |
| FR-11 | **Update Payment Method — autoRenewalFlag = YES + Software (any RecurringPayment):** VA shall respond with "Under 'Subscription Details' Page find 'Payment' Section, click Change Payment CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." | Routing Matrix § Update Payment Method |
| FR-12 | **Update Payment Method — autoRenewalFlag = YES + Services (any RecurringPayment):** VA shall respond with "Under 'Services Account' page find 'Subscription Account Summary' tab, find 'Payment' Section, click Change Payment CTA to open fly out and follow the instructions to provide updated payment method. **Note:** Payment method change for any service subscription will also update payment method for all service subscription under same Subscription Account." | Routing Matrix § Update Payment Method |
| FR-13 | **Update Billing Email — autoRenewalFlag = NO/blank/null:** VA shall respond with "Billing Notification Email can not be updated for selected subscription as this subscription is paid upfront / can not renewed." | Routing Matrix § Update Billing Notification Email |
| FR-14 | **Update Billing Email — autoRenewalFlag = YES + RecurringPayment = NO + Software:** VA shall respond with "Under 'Subscription Details' Page find 'Billing & Communications' Section, click for Change Billing Email CTA to open fly out and follow the instructions to provide updated Billing email id. **Note:** Billing Communication email change for any service subscription will also update email for all service subscription under same Subscription Account." | Routing Matrix § Update Billing Notification Email |
| FR-15 | **Update Billing Email — autoRenewalFlag = YES + RecurringPayment = YES + Software:** VA shall respond with "Under Payment section, click change payment method CTA to open fly out and select desired payment options." | Routing Matrix § Update Billing Notification Email |
| FR-16 | **Update Billing Email — autoRenewalFlag = YES + Services (any RecurringPayment):** VA shall respond with "Under 'Services Account' page find 'Subscription Account Summary' tab, find 'Update Billing Notifications' Section, click for Update Billing Notification CTA to open fly out and follow the instructions to provide updated Billing email id. **Note:** Billing Communication email change for any service subscription will also update email for all service subscription under same Subscription Account." | Routing Matrix § Update Billing Notification Email |
| FR-17 | The `autoRenewalFlag` shall be derived from `contractDetails.autoRenewalFlag` in the SLM API response: "OPT_IN" → YES; "OPT_OUT" → NO; null/blank → NULL. This field shall be added to the GraphQL query and extracted in `extract_subscription_details()` | feature-spec.md Routing Matrix |
| FR-18 | `SubscriptionType` shall be "Services" when `serviceType` is `/service/warranty` or `/service/warranty_consumer`; all other service types → "Software" | feature-spec.md Routing Matrix |
| FR-19 | `RecurringPayment` shall be YES when `productCadence` (from `currentVersions.purchasedProducts.productCadence`) is MONTHLY, ANNUAL, or QUARTERLY; otherwise NO. This field shall be extracted in `extract_subscription_details()` | feature-spec.md Routing Matrix |
| FR-20 | The `get_help` workflow shall be a multi-turn flow with stages: `start` → `get_help_preset` → `selectActionType` → `executeActionType` → `cch_select_issue_type` → `cch_select_issue_sub_type` → `end` | Technical Spec § 4; feature-spec.md Technical Spec References |
| FR-21 | All VA response messages shall be translated to the user's locale via `StaticTranslator.translate_text()` | technical-spec.md § 1; nfr-spec.md § 5 |
| FR-22 | The feature shall be supported on both Dell.com (`/api/v1`) and Premier (`/api/v1`) channels | JIRA: "on both Dell.com and Premier" |
| FR-23 | The feature is scoped to US customers only for this release | JIRA: "For now: US only" |
| FR-24 | The NLU prompt shall be updated to recognise `get_help` as a valid intent alongside existing intents | Technical Spec § 5; `nlu/prompt.py` |
| FR-25 | After displaying the instructional response (`executeActionType` stage), or any stage of the workflow the VA shall display care support options based on `SubscriptionType`: Software → "My Software & Subscription" and "Renewal/Upgrade"; Services → "Renewal/Upgrade" only | feature-spec.md § When customer further looking for care support or in any stage of the workflow customer wants to look for care support, ask for doubt confirmation when workflow being interrupted by custoemr support request |
| FR-26 | When "My Software & Subscription" is selected, the VA shall display two sub-options: "softwareLicensing — I am missing software from my Order" and "downloadsoftware — Cannot find or Unable to Download my Software". The selected value sets `user_selected_issue_sub_type` | feature-spec.md § When customer further looking for care support |
| FR-27 | When "Renewal/Upgrade" is selected, `user_selected_issue_type = "autoRenew"` and `user_selected_issue_sub_type = null` | feature-spec.md § When customer further looking for care support |
| FR-28 | Using `user_selected_issue_type` and `user_selected_issue_sub_type`, the VA shall route to the appropriate contact page by calling the eSupport MFE/API with encrypted subscription data and display the contact page result | feature-spec.md § When customer further looking for care support |

---

## Acceptance Criteria

> Copied verbatim from JIRA DAE-286 — customfield_10208

Given customer is on Manage Subscriptions space When they open the Actions CTA and click Get Help Invoke the VA with the question on VA ->Get help on the Subscription name and Subscription ID on both Dell.com and Premier. then display the choices as per the design here [DCX-3878 Get Help care VA - Dev Handoff - V4 - Progress|https://www.figma.com/proto/GBCnXHGo3nHrQuzEk26cCY/DCX-3878-Get-Help-care-VA?page-id=22%3A77&node-id=139-3200&p=f&viewport=6043%2C3550%2C0.45&t=P4Rjf5HizxYxgA41-1&scaling=scale-down-width&content-scaling=fixed&starting-point-node-id=139%3A3200] Please see the Figma design depending the Prompt user selects # Turn on/off auto renewal # Update payment option # Update billing formation Depending the Subscription type the response and contact to care channel changes, we need to follow the steps outlined here !image-2026-04-01-14-07-15-414.png! *!image-2026-04-01-14-06-31-155.png!!image-2026-04-01-14-07-06-695.png!* *For now : US only*

---

## Non-Functional Requirements

| Category | Requirement |
|---|---|
| Performance | `get_help` initial response (choices display) shall add no more than 200ms overhead vs existing intents — no SLM API call needed at choices stage |
| Performance | Per-choice response (after user selects) includes `fetch_subscription_details` API call; total response time shall remain within 3s p95 target |
| Security | Bearer token validation via `get_current_user` applies identically to `get_help` endpoint calls |
| Compatibility | New `get_help` intent and `Stage_GetHelp` stages must not break existing `ConversationState` deserialization from Redis for other intents |
| Observability | Intent `get_help` and stage transitions must be logged at INFO level following existing patterns in `subscriptionAIAgent.py` |
| i18n | All three choice labels and all response messages across the 15 routing paths (5 rows × 3 choices) must be routed through `StaticTranslator.translate_text()` |
| Scalability | No new stateful infrastructure — reuses existing Redis workflow store |

---

## Impacted Areas

| Area | File / Class / Endpoint | Nature of Change | Project Spec Reference |
|---|---|---|---|
| NLU Prompt | `virtual_assistant/app/nlu/prompt.py` — `PROMPT_TEMPLATE` | Add `get_help` to the intent list; update intent enumeration in JSON output spec | Technical Spec § 5 |
| Workflow Models | `virtual_assistant/app/workflows/models.py` — `Intent` enum, new `Stage_GetHelp` enum, `intent_stage_map` | New enum value `get_help`; new stage enum; register in `intent_stage_map` | Data Model Spec § 3 |
| Workflow Engine | `virtual_assistant/app/workflows/engine.py` — `is_transition_allowed()`, `step()`, `execute()` | Add `get_help` branch in all three functions | Technical Spec § 4 |
| Core Agent | `virtual_assistant/app/services/subscriptionAIAgent.py` — `preexecute_step()`, `postexecute_step()`, `prepare_response()` | Add `get_help` handling in each function; add `prepare_get_help_choices_response()` and `prepare_get_help_action_response()` | Technical Spec § 3 |
| Subscription Details | `virtual_assistant/app/services/subscription_details.py` — `extract_subscription_details()`, Add `autoRenewalFlag` (from `contractDetails.autoRenewalFlag`) and `productCadence` extraction; add `get_help` intent branch to extract function | Integration Spec § 1 |
| REST API (v1) | `virtual_assistant/app/api/v1/routes.py` — `POST /api/v1/subagent/handle` | No route changes; same endpoint handles `get_help` via existing dispatch | API Spec § POST /api/v1/subagent/handle |

| Unit Tests | `tests/` — new test file `test_get_help_intent.py` | New test coverage for `get_help` state machine, routing matrix, and response formatting | — |

---

## Open Questions & Assumptions

### Open Questions

1. **Routing matrix "Need Nikhil confirmation"**: The desired flow (right column of image-2026-04-01-14-07-06-695.png) is labelled "Option 1 Desired flow (Need Nikhil confirmation)". Is this the confirmed flow to implement, or should only the basic flow (left column) be implemented? Confirmation received from Sisir & Vinay and udoated JIRA.
2. **Renewable flag source**: The subscription data from `extract_subscription_details()` in `subscription_details.py` does not currently return an explicit `renewable` boolean. Should this be derived from `get_allowed_actions()` (non-empty result = renewable), or does the SLM API return an explicit flag that should be extracted? Confirmed and Updated Spec based on disussion between Sisir & Debi Prasad. We dont need to use `get_allowed_actions()` to determine renewable flag just use `extract_subscription_details()` to get the renewable flag.
3. **Subscription context in preset query**: When the user clicks "Get Help" from the Actions CTA, what exact format does the `userQuery` (or `transformedQuery`) carry? Does it follow a known pattern like `"get_help | subscription_name = X | subscription_id = Y|entitlement_id = Y | service_type = /service/..."` or is the subscription context passed separately? Confirmation - its passed in pipe seperated inside the query
4. **Premier routing**: The JIRA says "both Dell.com and Premier" but also "US only". For Premier users (`isPremier = true`), should the same instructional responses be shown, or are they directed to a different care channel URL? Confirmed - It is same for both Dell.com and Premier
5. **Warranty special case**: Image-2026-04-01-14-06-31-155.png shows a specific warranty routing (recurring renewable vs one-time paid). Is this only for "Turn On/Off Auto Renew" or does it apply to all three prompts? Should the warranty care number (8662933355) be included in the response?Confirmed and updated comprehensive souting logic. This opej item is closed.
6. **"Renew / Upgrade subscription"** option is visible in the routing matrix image but is not among the three confirmed choices in the JIRA description. Should it be included in the initial implementation?Confirmed - This is not part of the initial implementation. This is only available part of custoemr care issue type selection for software and services serviceType.

### Assumptions

1. The **desired flow** (routing matrix in feature-spec.md) is the confirmed implementation target.
2. `autoRenewalFlag` comes from `contractDetails.autoRenewalFlag` in the SLM REST API response. This field is not currently extracted and must be added.
3. `RecurringPayment` comes from `currentVersions.purchasedProducts.productCadence` in the SLM REST API. This field is not currently extracted and must be added.
4. **SubscriptionType** = "Services" for `/service/warranty` and `/service/warranty_consumer` only. All other service types = "Software".
5. The **subscription name and ID or Entitlement Id ** are passed as part of `userQuery` or can be inferred from `ConversationState.collected`.
6. The `get_help` workflow is a **multi-turn flow** with stages: `start` → `get_help_preset` → `selectActionType` → `executeActionType` → `cch_select_issue_type` → `cch_select_issue_sub_type` → `end`. The flow should allow get customer care help at any stage, however this interruption should be handled gracefully and the user should be able to continue from where they left off or asking for double confirmation
7. The eSupport MFE/API contract (endpoint, encrypted data format, response schema) is assumed to be available as a separate service. The VA agent will call it with `user_selected_issue_type`, `user_selected_issue_sub_type`, and encrypted subscription context.

---

## Definition of Done

- [ ] FR-01 through FR-28 implemented
- [ ] All acceptance criteria passing (manual and automated)
- [ ] Unit tests written for `get_help` intent state machine (`test_get_help_intent.py`)
- [ ] Unit tests written for all 15 routing matrix paths (5 rows × 3 choices)
- [ ] `autoRenewalFlag` and `productCadence` extraction tested for both REST API paths
- [ ] `SubscriptionType` classification tested (Services vs Software)
- [ ] Care support multi-turn flow tested (Software: 2 issue types + sub-types; Services: 1 issue type)
- [ ] eSupport MFE/API call integration tested with mock
- [ ] Locale translation verified for all new response strings
- [ ] `get_help` flow verified end-to-end on v1 (Dell.com) and v2 (Premier) channels
- [ ] No regression in existing `cancel_subscription`, `update_payment_method`, `view_subscription_details` flows
- [ ] Existing Redis state deserialization not broken by new stage enum values
- [ ] Open Question 3 (preset query format) confirmed with UI/frontend team before merge
- [ ] eSupport MFE/API contract (endpoint, encrypted data format) confirmed before implementation of FR-28
- [ ] Code reviewed and approved
- [ ] Feature spec reviewed against implementation for completeness
