# Implementation Plan: DAE-286
## Day2 AI experience — Subscription Sub Agent "Get Help" Action

---

## 1. Overview

Add `get_help` as a new multi-turn intent to the subscription domain agent. When invoked via the Actions CTA on a specific subscription, the VA presents 3 support choices. On selection, the agent fetches `autoRenewalFlag`, `productCadence`, and `serviceType` from the SLM API to determine the instructional response. After the instructional response, a care support flow is offered to route the user to the eSupport MFE/API.

**Full multi-turn flow:**
```
Turn 1 — messageType=preset
  NLU → intent=get_help, service_type, subscription_id/entitlementId
  stage: start → get_help_preset → selectActionType
  Response: Opening message + 3-CTA action menu

Turn 2 — messageType=followup
  userQuery = "get_help_action = TURN_AUTO_RENEW|UPDATE_PAYMENT|UPDATE_BILLING_EMAIL"
  stage: selectActionType → executeActionType
  Engine: fetch_subscription_details() → autoRenewalFlag + productCadence + serviceType
  Response: Instructional text (routing matrix) + care support CTAs

Turn 3 — user selects care support option
  stage: cch_select_issue_type
  Software: "My Software & Subscription" → Turn 4 for sub-type; "Renewal/Upgrade" → eSupport call + end
  Services: "Renewal/Upgrade" only → eSupport call + end

Turn 4 (Software "My Software & Subscription" path only)
  stage: cch_select_issue_sub_type
  userQuery = "issue_sub_type = SoftwareLicensing|downloadsoftware"
  → eSupport call + end
```

**Routing attributes** (derived from `fetch_subscription_details`):

| Attribute | Source field | Values |
|---|---|---|
| `autoRenewalFlag` | `contractDetails.autoRenewalFlag` | YES (OPT_IN), NO (OPT_OUT), NULL |
| `SubscriptionType` | `serviceType` | "Services" (/service/warranty or /service/warranty_consumer), "Software" (all others) |
| `RecurringPayment` | `currentVersions.purchasedProducts.productCadence` | YES (MONTHLY/ANNUAL/QUARTERLY), NO |

---

## 2. Test Strategy (TDD)

Write tests BEFORE implementation. All tests live in:
`subscription-domain-agent/virtual_assistant/tests/test_get_help_intent.py`

### Test Cases

```python
# --- State machine ---
# TC-01: stage start → get_help_preset (on get_help intent)
# TC-02: stage get_help_preset → selectActionType
# TC-03: stage selectActionType → executeActionType (action chosen)
# TC-04: stage executeActionType → cch_select_issue_type
# TC-05: stage cch_select_issue_type → cch_select_issue_sub_type (Software + My Software & Subscription)
# TC-06: stage cch_select_issue_type → end (Renewal/Upgrade)
# TC-07: stage cch_select_issue_sub_type → end

# --- 3-attribute derivation ---
# TC-08: autoRenewalFlag = OPT_IN → YES; OPT_OUT → NO; null → NULL
# TC-09: SubscriptionType = Services for /service/warranty; Software for /service/o365/consumer
# TC-10: RecurringPayment = YES for MONTHLY/ANNUAL/QUARTERLY; NO for others

# --- TURN_AUTO_RENEW routing (5 paths) ---
# TC-11: autoRenewalFlag=NULL → "cannot be Turn On/Off"
# TC-12: autoRenewalFlag=NO + Software → Renewal Details turn-on message
# TC-13: autoRenewalFlag=YES + Software → Renewal Details turn-off message
# TC-14: autoRenewalFlag=NO + Services → Assets tab turn-on message
# TC-15: autoRenewalFlag=YES + Services → Assets tab turn-off message

# --- UPDATE_PAYMENT routing (3 effective paths) ---
# TC-16: autoRenewalFlag=NULL → paid upfront message
# TC-17: autoRenewalFlag=YES + Software → Subscription Details Payment message
# TC-18: autoRenewalFlag=YES + Services → Services Account Payment message

# --- UPDATE_BILLING_EMAIL routing (4 effective paths) ---
# TC-19: autoRenewalFlag=NULL → billing email upfront message
# TC-20: autoRenewalFlag=YES + RecurringPayment=NO + Software → Billing & Communications message
# TC-21: autoRenewalFlag=YES + RecurringPayment=YES + Software → Payment section message
# TC-22: autoRenewalFlag=YES + Services → Update Billing Notifications message

# --- Field extraction ---
# TC-23: autoRenewalFlag extracted from REST subscription dict
# TC-24: productCadence extracted from REST subscription dict
# TC-25: autoRenewalFlag extracted from GraphQL subscription dict

# --- Care support flow ---
# TC-26: Software SubscriptionType → 2 care CTAs shown
# TC-27: Services SubscriptionType → 1 care CTA shown
# TC-28: issue_sub_type extraction rule in NLU
```

---

## 3. File Changes

### File 1: `virtual_assistant/app/nlu/prompt.py`

**Change:** Add `get_help` intent, `get_help_action`, and `issue_sub_type` extraction to `PROMPT_TEMPLATE_WORKING`.

```python
# In step 1, add intent definition:
    **get_help**
       - If the user wants help or support options for a specific subscription (e.g. "Get Help" button clicked)
       - If the user is asking what actions they can take on their subscription

# In step 5, add to JSON output:
   - get_help_action: Extracted get_help action or null
   - issue_sub_type: Extracted issue sub-type or null

# Add extraction rules (after rule 13):
14. Extract get_help_action from user query if and only if get_help_action is mentioned:
   - get_help_action: String following 'get_help_action =' in user query
     Values: TURN_AUTO_RENEW, UPDATE_PAYMENT, UPDATE_BILLING_EMAIL
15. Extract issue_sub_type from user query if and only if issue_sub_type is mentioned:
   - issue_sub_type: String following 'issue_sub_type =' in user query
     Values: SoftwareLicensing, downloadsoftware, autoRenew
```

**Lines affected:** `PROMPT_TEMPLATE_WORKING` — lines 31-109 of `nlu/prompt.py`

---

### File 2: `virtual_assistant/app/workflows/models.py`

**Change:** Add `Intent.get_help`, `Stage_GetHelp`, update `intent_stage_map` and `Result`.

```python
# Add to Intent enum:
    get_help = "get_help"

# New Stage enum (after Stage_Other):
class Stage_GetHelp(str, Enum):
    start = "start"
    get_help_preset = "get_help_preset"
    selectActionType = "selectActionType"
    executeActionType = "executeActionType"
    cch_select_issue_type = "cch_select_issue_type"
    cch_select_issue_sub_type = "cch_select_issue_sub_type"
    end = "end"
    done = "end"   # alias for framework compatibility

# Update Stage Union:
Stage = Union[Stage_Cancel_Subscription, Stage_Manage_Payment, Stage_view_Subscription, Stage_GetHelp]

# Update intent_stage_map:
    "get_help": Stage_GetHelp,

# Update Result model — add field:
    get_help_response: Optional[str] = None
```

---

### File 3: `virtual_assistant/app/workflows/engine.py`

**Change A — `is_transition_allowed()`:**
Add `get_help` — always returns `True` (informational flow).

```python
    if intent == Intent.get_help:
        return True
```

---

**Change B — `step()`:**
Add all `get_help` stage transitions.

```python
    # At start stage:
    if intent == Intent.get_help:
        state.intent = Intent.get_help
        state.stage = _stage.get_help_preset
        return state

    # At get_help_preset stage — advance to selectActionType:
    if state.stage == _stage.get_help_preset:
        if intent == Intent.get_help:
            state.stage = _stage.selectActionType
            return state

    # At selectActionType — user has chosen an action:
    if state.stage == _stage.selectActionType:
        if intent == Intent.get_help:
            state.stage = _stage.executeActionType
            return state

    # At executeActionType — response shown; advance to care support:
    if state.stage == _stage.executeActionType:
        if intent == Intent.get_help:
            state.stage = _stage.cch_select_issue_type
            return state

    # At cch_select_issue_type — user selects issue type:
    if state.stage == _stage.cch_select_issue_type:
        if intent == Intent.get_help:
            issue_sub_type = nlu.get("issue_sub_type", "")
            # "My Software & Subscription" → show sub-types; "Renewal/Upgrade" → end
            if issue_sub_type and issue_sub_type.lower() == "software":
                state.stage = _stage.cch_select_issue_sub_type
            else:
                state.stage = _stage.end
            return state

    # At cch_select_issue_sub_type — user selects sub-type, then end:
    if state.stage == _stage.cch_select_issue_sub_type:
        if intent == Intent.get_help:
            state.stage = _stage.end
            return state
```

---

**Change C — `execute()`:**

```python
    # At get_help_preset — store subscription context, no API call:
    if state.stage == _stage.get_help_preset:
        if intent == Intent.get_help:
            state.service_type = nlu.get("service_type") or state.service_type
            state.message_type = MessageType.followups
            state.collected["service_type"] = state.service_type
            state.collected["subscription_id"] = nlu.get("subscription_id")
            state.collected["entitlement_id"] = nlu.get("entitlement_id")
            state.collected["service_tag"] = nlu.get("service_tag")
            state.collected["sub_agreement_id"] = nlu.get("sub_agreement_id")
            return Result()

    # At executeActionType — fetch subscription, derive routing attributes:
    if state.stage == _stage.executeActionType:
        if intent == Intent.get_help:
            get_help_action = nlu.get("get_help_action", "").upper()
            service_type = state.collected.get("service_type") or nlu.get("service_type")
            subscription_id = state.collected.get("subscription_id") or nlu.get("subscription_id")
            entitlement_id = state.collected.get("entitlement_id") or nlu.get("entitlement_id")
            service_tag = state.collected.get("service_tag") or nlu.get("service_tag")
            sub_agreement_id = state.collected.get("sub_agreement_id") or nlu.get("sub_agreement_id")
            dcns = nlu.get("dcns")
            party_ids = nlu.get("party_ids")

            subscriptions = []
            if not nlu.get("is_maverick", False):
                st_list = [service_tag] if service_tag and isinstance(service_tag, str) else service_tag
                subscriptions = await fetch_subscription_details(
                    dcns, subscription_id, service_type, entitlement_id,
                    st_list, nlu.get("order_no"), sub_agreement_id, "get_help"
                )
            else:
                st = service_tag[0] if service_tag and len(service_tag) > 0 else None
                subscriptions = await fetch_subscription_details_graphql(
                    dcns, party_ids, subscription_id, entitlement_id,
                    st, service_type, "get_help"
                )

            auto_renewal_flag = None
            recurring_payment = False
            resolved_service_type = service_type
            if subscriptions and len(subscriptions) > 0:
                sub = subscriptions[0]
                auto_renewal_flag = sub.get("autoRenewalFlag")   # YES / NO / None
                product_cadence = sub.get("productCadence", "")
                recurring_payment = product_cadence.upper() in ("MONTHLY", "ANNUAL", "QUARTERLY")
                resolved_service_type = sub.get("serviceType") or service_type

            is_services = resolved_service_type and resolved_service_type.lower() in (
                "/service/warranty", "/service/warranty_consumer"
            )

            state.collected["get_help_action"] = get_help_action
            state.collected["auto_renewal_flag"] = auto_renewal_flag
            state.collected["recurring_payment"] = recurring_payment
            state.collected["is_services"] = is_services
            state.collected["resolved_service_type"] = resolved_service_type
            state.message_type = MessageType.followups
            return Result(get_help_response="executeActionType")

    # At cch_select_issue_type / cch_select_issue_sub_type / end:
    if state.stage in (_stage.cch_select_issue_type, _stage.cch_select_issue_sub_type, _stage.end):
        if intent == Intent.get_help:
            issue_sub_type = nlu.get("issue_sub_type")
            if issue_sub_type:
                state.collected["user_selected_issue_sub_type"] = issue_sub_type
            state.collected["user_selected_issue_type"] = (
                nlu.get("issue_sub_type_parent", "autoRenew")
                if state.stage == _stage.cch_select_issue_sub_type
                else state.collected.get("user_selected_issue_type", "autoRenew")
            )
            state.message_type = MessageType.followup
            return Result(get_help_response="care_support")
```

**New import in `engine.py`:** None needed (service type strings used directly, not `DELL_SERVICE_TYPES`)

---

### File 4: `virtual_assistant/app/services/subscription_details.py`

**Change A — GraphQL query (`contractDetails` block, ~line 471):**
```graphql
contractDetails {
    contractStartDate
    contractEndDate
    autoRenewalFlag       # ADD
}
```
Also add `productCadence` to `purchasedProducts` block (~line 448):
```graphql
purchasedProducts {
    ...
    productCadence        # ADD
}
```

---

**Change B — `extract_subscription_details()` — add `get_help` branch after `view_subscription_details` (~line 287):**

```python
                    elif intent == "get_help":
                        auto_renewal_flag_raw = contract_details.get("autoRenewalFlag")
                        if auto_renewal_flag_raw and auto_renewal_flag_raw.upper() == "OPT_IN":
                            auto_renewal_flag = "YES"
                        elif auto_renewal_flag_raw and "OPT" in auto_renewal_flag_raw.upper():
                            auto_renewal_flag = "NO"
                        else:
                            auto_renewal_flag = None
                        product_cadence = (
                            purchased_products[0].get("productCadence")
                            if purchased_products and len(purchased_products) > 0
                            else None
                        )
                        subscriptions.append({
                            "subscriptionId": entitlement_id if service_type in SA_KEY_SUB_SERVTYPE_MAP.get("subscriptionId") else None,
                            "serviceType": service_type,
                            "subscriptionReference": subscription_reference,
                            "contractStartDate": contract_start_date,
                            "contractEndDate": contract_end_date,
                            "title": sku_descr,
                            "entitlementId": entitlement_id,
                            "serviceTagId": service_tag_id if service_type in SA_KEY_SUB_SERVTYPE_MAP.get("serviceTag") else None,
                            "subAgreementId": subAgreementId if service_type in SA_KEY_SUB_SERVTYPE_MAP.get("subAgreementId") else None,
                            "dellCustomerNumber": dell_customer_number,
                            "orderNumber": order_no,
                            "autoRenewalFlag": auto_renewal_flag,
                            "productCadence": product_cadence,
                            "country": "US" if buid == "11" else "Non-US"
                        })
```

Note: `contract_details` is already extracted at line ~199; `purchased_products` already at line ~236.

---

**Change C — `extract_graphql_subscription_details()` (~line 775):**
Add `get_help` branch in the per-subscription loop (where `view_subscription_details` branch exists):

```python
                    elif intent == "get_help":
                        contract_details_gql = sub.get("contractDetails") or {}
                        auto_renewal_flag_raw = contract_details_gql.get("autoRenewalFlag")
                        if auto_renewal_flag_raw and auto_renewal_flag_raw.upper() == "OPT_IN":
                            auto_renewal_flag = "YES"
                        elif auto_renewal_flag_raw and "OPT" in auto_renewal_flag_raw.upper():
                            auto_renewal_flag = "NO"
                        else:
                            auto_renewal_flag = None
                        purchased_products_gql = sub.get("purchasedProducts") or []
                        product_cadence = (
                            purchased_products_gql[0].get("productCadence")
                            if purchased_products_gql else None
                        )
                        subscriptions.append({
                            "subscriptionId": subscription_id,
                            "serviceType": service_type,
                            "entitlementId": entitlement_id,
                            "serviceTagId": service_tag,
                            "title": description,
                            "contractStartDate": contract_start_date,
                            "contractEndDate": contract_end_date,
                            "dellCustomerNumber": dcn,
                            "autoRenewalFlag": auto_renewal_flag,
                            "productCadence": product_cadence,
                            "country": "US" if buid == "11" else "Non-US"
                        })
```

---

**Change D — `fetch_subscription_details()` (~line 974):**
Add `get_help` sort branch:
```python
                if intent == "get_help":
                    subscriptions = await sort_subscriptions_by_endtime(subscriptions)
```

---

### File 5: `virtual_assistant/app/services/subscriptionAIAgent.py`

**Change A — Helper: `_build_get_help_instructional_msg()`** (pure function, no side effects, easy to unit test):

```python
def _build_get_help_instructional_msg(
    get_help_action: str,
    auto_renewal_flag: str,      # "YES" / "NO" / None
    recurring_payment: bool,
    is_services: bool
) -> str:
    flag = (auto_renewal_flag or "").upper()
    is_null = flag not in ("YES", "NO")

    if get_help_action == "TURN_AUTO_RENEW":
        if is_null:
            return "This subscription cannot be Turn On/Off for renew."
        if not is_services:  # Software
            if flag == "NO":
                return ("Under Subscription Details Page find \"Renewal Details\" section, "
                        "you can turn on your subscription. Kindly read the notes carefully.")
            return ("Under Subscription Details Page find \"Renewal Details\" section, "
                    "you can turn off your subscription. Kindly read the notes carefully.")
        else:  # Services
            if flag == "NO":
                return ("Under \"Services Account\" page find \"Assets\" tab and check for "
                        "\"Auto Renew\" Column, you can turn On your Services subscription.")
            return ("Under \"Services Account\" page find \"Assets\" tab and check for "
                    "\"Auto Renew\" Column, you can turn off your Services subscription.")

    elif get_help_action == "UPDATE_PAYMENT":
        if is_null or flag == "NO":
            return ("Payment Method can not be updated for selected subscription as this subscription "
                    "is paid upfront (when billing cadence is Upfront) and can not renewed "
                    "(when optedIn is No or null).")
        if not is_services:
            return ("Under \"Subscription Details\" Page find \"Payment\" Section, click Change Payment "
                    "CTA to open fly out and follow the instructions to provide updated payment method. "
                    "**Note:** Payment method change for any service subscription will also update "
                    "payment method for all service subscription under same Subscription Account.")
        return ("Under \"Services Account\" page find \"Subscription Account Summary\" tab, find "
                "\"Payment\" Section, click Change Payment CTA to open fly out and follow the "
                "instructions to provide updated payment method. **Note:** Payment method change for "
                "any service subscription will also update payment method for all service subscription "
                "under same Subscription Account.")

    elif get_help_action == "UPDATE_BILLING_EMAIL":
        if is_null or flag == "NO":
            return ("Billing Notification Email can not be updated for selected subscription as "
                    "this subscription is paid upfront / can not renewed.")
        if not is_services:
            if not recurring_payment:  # RecurringPayment = NO
                return ("Under \"Subscription Details\" Page find \"Billing & Communications\" Section, "
                        "click for Change Billing Email CTA to open fly out and follow the instructions "
                        "to provide updated Billing email id. **Note:** Billing Communication email change "
                        "for any service subscription will also update email for all service subscription "
                        "under same Subscription Account.")
            return "Under Payment section, click change payment method CTA to open fly out and select desired payment options."
        # Services — same message regardless of RecurringPayment
        return ("Under \"Services Account\" page find \"Subscription Account Summary\" tab, find "
                "\"Update Billing Notifications\" Section, click for Update Billing Notification CTA "
                "to open fly out and follow the instructions to provide updated Billing email id. "
                "**Note:** Billing Communication email change for any service subscription will also "
                "update email for all service subscription under same Subscription Account.")

    return "Unable to determine the requested action. Please try again."
```

---

**Change B — Helper: `prepare_get_help_choices_response()`**
3-CTA action menu (same as previous plan).

**Change C — Helper: `prepare_get_help_action_and_care_response()`**
Combines instructional text with care support CTAs:

```python
def prepare_get_help_action_and_care_response(
    workflowId: str, state: ConversationState, payload: RequestPayload
) -> ResponsePayload:
    get_help_action = state.collected.get("get_help_action", "")
    auto_renewal_flag = state.collected.get("auto_renewal_flag")
    recurring_payment = state.collected.get("recurring_payment", False)
    is_services = state.collected.get("is_services", False)

    instructional_msg = _build_get_help_instructional_msg(
        get_help_action, auto_renewal_flag, recurring_payment, is_services
    )
    translated_msg = translator.translate_text(instructional_msg, payload.locale)

    # Care support CTAs
    if is_services:
        care_ctas = [CtaDetails(label="Renewal/Upgrade", message="issue_sub_type = autoRenew")]
    else:
        care_ctas = [
            CtaDetails(label="My Software & Subscription", message="issue_type = Software"),
            CtaDetails(label="Renewal/Upgrade", message="issue_sub_type = autoRenew"),
        ]

    # Build combined response
    ...
```

**Change D — Helper: `prepare_get_help_care_sub_options_response()`**
Sub-options for Software path:

```python
# Returns 2 CTAs: softwareLicensing and downloadsoftware
```

**Change E — Helper: `call_esupport_api()`** (async):
```python
async def call_esupport_api(
    user_selected_issue_type: str,
    user_selected_issue_sub_type: str,
    subscription_context: dict,
    locale: str
) -> str:
    # POST to eSupport MFE/API endpoint (URL from config)
    # Returns contact page HTML/URL or formatted message
    # Placeholder until eSupport API contract is confirmed (FR-28 dependency)
    ...
```

**Change F — `preexecute_step()`:** Add `get_help` context injection (same as previous plan but updated field names).

**Change G — `postexecute_step()`:**
```python
    if state.intent == Intent.get_help:
        _stage = Stage_GetHelp

        if state.stage == _stage.selectActionType:
            return prepare_get_help_choices_response(workflowId, payload)

        if state.stage == _stage.executeActionType:
            return prepare_get_help_action_and_care_response(workflowId, state, payload)

        if state.stage == _stage.cch_select_issue_sub_type:
            return prepare_get_help_care_sub_options_response(workflowId, payload)

        if state.stage == _stage.end:
            contact_result = await call_esupport_api(
                state.collected.get("user_selected_issue_type"),
                state.collected.get("user_selected_issue_sub_type"),
                {"serviceType": state.collected.get("resolved_service_type"),
                 "subscriptionId": state.collected.get("subscription_id")},
                payload.locale
            )
            return build_esupport_response(workflowId, contact_result, payload)
```

**New imports in `subscriptionAIAgent.py`:**
```python
from ..workflows.models import Stage_GetHelp
```

---

## 4. File Change Summary

| File | Change |
|---|---|
| `nlu/prompt.py` | Add `get_help` intent + `get_help_action` + `issue_sub_type` extraction rules to `PROMPT_TEMPLATE_WORKING` |
| `workflows/models.py` | `Intent.get_help`, `Stage_GetHelp` (7 stages), `intent_stage_map` entry, `Result.get_help_response` field |
| `workflows/engine.py` | `get_help` in `is_transition_allowed()`, `step()` (6 transitions), `execute()` (4 stage handlers) |
| `services/subscription_details.py` | `autoRenewalFlag` + `productCadence` in GraphQL query; `get_help` extraction branches in both `extract_*` functions; `get_help` sort in `fetch_subscription_details()` |
| `services/subscriptionAIAgent.py` | `_build_get_help_instructional_msg()`, `prepare_get_help_choices_response()`, `prepare_get_help_action_and_care_response()`, `prepare_get_help_care_sub_options_response()`, `call_esupport_api()`, `build_esupport_response()`; wire in `preexecute_step` + `postexecute_step` |
| `tests/test_get_help_intent.py` | New file — 28 test cases |

---

## 5. Open Dependencies (Blockers)

| # | Item | Owner | Impacts |
|---|---|---|---|
| D-1 | eSupport MFE/API endpoint URL, auth, request/response schema, encrypted data format | Product/Backend team | `call_esupport_api()` and FR-28 |
| D-2 | Preset query format from UI — exact `userQuery` string when "Get Help" button clicked | Frontend/UI team | `preexecute_step` subscription context extraction |

---

## 6. Verification

```bash
# Run from subscription-domain-agent/
pytest virtual_assistant/tests/test_get_help_intent.py -v

# Full regression suite:
pytest --tb=short -q
```

### Manual Verification Checklist
- [ ] Turn 1: POST `/api/v1/subagent/handle` with `messageType="preset"`, `userQuery="Get help for subscription Microsoft 365"` → 3 action CTAs
- [ ] Turn 2: `userQuery="get_help_action = TURN_AUTO_RENEW"`, `messageType="followup"` → instructional text + care support CTAs
- [ ] All 15 routing paths (5 rows × 3 choices) validated against routing matrix
- [ ] Software path: 2 care CTAs shown; Services path: 1 care CTA
- [ ] "My Software & Subscription" → sub-option CTAs displayed
- [ ] "Renewal/Upgrade" → eSupport API called → contact page displayed
- [ ] Same flow via `/api/v2/subagent/handle` (Premier / `is_maverick=true` path)
- [ ] No regression: `cancel_subscription`, `update_payment_method`, `view_subscription_details`
- [ ] Redis state not broken by new stage enum values
